---
title: "Zmiana hasła"
sidebar_label: "3.2. Zmiana hasła"
---

Z poziomu „Moje konto” możliwa jest zmiana hasła użytkownika. Należy najpierw podać aktualne hasło, następnie dwa razy wpisać nowe hasło.

![ Widok okna zmiany hasła użytkownika, w systemie Asiston WMS.](\img\Obrazy\Haslo.png)

 Widok okna zmiany hasła użytkownika, w systemie Asiston WMS.
