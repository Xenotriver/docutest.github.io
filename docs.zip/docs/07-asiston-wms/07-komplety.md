---
title: "Komplety"
sidebar_label: "7.7. Komplety"
---

Komplety to moduł pozwalający na realizacje operacji magazynowych polegająca na łączeniu kilku towarów w jeden zestaw lub rozdzielaniu zestawu na pojedyncze elementy. Proces ten może obejmować kompletację, czyli tworzenie gotowego produktu z różnych części, lub dekompletację, czyli rozłożenie produktu na jego składowe.

## Kompletacja

Po przejściu do listy kompletacji, użytkownik będzie miał widok listy utworzonych dokumentów zleceń kompletacji.

Lista będzie zawierać kolumny:

- Numer dokumentu
- Status
  - Anulowany
  - Do akceptacji
  - Do anulowania
  - Oczekuje na kompletacje
  - Oczekuje na przesunięcie
  - Przerwano
  - W przygotowaniu
  - W trakcie przesunięcia
  - Wersja robocza
  - Zakończony
- Produkty finalne
- Data utworzenia
- Data zakończenia
- Termin realizacji
- Nr dokumentu realizującego
- Przesunięcie
- Osoba blokująca
- Postęp realizacji

Filtrowanie listy możliwe będzie wg następujących kryteriów:

- Numer dokumentu
- Dokument realizujący
- Dokument przesunięcia
- Status
  - Anulowany
  - Do akceptacji
  - Do anulowania
  - Oczekuje na kompletacje
  - Oczekuje na przesunięcie
  - Przerwano
  - W przygotowaniu
  - W trakcie przesunięcia
  - Wersja robocza
  - Zakończony
- Produkt
- Data utworzenia
- Data zakończenia
- Osoba blokująca

![6. Przykładowy widok listy zleceń kompletacji.](\img\OIP.png)

6. Przykładowy widok listy zleceń kompletacji.

### *Tworzenie zlecenia kompletacji*

Możliwość dodania nowego zlecenia kompletacji  będzie dostępna z poziomu listy zleceń w zależności od konfiguracji:

- W widoku magazynowym – dla kompletacji bez akceptacji
- W widoku akceptacji – dla kompletacji z początkową akceptacją

Nowe zlecenie kompletacji  będzie można utworzyć, używając przycisku „Utwórz zlecenie”. System wyświetli formularz tworzenia zlecenia z kolejnym numerem, nadanym automatycznie. W formularzu należy wskazać rodzaj zlecenia. W zależności od wyboru, system wyświetli różne pola do uzupełnienia dostępne możliwość to:

  1. Komplet – Wybieramy zdefiniowany w systemie ERP zestaw posiadający zdefiniowane  składniki. W formularzy dla tego wariantu należy wybrać
- Komplet (z listy rozwijalnej należy wybrać nazwę towaru posiadającego zdefiniowane składowe)
  - W widoku formularza system zwróci sekcję, ze wszystkimi towarami wchodzącymi w skład kompletu. Dla każdej pozycji wyświetli następujące dane
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Potrzebna ilość
    - Dostępna ilość w WMS
    - Dostępna ilość w ERP
    - JM
- Ilość
- Jednostka miary

Po kliknięciu przycisku „Dodaj” system doda komplet do utworzenia i wyświetli sekcję Komplety zawierającą następujące kolumny:

- Symbol
- Nazwę
- Kod towaru
- Ilość
- JM
- Ikonę usuwania
- Ikonę rozwinięcia. Po jej naciśnięciu system wyświetli wiersze ze składnikami kompletu zawierające kolumny:
  - Symbol
  - Nazwa
  - Kod towaru
  - Ilość
  - JM
  - Lokalizacje - listę rozwijalną ze wszystkimi lokalizacjami, na których dany towar znajduje się w magazynie. Lista pozwala użytkownikowi na wskazanie lokalizacji z której ma zostać pobrany towar potrzebny do realizacji zlecenia kompletacji.
  - Ikonę podglądu lokalizacji

Przed zapisaniem będą dostępne opcjonalnie pola do uzupełnienia:

- Termin realizacji
- Utwórz ZZL do kompletacji – pole typu Checkbox, jego zaznaczenie pozwala dodatkowo na konfigurację pól
  - Wymuszaj przesunięcie do lokalizacji końcowej - pole typu Checkbox
  - Lokalizacja dla kompletacji –  lista wyboru pozwalająca na wskazanie lokalizacji na która maja zostać przesunięte składniki do utworzenia kompletu. Jeśli w konfiguracji procesu wskazano domyślna lokalizację jest ona wybrana, jednak system pozwala na jej zmodyfikowanie na etapie realizowanego zlecenia.
- Uwagi (jeśli potrzebne są dodatkowe informacje do obsługi przesunięcia)
  1. Towar – Użytkownik może samodzielnie stworzyć komplet, określając towar nadrzędny i jego poszczególne elementy
- Towar (Lista rozwijalna pozwalająca na wskazanie towaru nadrzędnego i towarów składowych dla tworzonego kompletu)
- Ilość
- Jednostka miary
- Towar nadrzędny  (Lista rozwijalna zawierająca dodane towary w obrębie tworzonego zlecenia)

Każdorazowo po kliknięciu przycisku „Dodaj” system doda do sekcji „Komplety” wybrany towar nadrzędny i jego poszczególne składowe zdefiniowane przez użytkownika.  Sekcja zawiera następujące kolumny:

- Symbol
- Nazwę
- Kod towaru
- Ilość
- JM
- Ikonę usuwania
- Ikonę rozwinięcia. Po jej naciśnięciu system wyświetli wiersze ze składnikami kompletu zawierające kolumny:
  - Symbol
  - Nazwa
  - Kod towaru
  - Ilość
  - JM
  - Lokalizacje - listę rozwijalną ze wszystkimi lokalizacjami, na których dany towar znajduje się w magazynie. Lista pozwala użytkownikowi na wskazanie lokalizacji, z której ma zostać pobrany towar potrzebny do realizacji zlecenia kompletacji.
  - Ikonę podglądu lokalizacji

Przed zapisaniem będą dostępne opcjonalnie pola do uzupełnienia:

- Termin realizacji
- Utwórz ZZL do kompletacji – pole typu Checkbox jego zaznaczenie pozwala dodatkowo na konfigurację pól
  - Wymuszaj przesunięcie do lokalizacji końcowej - pole typu Checkbox
  - Lokalizacja dla kompletacji –  lista wyboru pozwalająca na wskazanie lokalizacji na która maja zostać przesunięte składniki do utworzenia kompletu. Jeśli w konfiguracji procesu wskazano domyślna lokalizację jest ona wybrana, jednak system pozwala na jej zmodyfikowanie na etapie realizowanego zlecenia.
- Uwagi (jeśli potrzebne są dodatkowe informacje do obsługi zlecenia)

Zlecenie będzie można zapisać przyciskami:

•    Zapisz (na liście zlecenie będzie miało status „Wersja robocza”)

•    Zapisz i przekaż do realizacji (na liście zlecenie otrzyma status „Oczekuje na przesunięcie” – dla zleceń, dla których zaznaczono opcje „Utwórz ZZL do kompletacji”  lub „Oczekuje na kompletacje” – dla zleceń dla których nie zlecono ZZL ).

## Dekompletacja

Po przejściu do listy dekompletacji, użytkownik będzie miał widok listy utworzonych dokumentów zleceń dekompletacji.

Lista będzie zawierać kolumny:

- Numer dokumentu
- Status
  - Anulowany
  - Do akceptacji
  - Do anulowania
  - Oczekuje na dekompletacje
  - Oczekuje na przesunięcie
  - Przerwano
  - W przygotowaniu
  - W trakcie przesunięcia
  - Wersja robocza
  - Zakończony
- Komplet
- Data utworzenia
- Data zakończenia
- Termin realizacji
- Nr dokumentu realizującego
- Przesunięcie
- Osoba blokująca
- Postęp realizacji

Filtrowanie listy możliwe będzie wg następujących kryteriów:

- Numer dokumentu
- Dokument realizujący
- Dokument przesunięcia
- Status
  - Anulowany
  - Do akceptacji
  - Do anulowania
  - Oczekuje na dekompletacje
  - Oczekuje na przesunięcie
  - Przerwano
  - W przygotowaniu
  - W trakcie przesunięcia
  - Wersja robocza
  - Zakończony
- Produkt
- Data utworzenia
- Data zakończenia
- Osoba blokująca

![7. Przykładowy widok listy zleceń dekompletacji.](\img\OIP.png)

7. Przykładowy widok listy zleceń dekompletacji.

### *Tworzenie zlecenia dekompletacji*

Możliwość dodania nowego zlecenia dekompletacji będzie dostępna z poziomu listy zleceń w zależności od konfiguracji:

- W widoku magazynowym – dla dekompletacji bez akceptacji
- W widoku akceptacji – dla dekompletacji z początkową akceptacją

Nowe zlecenie dekompletacji  będzie można utworzyć, używając przycisku „Utwórz zlecenie”. System wyświetli formularz tworzenia zlecenia z kolejnym numerem, nadanym automatycznie. W formularzu należy wskazać rodzaj zlecenia. W zależności od wyboru, system wyświetli różne pola do uzupełnienia dostępne możliwość to:

1. Komplet – Wybieramy zdefiniowany w systemie ERP zestaw posiadający zdefiniowane  składniki. W formularzy dla tego wariantu należy wybrać
- Komplet (z listy rozwijalnej należy wybrać nazwę towaru posiadającego zdefiniowane składowe)
  - W widoku formularza system zwróci sekcję, ze wszystkimi towarami wchodzącymi w skład kompletu. Dla każdej pozycji wyświetli następujące dane
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Potrzebna ilość
    - Dostępna ilość w WMS
    - Dostępna ilość w ERP
    - JM
- Ilość
- Jednostka miary

Po kliknięciu przycisku „Dodaj” system doda komplet do dekompletacji i wyświetli Komplety zawierająca następujące kolumny:

- Symbol
- Nazwę
- Kod towaru
- Ilość
- JM
- Lokalizacje - listę rozwijalną ze wszystkimi lokalizacjami, na których dany komplet znajduje się w magazynie. Lista pozwala użytkownikowi na wskazanie lokalizacji, z której ma zostać pobrany zestaw przeznaczony do dekompletacji.
- Ikonę podglądu lokalizacji
- Ikonę usuwania
- Ikonę rozwinięcia. Po jej naciśnięciu system wyświetli wiersze ze składnikami kompletu zawierające kolumny:
  - Symbol
  - Nazwa
  - Kod towaru
  - Ilość
  - JM

Przed zapisaniem będą dostępne opcjonalnie pola do uzupełnienia:

- Termin realizacji
- Utwórz ZZL do dekompletacji – pole typu Checkbox jego zaznaczenie pozwala dodatkowo na konfigurację pól
  - Wymuszaj przesunięcie do lokalizacji końcowej - pole typu Checkbox
  - Lokalizacja dla dekompletacji – lista wyboru pozwalająca na wskazanie lokalizacji na która przesuwamy komplety do dekompletacji. Jeśli w konfiguracji procesu wskazano domyślna lokalizację, jest ona wybrana, jednak system pozwala na jej zmodyfikowanie na etapie realizowanego zlecenia.
- Uwagi (jeśli potrzebne są dodatkowe informacje do obsługi zlecenia)
1. Towar – Użytkownik samodzielnie wskazuje komplet i jego poszczególne elementy podlegające dekompletacji
- Towar (Lista rozwijalna pozwalająca na wskazanie towaru nadrzędnego i towarów składowych dla tworzonego zlecenia dekompletacji)
- Ilość
- Jednostka miary
- Towar nadrzędny (Lista rozwijalna zawierająca dodane towary w obrębie tworzonego zlecenia)

Każdorazowo po kliknięciu przycisku „Dodaj” system doda do sekcji „Komplety” wybrany towar nadrzędny i jego poszczególne składowe. Sekcja zawiera następujące kolumny:

- Symbol
- Nazwę
- Kod towaru
- Ilość
- JM
- Lokalizacja - listę rozwijalną ze wszystkimi lokalizacjami, na których dany komplet znajduje się w magazynie. Lista pozwala użytkownikowi na wskazanie lokalizacji, z której ma zostać pobrany zestaw przeznaczony do dekompletacji.
- Ikonę usuwania
- Ikonę rozwinięcia. Po jej naciśnięciu system wyświetli wiersze ze składnikami kompletu zawierające kolumny:
  - Symbol
  - Nazwa
  - Kod towaru
  - Ilość
  - JM
  - Ikonę podglądu lokalizacji

Przed zapisaniem będą dostępne opcjonalnie pola do uzupełnienia:

- Termin realizacji
- Utwórz ZZL do dekompletacji – pole typu Checkbox jego zaznaczenie pozwala dodatkowo na konfigurację pól
  - Wymuszaj przesunięcie do lokalizacji końcowej - pole typu Checkbox
  - Lokalizacja dla dekompletacji – lista wyboru pozwalająca na wskazanie lokalizacji na która przesuwamy komplety do dekompletacji. Jeśli w konfiguracji procesu wskazano domyślna lokalizację, jest ona wybrana, jednak system pozwala na jej zmodyfikowanie na etapie realizowanego zlecenia.
- Uwagi (jeśli potrzebne są dodatkowe informacje do obsługi zlecenia)

Zlecenie będzie można zapisać przyciskami:

•    Zapisz (na liście zlecenie będzie miało status „Wersja robocza”)

•    Zapisz i przekaż do realizacji (na liście zlecenie otrzyma status „Oczekuje na przesunięcie” – dla zleceń, dla których zaznaczono opcje „Utwórz ZZL do dekompletacji”  lub „Oczekuje na dekompletacje” – dla zleceń dla których nie zlecono ZZL ).

## Opisy procesów kompletacji

### Kompletacja bez akceptacji

![Diagram 43 Kompletacja bez akceptacji](\img\OIP.png)

Diagram 43 Kompletacja bez akceptacji

Proces rozpoczyna się od utworzenia zlecenia kompletacji z poziomu widoku magazynowego. Pracownik, tworząc dokument, może zlecić kompletację na dwa sposoby:

1. **Predefiniowany komplet z systemu ERP:**
- Pracownik wybiera właściwą pozycję na liście towarów i określa ilość kompletów do utworzenia.
- System automatycznie pobiera listę wszystkich składników potrzebnych do przygotowania określonej ilości kompletów.
1. **Własny zestaw:**
- Pracownik ręcznie definiuje komplet oraz jego składniki, wskazując ilość poszczególnych towarów wchodzących w skład kompletu.

Dodatkowo, podczas tworzenia zlecenia, pracownik może określić, czy towary przeznaczone do utworzenia kompletu mają zostać przed kompletacją przesunięte do innej lokalizacji (ZZL). Możliwe są dwie opcje konfiguracji ZZL:

- Sugerowana lokalizacja: System proponuje lokalizację, do której użytkownik powinien odłożyć składniki przed kompletacją.
- Wymuszona lokalizacja: System wymusza na użytkowniku odłożenie składników wyłącznie na zdefiniowaną lokalizację.

Po wprowadzeniu wszystkich parametrów zlecenia kompletacji, pracownik zapisuje zlecenie i przekazuje je do realizacji. Zgłoszenie jest automatycznie awizowane zarówno w widoku akceptacji, jak i w widoku magazynowym.

Po przekazaniu zlecenia do realizacji system nadaje odpowiedni status zależny od konfiguracji:

- „Oczekuje na przesunięcie” – Nadawany, jeśli w zleceniu utworzono dokument ZZL (Zlecenie Zmiany Lokalizacji).
- „Oczekuje na kompletację” – Nadawany, jeśli:
  - Dokument ZZL nie został utworzony (składniki są pobierane z lokalizacji w trakcie realizacji kompletacji).
  - Dokument ZZL został zrealizowany, a składniki są gotowe do kompletacji.

Zlecenie zmiany lokalizacji realizowane jest z poziomu modułu „Przesunięcia” z zakładki „Zlecenia”.

Pracownik posiadający uprawnienia do modułu kompletacji może podjąć do realizacji zlecenia ze statusem „Oczekuje na kompletację”. Po podjęciu zlecenia jego status zmienia się na „W przygotowaniu”.

Następnie Pracownik skanuje kody poszczególnych towarów wchodzących w skład kompletu oraz kod utworzonego kompletu.

Po zeskanowaniu wszystkich pozycji z listy, pracownik może zakończyć zlecenie kompletacji, system automatycznie zmienia status zadania na „Zakończone”.

### Kompletacja z akceptacją

![Diagram 44 Kompletacja z akceptacją](\img\OIP.png)

Diagram 44 Kompletacja z akceptacją

Proces rozpoczyna się od utworzenia zlecenia kompletacji z poziomu widoku akceptacji. Pracownik, tworząc dokument, może zlecić kompletację na dwa sposoby:

1. **Predefiniowany komplet z systemu ERP:**
- Pracownik wybiera właściwą pozycję na liście towarów i określa ilość kompletów do utworzenia.
- System automatycznie pobiera listę wszystkich składników potrzebnych do przygotowania określonej ilości kompletów.
1. **Własny zestaw:**
- Pracownik ręcznie definiuje komplet oraz jego składniki, wskazując ilość poszczególnych towarów wchodzących w skład kompletu.

Dodatkowo, podczas tworzenia zlecenia, pracownik może określić, czy towary przeznaczone do utworzenia kompletu mają zostać przed kompletacją przesunięte do innej lokalizacji (ZZL). Możliwe są dwie opcje konfiguracji ZZL:

- Sugerowana lokalizacja: System proponuje lokalizację, do której użytkownik powinien odłożyć składniki przed kompletacją.
- Wymuszona lokalizacja: System wymusza na użytkowniku odłożenie składników wyłącznie na zdefiniowaną lokalizację.

Po wprowadzeniu wszystkich parametrów zlecenia kompletacji, pracownik z zapisuje zlecenie co skutkuje nadanie statusu „do akceptacji. Pracownik posiadający uprawnienia do modułu akceptacji może zwrócić zlecenie do edycji lub przekazać zlecenie do magazynu (akceptacja). Po zaakceptowaniu zgłoszenia i przekazaniu go do magazynu Zgłoszenie jest automatycznie awizowane w widoku magazynowym.

W zależności od konfiguracji system nadaje odpowiedni status zlecenia:

- „Oczekuje na przesunięcie” – Nadawany, jeśli w zleceniu utworzono dokument ZZL (Zlecenie Zmiany Lokalizacji).
- „Oczekuje na kompletację” – Nadawany, jeśli:
  - Dokument ZZL nie został utworzony (składniki są pobierane z lokalizacji w trakcie realizacji kompletacji).
  - Dokument ZZL został zrealizowany, a składniki są gotowe do kompletacji.

Zlecenie zmiany lokalizacji realizowane jest z poziomu modułu „Przesunięcia” z zakładki „Zlecenia”.

Pracownik posiadający uprawnienia do modułu kompletacji może podjąć do realizacji zlecenia ze statusem „Oczekuje na kompletację”. Po podjęciu zlecenia jego status zmienia się na „W przygotowaniu”.

Następnie Pracownik skanuje kody poszczególnych towarów wchodzących w skład kompletu oraz kod utworzonego kompletu.

Po zeskanowaniu wszystkich pozycji z listy, pracownik może zakończyć zlecenie kompletacji, system automatycznie zmienia status zadania na „Zakończone”.


## Opisy procesów dekompletacji

### Dekompletacja bez akceptacji

![Diagram 45 Dekompletacja bez akceptacji](\img\OIP.png)

Diagram 45 Dekompletacja bez akceptacji

Proces rozpoczyna się od utworzenia zlecenia dekompletacji z poziomu widoku magazynowego. Pracownik, tworząc dokument, może zlecić dekompletację na dwa sposoby:

    1. **Dekompletacja predefiniowanego komplet z systemu ERP:**
- Pracownik wybiera właściwą pozycję na liście towarów i określa ilość kompletów do dekompletacji.
- System automatycznie pobiera listę wszystkich składników wchodzących w skład kompletu.
    1. **Dekompletacja własnego zestawu:**
- Pracownik ręcznie definiuje komplety przeznaczone do dekompletacji. Musi wskazać komplet oraz jego składniki, wskazując ilość poszczególnych towarów wchodzących w skład kompletu.

Dodatkowo, podczas tworzenia zlecenia, pracownik może określić, czy towary przeznaczone do dekompletacji mają zostać przed dekompletacją przesunięte do innej lokalizacji (ZZL). Możliwe są dwie opcje konfiguracji ZZL:

- Sugerowana lokalizacja: System proponuje lokalizację, do której użytkownik powinien odłożyć komplety przeznaczone do dekompletacji.
- Wymuszona lokalizacja: System wymusza na użytkowniku odłożenie kompletów przeznaczonych do dekompletacji wyłącznie na zdefiniowaną lokalizację.

Po wprowadzeniu wszystkich parametrów zlecenia dekompletacji, pracownik zapisuje zlecenie i przekazuje je do realizacji. Zgłoszenie jest automatycznie awizowane zarówno w widoku akceptacji, jak i w widoku magazynowym.

Po przekazaniu zlecenia do realizacji system nadaje odpowiedni status zależny od konfiguracji:

- „Oczekuje na przesunięcie” – Nadawany, jeśli w zleceniu utworzono dokument ZZL (Zlecenie Zmiany Lokalizacji).
- „Oczekuje na dekompletację” – Nadawany, jeśli:
  - Dokument ZZL nie został utworzony (komplety są pobierane z lokalizacji w trakcie realizacji dekompletacji).
  - Dokument ZZL został zrealizowany, a komplety przeznaczone do dekompletacji znajdują się w właściwej lokalizacji.

Zlecenie zmiany lokalizacji realizowane jest z poziomu modułu „Przesunięcia” z zakładki „Zlecenia”.

Pracownik posiadający uprawnienia do modułu dekompletacji może podjąć do realizacji zlecenia ze statusem „Oczekuje na dekompletację”. Po podjęciu zlecenia jego status zmienia się na „W przygotowaniu”.

Następnie Pracownik skanuje kody kompletu przeznaczonego do dekompletacji oraz kody poszczególnych towarów wchodzących w skład kompletu.

Po zeskanowaniu wszystkich pozycji z listy, pracownik może zakończyć zlecenie dekompletacji, system automatycznie zmienia status zadania na „Zakończone”.

### Dekompletacja z akceptacją

![Diagram 46 Dekompletacja z akceptacją](\img\OIP.png)

Diagram 46 Dekompletacja z akceptacją

Proces rozpoczyna się od utworzenia zlecenia dekompletacji z poziomu widoku akceptacji. Pracownik, tworząc dokument, może zlecić dekompletację na dwa sposoby:

    1. **Dekompletacja predefiniowanego komplet z systemu ERP:**
- Pracownik wybiera właściwą pozycję na liście towarów i określa ilość kompletów do dekompletacji.
- System automatycznie pobiera listę wszystkich składników wchodzących w skład kompletu.
    1. **Dekompletacja własnego zestawu:**
- Pracownik ręcznie definiuje komplety przeznaczone do dekompletacji. Musi wskazać komplet oraz jego składniki, wskazując ilość poszczególnych towarów wchodzących w skład kompletu.

Dodatkowo, podczas tworzenia zlecenia, pracownik może określić, czy towary przeznaczone do dekompletacji mają zostać przed dekompletacją przesunięte do innej lokalizacji (ZZL). Możliwe są dwie opcje konfiguracji ZZL:

- Sugerowana lokalizacja: System proponuje lokalizację, do której użytkownik powinien odłożyć komplety przeznaczone do dekompletacji.
- Wymuszona lokalizacja: System wymusza na użytkowniku odłożenie kompletów przeznaczonych do dekompletacji wyłącznie na zdefiniowaną lokalizację.

Po wprowadzeniu wszystkich parametrów zlecenia dekompletacji, pracownik z zapisuje zlecenie co skutkuje nadanie statusu „do akceptacji. Pracownik posiadający uprawnienia do modułu akceptacji może zwrócić zlecenie do edycji lub przekazać zlecenie do magazynu (akceptacja). Po zaakceptowaniu zgłoszenia i przekazaniu go do magazynu Zgłoszenie jest automatycznie awizowane w widoku magazynowym.

W zależności od konfiguracji system nadaje odpowiedni status zlecenia:

- „Oczekuje na przesunięcie” – Nadawany, jeśli w zleceniu utworzono dokument ZZL (Zlecenie Zmiany Lokalizacji).
- „Oczekuje na dekompletację” – Nadawany, jeśli:
  - Dokument ZZL nie został utworzony (komplety są pobierane z lokalizacji w trakcie realizacji dekompletacji).
  - Dokument ZZL został zrealizowany, a komplety przeznaczone do dekompletacji znajdują się w właściwej lokalizacji.

Zlecenie zmiany lokalizacji realizowane jest z poziomu modułu „Przesunięcia” z zakładki „Zlecenia”.

Pracownik posiadający uprawnienia do modułu dekompletacji może podjąć do realizacji zlecenia ze statusem „Oczekuje na dekompletację”. Po podjęciu zlecenia jego status zmienia się na „W przygotowaniu”.

Następnie Pracownik skanuje kody kompletu przeznaczonego do dekompletacji oraz kody poszczególnych towarów wchodzących w skład kompletu.

Po zeskanowaniu wszystkich pozycji z listy, pracownik może zakończyć zlecenie dekompletacji, system automatycznie zmienia status zadania na „Zakończone”.