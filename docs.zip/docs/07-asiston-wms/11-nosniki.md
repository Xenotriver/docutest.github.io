---
title: "Nośniki"
sidebar_label: "7.11. Nośniki"
---

Konfiguracja nośników służy do oznaczania pojemników, palet i wózków, wykorzystywanych do zbierania i przemieszczania towaru w procesie magazynowym.

Widok listy nośników będzie zawierał następujące informacje:

- Nazwę,
- Opis,
- Kod,
- Typ,
- Rodzaj,
- Wagę,
- Wymiary,
- Zajętość
- Przycisk akcji: „Podgląd/Drukuj/Edytuj/Usuń”.

Listę nośników można będzie filtrować wg:

- Nazwy,
- Typu,
- Kodu.

![4. Widok list nośników w systemie Asiston WMS.](\img\OIP.png)

4. Widok list nośników w systemie Asiston WMS.

Dodawanie nowego nośnika do listy, będzie się odbywać przyciskiem „Dodaj nośnik”. Użycie przycisku zwróci formularz z następującymi polami do wypełnienia:

- Nazwa nośnika – pole obowiązkowe,
- Opis,
- Typ nośnika:
  - Stały,
  - Opakowanie
- Rodzaj nośnika (możliwość wyboru dla nośnika stałego),
- Kod nośnika,
- Długość,
- Szerokość,
- Wysokość
- Masa.

Z widoku listy nośników można będzie wejść do szczegółów wybranego nośnika. Widok szczegółów zawiera:

- Nazwa nośnika,
- Opis,
- Typ nośnika,
- Rodzaj nośnika (pole widoczne dla nośnika stałego),
- Kod,
- Długość,
- Szerokość,
- Wysokość
- Masa.

![5. Widok szczegółów nośnika, w systemie Asiston WMS.](\img\OIP.png)

5. Widok szczegółów nośnika, w systemie Asiston WMS.

Wszystkie pola, widoczne w szczegółach nośnika są edytowalne, można zmieniać ich zawartość. Wprowadzone zmiany należy zapisać przyciskiem „Zapisz” lub „Zapisz i wróć”.

## Ustawienia nośników

Z poziomu listy nośników istnieje możliwość przejścia do ustawień nośników, z poziomu którego możliwe będzie dodanie rodzajów dla nośników stałych.

Widok ustawień nośników będzie zawierał następujące informacje:

- Nazwę,
- Wagę,
- Wymiary,
- Przycisk akcji: „Edytuj/Usuń”.

Listę ustawień nośników można będzie filtrować wg:

- Nazwy,

![6. Widok ustawień nośników](\img\OIP.png)

6. Widok ustawień nośników

Dodawanie nowego rodzaju nośnika, będzie się odbywać przyciskiem „Dodaj rodzaj”. Użycie przycisku zwróci formularz z następującymi polami do wypełnienia:

- Nazwa rodzaju nośnika,
- Długość,
- Szerokość,
- Wysokość,
- Masa.

Z widoku listy ustawień można będzie wejść do szczegółów wybranego rodzaju nośnika. Widok szczegółów zawiera:

- Nazwa rodzaju nośnika,
- Długość,
- Szerokość,
- Wysokość,
- Masa.
