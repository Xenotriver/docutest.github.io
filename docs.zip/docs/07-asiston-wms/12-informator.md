---
title: "Informator"
sidebar_label: "7.12. Informator"
---

Informator to narzędzie, które pozwala szybko uzyskać informacje na temat lokalizacji danego produktu w magazynie. Jego głównym celem jest ułatwienie wyszukiwania i podglądu danych dotyczących konkretnego produktu, nośnika czy lokalizacji.

Widok informatora zawiera:

- Wyszukiwarkę
- Opcję „Wyszukiwanie dokładnej wartości” – odznaczenie spowoduje wyszukiwanie po produkcie, nośniku, lokalizacji zawierające wprowadzoną wartość
- Resetuj – powoduje wyczyszczenie wartości z wyszukiwarki
- Szukaj – powoduje wyszukanie wyników zgodnie z wprowadzoną wartością

![7. Widok wyszukiwarki informatora](\img\OIP.png)

7. Widok wyszukiwarki informatora

Widok informatora po wyszukaniu wartości zawiera:

- Symbol,
- Nazwę,
- Kod,
- Lokalizację,
- Nośnik,
- Partię,
- Ilość,
- JM

Dodatkowo wyniki można filtrować po:

- Symbol/Nazwie/EAN produktu
- Lokalizacji
- Nośniku
- Partii

![8. Widok informatora](\img\OIP.png)

8. Widok informatora
