---
title: "Użytkownicy"
sidebar_label: "4.1. Użytkownicy"
---

W module tym będzie znajdować się lista użytkowników – pracowników, zatrudnionych  w firmie i mających dostęp do aplikacji. Na liście będą widoczne takie informacje jak:

- Imię i nazwisko użytkownika
- Nazwa - za pomocą której będzie logował się do systemu
- E-mail
- Typ konta
- Data rejestracji użytkownika
- Akcje:
  - Edytuj,
  - Usuń

Użytkowników można przefiltrować według kryteriów:

- Nazwa użytkownika
- Imię
- Nazwisko
- Data dodania użytkownika
- Email potwierdzony (tak/nie)
- Konta aktywne (tak/nie)
- Konta zanonimizowane (tak/nie)
- Konto z dostępem do panelu administracyjnego (tak/nie)

![ Przykładowy widok listy użytkowników w systemie Asiston WMS.](\img\Obrazy\Lista_uzytkownikow.png)

 Przykładowy widok listy użytkowników w systemie Asiston WMS.

Administrator będzie mógł dodać użytkownika, przyciskiem „Dodaj użytkownika”. Po jego użyciu, system wyświetli widok z polami do wypełnienia. Widok będzie zawierał trzy zakładki:

- Ustawienia konta - z danymi użytkownika,
- Uprawnienia – lista dostępnych ról uprawnień,
- Inspekcja – lista efektywnych uprawnień użytkownika.

![ Widok dodawania użytkownika w systemie Asiston WMS, zakładka „Ustawienia konta”.](\img\Obrazy\Ustawienia_konta.png)

 Widok dodawania użytkownika w systemie Asiston WMS, zakładka „Ustawienia konta”.

![ Widok dodawania użytkownika w systemie Asiston WMS, zakładka „Uprawnienia”.](\img\Obrazy\Uprawnienia.png)

 Widok dodawania użytkownika w systemie Asiston WMS, zakładka „Uprawnienia”.

![Widok dodawania użytkownika w systemie Asiston WMS, zakładka „Inspekcja”.](\img\Obrazy\Inspekcja.png)

Widok dodawania użytkownika w systemie Asiston WMS, zakładka „Inspekcja”.

Te same widoki będą dostępne po wejściu w szczegóły istniejących już użytkowników na liście i będą mogły być aktualizowane.
