---
title: "Akceptacje"
sidebar_label: "7.3. Akceptacje"
---

Moduł ten służy do obsługi akceptacji dokumentów przyjęć i wydań, w procesach, w których taka akceptacja będzie występować. Wybór wariantów procesów – z akceptacją lub bez - będzie dokonywany wcześniej, w konfiguracji procesów („Konfiguracja WMS/Procesy”).

## Przyjęcia awizowane

W module „Przyjęcia awizowane” będą znajdować się dokumenty ZD, wymagające akceptacji:

- Początkowej,
- Końcowej,
- Początkowej i końcowej.

Dane na liście przyjęć:

- Numer dokumentu
- Pierwotny dokument
- Status:
  - Nowy – wymaga akcji akceptanta
  - Oczekuje na przyjęcie
  - W przygotowaniu
  - Przerwano
  - Zwrócone
  - Do akceptacji - wymaga akcji akceptanta
  - Zakończony
- Kontrahent
- Data utworzenia
- Data dostawy
- Data zakończenia
- Nr dokumentu realizującego
- Postęp realizacji
- Osoba blokująca
- Priorytet
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Kontrahenta – wyszukiwanie po nazwie
- Statusu:
  - Nowy
  - Oczekuje na przyjęcie
  - W przygotowaniu
  - Przerwano
  - Zwrócone
  - Do akceptacji
  - Zakończony
  - Zwrócone
- Daty utworzenia (od – do)
- Daty dostawy (od – do)
- Daty zakończenia (od – do)
- Osoby blokującej
- Priorytet

![6. Widok listy dokumentów przyjęć awizowanych, wymagających akceptacji.](\img\Obrazy\Akceptacja_przyjecie_awizo.png)

6. Widok listy dokumentów przyjęć awizowanych, wymagających akceptacji.

Widok szczegółów dokumentu akceptacji przyjęcia awizowanego zawiera:

- Numer dokumentu
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Pasek postępu obsługi dokumentu
- Sekcję „Towary” z następującymi elementami:
  - Pole wyszukiwania po frazie z dowolnej kolumny na liście
  - Listę awizowanych towarów w dokumencie, lista ma następujące kolumny:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
    - Termin realizacji (możliwość edycji tego pola w dokumencie akceptacji, o statusie „Nowy” oraz „Do akceptacji”)
    - Opis dla pozycji (możliwość edycji tego pola w dokumencie akceptacji, o statusie „Nowy” oraz „Do akceptacji”)
    - Przycisk rozwijania pola, pole rozwijane zawiera (dla danego towaru):
      - Lokalizacja
      - Nośnik
      - Ilości
      - JM
      - Partia
      - Ikonkę usuwania
- Sekcję „Podstawowe informacje”, która wyświetla
  - Nazwę kontrahenta
  - Status dokumentu
  - Nr dokumentu realizującego,
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Datę dostawy
  - Datę zakończenia przyjęcia
  - Pole „Uwagi”, tu akceptant może wpisać uwagi dla magazyniera.
  - Ilość palet
- Przyciski, których zestaw zależy od statusu dokumentu:
  - Dla statusu „Nowy”, przyciski:
    - Akcji:
      - Powrót
      - Edytuj
      - Przekaż do magazynu
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla statusu „Do akceptacji”, przyciski:
    - Akcji:
      - Powrót
      - Edytuj
      - Wyślij do ERP
      - Zwróć do magazynu
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla pozostałych statusów, przyciski przełączania widoków:
      - Powrót
      - Pokaż powiązane dokumenty
      - Logi

![7. Widok szczegółów akceptacji dokumentu przyjęcia awizowanego.](\img\OIP.png)

7. Widok szczegółów akceptacji dokumentu przyjęcia awizowanego.

## Przyjęcia bezpośrednie

W module „Przyjęcia bezpośrednie” będą znajdować się dokumenty przyjęć bezpośrednich (PWW), wymagające końcowej akceptacji.

Dane na liście przyjęć:

- Numer dokumentu
- Status:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zwrócony
  - Do akceptacji
  - Zakończony
- Data utworzenia
- Data zakończenia
- Nr dokumentu realizującego
- Osoba blokująca
- Magazyn ERP
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Statusu:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zwrócony
  - Do akceptacji
  - Zakończony
- Daty utworzenia (od – do)
- Daty zakończenia (od – do)
- Osoby blokującej

![8. Widok listy dokumentów przyjęć bezpośrednich w module akceptacji.](\img\Obrazy\Akceptacja_przyjecie_bezp.png)

8. Widok listy dokumentów przyjęć bezpośrednich w module akceptacji.

Widok szczegółów dokumentu akceptacji przyjęcia bezpośredniego zawiera:

- Numer dokumentu
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Sekcję „Towary” z następującymi elementami:
  - Pole wyszukiwania po frazie z dowolnej kolumny na liście
  - Listę awizowanych towarów w dokumencie, lista ma następujące kolumny:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
    - Opis dla pozycji
    - Przycisk rozwijania pola, pole rozwijane zawiera (dla danego towaru):
      - Lokalizacja
      - Nośnik
      - Ilość (możliwość edycji tego pola w dokumencie akceptacji, o statusie „Do akceptacji”)
      - JM
      - Partia
      - Ikonkę usuwania
- Sekcję „Podstawowe informacje”, która wyświetla
  - Status dokumentu
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Datę zakończenia przyjęcia
  - Pole „Uwagi”, tu akceptant może wpisać uwagi dla magazyniera.
- Przyciski, których zestaw zależy od statusu dokumentu:
  - Dla statusu „Nowy”, przyciski:
    - Akcji:
      - Powrót
      - Edytuj
      - Przekaż do magazynu
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla statusu „Do akceptacji”, przyciski:
    - Akcji:
      - Powrót
      - Edytuj
      - Wyślij do ERP
      - Zwróć do magazynu
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla pozostałych statusów, przyciski przełączania widoków:
      - Powrót
      - Pokaż powiązane dokumenty
      - Logi

![9. Widok szczegółów akceptacji dokumentu przyjęcia bezpośredniego.](\img\OIP.png)

9. Widok szczegółów akceptacji dokumentu przyjęcia bezpośredniego.

## Wydania

W module „Wydania” będą znajdować się dokumenty wydań, wymagające akceptacji:

- Początkowej,
- Końcowej,
- Początkowej i końcowej.

Dane na liście wydań:

- Numer dokumentu
- Pierwotny dokument
- Kontrahent
- Status:
  - Nowy – wymaga akcji akceptanta
  - Oczekuje na zbieranie
  - W trakcie zbierania
  - Oczekuje na pakowanie
  - W trakcie pakowania
  - Oczekuje na wydanie kurierowi
  - Anulowane
  - Przerwano
  - Do akceptacji - wymaga akcji akceptanta
  - Zakończony
- Data utworzenia
- Waga całkowita pozycji
- Objętość całkowita pozycji
- Nr dokumentu realizującego
- Listy przewozowe
- Typ wydania
- Termin realizacji
- Data zakończenia
- Kurier
- Osoba wystawiająca
- Priorytet
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Nr dokumentu powiązanego
- Kontrahenta – wyszukiwanie po nazwie
- Statusu:
  - Nowy – wymaga akcji akceptanta
  - Oczekuje na zbieranie
  - W trakcie zbierania
  - Oczekuje na pakowanie
  - W trakcie pakowania
  - Oczekuje na wydanie kurierowi
  - Anulowane
  - Przerwano
  - Do akceptacji - wymaga akcji akceptanta
  - Zakończony
- Daty utworzenia (od – do)
- Daty zakończenia (od – do)
- Uwag dokumentu
- Zawierania listów przewozowych
- Odbioru osobistego
- Wagi całkowitej
- Kuriera
- Objętości całkowitej
- Priorytecie
- Nr listu przewozowego
- Nr opakowania

![0. Widok listy dokumentów wydań awizowanych, wymagających akceptacji.](\img\Obrazy\Akceptacja_wydanie.png)

0. Widok listy dokumentów wydań awizowanych, wymagających akceptacji.

Widok szczegółów dokumentu akceptacji wydania awizowanego zawiera:

- Numer dokumentu
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Pasek postępu obsługi dokumentu
- Sekcję „Towary” z następującymi elementami:
  - Pole wyszukiwania po frazie z dowolnej kolumny na liście
  - Listę awizowanych towarów w dokumencie, lista ma następujące kolumny:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
    - Ilość przekazana
    - Ilość dostępna
- Sekcję „Kontrahent”, która zawiera:
  - Listę rozwijaną wyboru kontrahenta (możliwa do zmiany w trybie edycji),
  - Adres dostawy
    - Państwo
    - Miasto
    - Kod pocztowy
    - Ulica
    - Nr budynku
    - Nr lokalu
    - Osoba kontaktowa
    - Firma testowa
    - Nr tel. os. Kontaktowej
    - Adres e-mail
  - Listę rozwijaną wyboru dokumentu realizującego (możliwa do zmiany w trybie edycji)
    - Faktura sprzedaży
    - Wydanie zewnętrzne (WZ)
    - Paragon imienny
    - Wyłączone
- Sekcję „Dostawa”, która zawiera
  - Listy rozwijane (możliwe do zmiany w trybie edycji)
    - Kurier
    - Rodzaj przesyłki
    - Dłużyca
  - Pola (możliwe do zmiany w trybie edycji)
    - Ilość paczek/palet
    - Opcje dodatkowe
    - Suma obj. Zamówienia
    - Suma wagi zamówienia
- Sekcję „Listy przewozowe”, która zawiera
  - Listę wygenerowanych listów przewozowych, która zawiera kolumny
    - Kurier
    - Rodzaj
    - Ilość
    - Waga (kg)
    - Długość (m)
    - Szerokość (m)
    - Wysokość (m)
    - Numer listu przewozowego
    - Przycisk do wydruku etykiety
    - Przycisk do usunięcia listu przewozowego
  - Przycisk do dodania listu przewozowego, który po kliknięciu otwiera pop’up z polami
    - Kurier (lista rozwijana),
    - Numer listu przewozowego,
    - Pole do załączenia pliku.
- Sekcję „Podstawowe informacje”, która wyświetla
  - Status dokumentu
  - Nr dokumentu realizującego,
  - Pierwotny dokument
  - Datę utworzenia dokumentu
  - Datę zakończenia
  - Opis (ERP)
  - Osobę wystawiającą
  - Walutę dokumentu
  - Dokument priorytetowy
  - Priorytet
  - Dokument realizujący
  - Pole „Uwagi”, tu akceptant może wpisać uwagi dla magazyniera.
- Przyciski, których zestaw zależy od statusu dokumentu:
  - Dla statusu „Nowy”, przyciski:
    - Akcji:
      - Powrót
      - Edytuj
      - Przekaż do magazynu
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla statusu „Do akceptacji”, przyciski:
    - Akcji:
      - Powrót
      - Edytuj
      - Wyślij do ERP
      - Zwróć do magazynu
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla pozostałych statusów, przyciski przełączania widoków:
      - Powrót
      - Pokaż powiązane dokumenty
      - Logi

![1. Widok szczegółów akceptacji dokumentu wydania awizowanego.](\img\OIP.png)

1. Widok szczegółów akceptacji dokumentu wydania awizowanego.

## Wydania bezpośrednie

W module „Wydania bezpośrednie” będą znajdować się dokumenty wydań bezpośrednich, wymagające końcowej akceptacji.

Dane na liście przyjęć:

- Numer dokumentu
- Status:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zwrócony
  - Do akceptacji
  - Zakończony
- Data utworzenia
- Data zakończenia
- Nr dokumentu realizującego
- Osoba blokująca
- Magazyn ERP
- Priorytet
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Statusu:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zwrócony
  - Do akceptacji
  - Zakończony
- Daty utworzenia (od – do)
- Daty zakończenia (od – do)
- Produktu
- Osoby blokującej
- Priorytetu

![2. Widok listy dokumentów wydań bezpośrednich w module akceptacji.](\img\Obrazy\Akceptacja_wydanie_bezp.png)

2. Widok listy dokumentów wydań bezpośrednich w module akceptacji.

Widok szczegółów dokumentu akceptacji wydania bezpośredniego zawiera:

- Numer dokumentu
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Sekcję „Towary” z następującymi elementami:
  - Pole wyszukiwania po frazie z dowolnej kolumny na liście
  - Listę awizowanych towarów w dokumencie, lista ma następujące kolumny:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
    - Przycisk rozwijania pola, pole rozwijane zawiera (dla danego towaru):
      - Lokalizacja
      - Nośnik
      - Ilość
      - JM
      - Partia
- Sekcję „Podstawowe informacje”, która wyświetla
  - Status dokumentu
  - Nr dokumentu realizującego
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Datę zakończenia wydania
  - Pole „Uwagi”.
- Przyciski, których zestaw zależy od statusu dokumentu:
  - Dla statusu „Nowy”, przyciski:
    - Akcji:
      - Powrót
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla statusu „Do akceptacji”, przyciski:
    - Akcji:
      - Powrót
      - Edytuj
      - Wyślij do ERP
      - Zwróć do magazynu
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla pozostałych statusów, przyciski przełączania widoków:
      - Powrót
      - Pokaż powiązane dokumenty
      - Logi

![3. Widok szczegółów akceptacji dokumentu wydania bezpośredniego.](\img\OIP.png)

3. Widok szczegółów akceptacji dokumentu wydania bezpośredniego.

## Kompletacje

W module „Kompletacje” będą znajdować się Kompletacji, wymagające akceptacji:

- Początkowej,

Dane na liście kompletacji:

- Numer dokumentu
- Status:
  - Anulowany
  - Do akceptacji
  - Do anulowania
  - Oczekuje na kompletacje
  - Oczekuje na przyjęcie
  - W przygotowaniu
  - Przerwano
  - W trakcie przesunięcia
  - Wersja robocza
  - Zakończony
- Produkty finalne
- Data utworzenia
- Data zakończenia
- Termin realizacji
- Nr dokumentu realizującego
- Przesunięcie
- Postęp realizacji
- Osoba blokująca
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Dokument realizujący
- Dokument przesunięcia
- Produkt
- Statusu:
  - Anulowany
  - Do akceptacji
  - Do anulowania
  - Oczekuje na kompletacje
  - Oczekuje na przyjęcie
  - W przygotowaniu
  - Przerwano
  - W trakcie przesunięcia
  - Wersja robocza
  - Zakończony
- Daty utworzenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Daty zakończenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Osoba blokująca

![4. Widok listy dokumentów kompletacji, wymagających akceptacji.](\img\Obrazy\Akceptacja_kompletacja.png)

4. Widok listy dokumentów kompletacji, wymagających akceptacji.

Widok szczegółów dokumentu akceptacji kompletacji zawiera:

- Numer dokumentu
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Pasek postępu obsługi dokumentu
- Sekcję „Komplety” z następującymi kolumnami
    - Typ
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
- Sekcję „Podstawowe informacje”, która wyświetla
  - Status dokumentu
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Termin realizacji
  - Datę zakończenia
  - Dokument przesunięcia
  - Uwagi
- Przyciski, których zestaw zależy od statusu dokumentu:
  - Dla statusu „Do akceptacji”, przyciski:
    - Akcji:
      - Zwróć do edycji
      - Anuluj
      - Przekaż do magazynu
      - Powrót
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla statusu „Wersja robocza”, przyciski:
    - Akcji:
      - Zapisz i przekaż do realizacji
      - Zapisz
      - Anuluj
      - Powrót
  - Dla statusu „W trakcie przesunięcia”, „W przygotowaniu”, „Przerwano” „ Oczekuje na przesunięcie”, „Oczekuje na kompletacje” przyciski:
    - Akcji:
      - Anuluj
      - Powrót
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla pozostałych statusów, przyciski przełączania widoków:
      - Powrót
      - Pokaż powiązane dokumenty
      - Logi

![5 Widok szczegółów kompletacji w widoku akceptacji](\img\OIP.png)

5 Widok szczegółów kompletacji w widoku akceptacji

## Dekompletacje

W module „Dekompletacje” będą znajdować się Dekompletacje, wymagające akceptacji:

- Początkowej,

Dane na liście dekompletacji:

- Numer dokumentu
- Status:
  - Anulowany
  - Do akceptacji
  - Do anulowania
  - Oczekuje na dekopletacje
  - Oczekuje na przyjęcie
  - W przygotowaniu
  - Przerwano
  - W trakcie przesunięcia
  - Wersja robocza
  - Zakończony
- Komplet
- Data utworzenia
- Data zakończenia
- Termin realizacji
- Nr dokumentu realizującego
- Przesunięcie
- Postęp realizacji
- Osoba blokująca
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Dokument realizujący
- Dokument przesunięcia
- Produkt
- Statusu:
  - Anulowany
  - Do akceptacji
  - Do anulowania
  - Oczekuje na dekompletacje
  - Oczekuje na przyjęcie
  - W przygotowaniu
  - Przerwano
  - W trakcie przesunięcia
  - Wersja robocza
  - Zakończony
- Daty utworzenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Daty zakończenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Osoba blokująca

![6. Widok listy dokumentów dekompletacji, wymagających akceptacji.](\img\Obrazy\Akceptacja_dekompletacja.png)

6. Widok listy dokumentów dekompletacji, wymagających akceptacji.

Widok szczegółów dokumentu akceptacji dekompletacji zawiera:

- Numer dokumentu
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Pasek postępu obsługi dokumentu
- Sekcję „Komplety” z następującymi kolumnami
    - Typ
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
- Sekcję „Podstawowe informacje”, która wyświetla
  - Status dokumentu
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Termin realizacji
  - Datę zakończenia
  - Dokument przesunięcia
  - Uwagi
- Przyciski, których zestaw zależy od statusu dokumentu:
  - Dla statusu „Do akceptacji”, przyciski:
    - Akcji:
      - Zwróć do edycji
      - Anuluj
      - Przekaż do magazynu
      - Powrót
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla statusu „Wersja robocza”, przyciski:
    - Akcji:
      - Zapisz i przekaż do realizacji
      - Zapisz
      - Anuluj
      - Powrót
  - Dla statusu „W trakcie przesunięcia”, „W przygotowaniu”, „Przerwano” „ Oczekuje na przesunięcie”, „Oczekuje na dekompletacje” przyciski:
    - Akcji:
      - Anuluj
      - Powrót
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla pozostałych statusów, przyciski przełączania widoków:
      - Powrót
      - Pokaż powiązane dokumenty
      - Logi

![7 Widok szczegółów dekompletacji w widoku akceptacji](\img\OIP.png)

7 Widok szczegółów dekompletacji w widoku akceptacji

## Reklamacje

W module „Reklamacje” będą znajdować się Reklamacje, wymagające akceptacji:

- Końcowej

Dane na liście reklamacji:

- Numer dokumentu
- Status:
  - Do weryfikacji
  - Oczekuje na przyjęcie
  - Oczekuje na wydanie
  - Odrzucono
  - W trakcie naprawy
  - W trakcie przyjęcia
  - W trakcie wydania
  - Zaakceptowano
  - Zakończono
  - Zarejestrowano
- Kontrahent
- Data zgłoszenia
- Data utworzenia
- Data zakończenia
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Dokument sprzedaży
- Statusu:
  - Do weryfikacji
  - Oczekuje na przyjęcie
  - Oczekuje na wydanie
  - Odrzucono
  - W trakcie naprawy
  - W trakcie przyjęcia
  - W trakcie wydania
  - Zaakceptowano
  - Zakończono
  - Zarejestrowano
- Data zgłoszenia
- Daty utworzenia
- Daty zakończenia
- Żądanie reklamującego
  - Wymiana towaru
  - Naprawa
  - Zwrot pieniędzy

![8. Widok listy dokumentów reklamacji, wymagających akceptacji.](\img\Obrazy\Akceptacja_reklamacja.png)

8. Widok listy dokumentów reklamacji, wymagających akceptacji.

Widok szczegółów dokumentu akceptacji reklamacji zawiera:

- Numer dokumentu
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Sekcję „Towary” z następującymi kolumnami
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość ma dokumencie sprzedaży
    - Ilość reklamowana
    - Ilość przyjęta
    - JM
- Sekcję „Podstawowe informacje”, która wyświetla
  - Kontrahenta
  - Status
  - Numer dokumentu sprzedaży
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Żądanie reklamującego
  - Data powstania wady
  - Data zgłoszenia
  - Datę zakończenia
  - Sposób odesłania zgłaszanego towaru
  - Opis usterki
  - Uwagi
  - Załącznik
- Przyciski, których zestaw zależy od statusu dokumentu:
  - Dla statusu „Do akceptacji”, przyciski:
    - Akcji:
      - Zwróć do magazynu
      - Akceptuj
      - Powrót
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla statusu „Do weryfikacji”, przyciski:
    - Akcji:
      - Zatwierdź
      - Odrzuć
      - Powrót
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla statusu „W trakcie naprawy” i „Zaakceptowano”,, przyciski:
    - Akcji:
      - Przekaz do wydania
      - Odrzuć
      - Powrót
    - Dodatkowe informacje:
      - Pokaż powiązane dokumenty
      - Logi
  - Dla pozostałych statusów, przyciski przełączania widoków:
      - Powrót
      - Pokaż powiązane dokumenty
      - Logi

![9 Widok szczegółów reklamacji w widoku akceptacji](\img\OIP.png)

9 Widok szczegółów reklamacji w widoku akceptacji
