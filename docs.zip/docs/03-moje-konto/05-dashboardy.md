---
title: "Dashboardy"
sidebar_label: "3.5. Dashboardy"
---

Z poziomu zakładki Dashboardy użytkownik może konfigurować spersonalizowane raporty prezentowane na stronie głównej. Układ strony głównej można dostosować poprzez dodawanie predefiniowanych widżetów, które wizualizują kluczowe dane systemowe.

![ Przykładowe okno " Dashboardy", w systemie Asiston WMS.](\img\Obrazy\Dashboardy.png)

 Przykładowe okno " Dashboardy", w systemie Asiston WMS.
