---
title: "Profil użytkownika"
sidebar_label: "3.1. Profil użytkownika"
---

„Moje konto/Profil użytkownika” służy do zarządzania podstawowymi informacjami, tj.: imię, nazwisko, adres e-mail. Możliwe jest również dodanie zdjęcia profilowego.

![ Przykładowy widok profilu użytkownika, w systemie Asiston WMS.](\img\Obrazy\Profil.png)

 Przykładowy widok profilu użytkownika, w systemie Asiston WMS.
