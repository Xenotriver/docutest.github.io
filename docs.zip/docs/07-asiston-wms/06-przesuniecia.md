---
title: "Przesunięcia"
sidebar_label: "7.6. Przesunięcia"
---

Przesunięcie to operacja magazynowa, polegająca na przemieszczeniu towaru z jednej lokalizacji do innej, w tym samym magazynie lub między różnymi magazynami. Wyróżniamy dwa rodzaje przesunięć:

1. Awizowane – dokonywane na podstawie dokumentu zlecenia zmiany lokalizacji (ZZL), utworzonego w systemie Asiston WMS,
1. Szybkie – nie wymagające awizowania.

## Zlecenie zmiany lokalizacji

Po przejściu do listy przesunięć, użytkownik będzie miał widok listy utworzonych dokumentów zlecenia zmiany lokalizacji ZZL.

Lista będzie zawierać kolumny:

- Nr dokumentu,
- Status:
  - Wersja robocza
  - W przygotowaniu
  - Oczekuje na przesunięcie
  - Przerwano
  - W trakcie (dokument powstały po niezrealizowanym Szybkim przesunięciu dwuetapowym)
  - Anulowany
  - Zakończony
- Z magazynu,
- Do magazynu,
- Data utworzenia,
- Data zakończenia,
- Nr dokumentu realizującego,
- Rodzaj,
- Osoba blokująca,
- Postęp,
- Przycisk akcji: „Szczegóły”.

Filtrowanie listy możliwe będzie wg następujących kryteriów:

- Nr dokumentu,
- Status:
  - Wersja robocza
  - W przygotowaniu
  - Oczekuje na przesunięcie
  - Przerwano
  - W trakcie
  - Anulowane
  - Zakończony
- Z magazynu,
- Do magazynu,
- Data utworzenia,
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Data zakończenia,
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Nr dokumentu realizującego - np. MM w przypadku przesunięcia międzymagazynowego,
- Rodzaj,
- Osoba blokująca.
- Priorytet

![0. Przykładowy widok listy zleceń zmiany lokalizacji.](\img\OIP.png)

0. Przykładowy widok listy zleceń zmiany lokalizacji.

### Tworzenie zlecenia przesunięcia

Nowe zlecenie przesunięcia będzie można utworzyć, używając przycisku „Utwórz zlecenie”, w widoku listy zleceń. System wyświetli formularz tworzenia zlecenia z kolejnym numerem, nadanym automatycznie. W formularzu należy wybrać:

- Nazwę towaru do przesunięcia (wybrać z listy rozwijanej lub wpisać ręcznie),
  - W widoku formularza system zwróci sekcję, ze wszystkimi lokalizacjami, na których dany towar znajduje się w magazynie. Dla każdej lokalizacji towaru wyświetli dodatkowo:
    - Nośnik,
    - Partię,
    - Ilość,
    - Jednostkę miary (JM).
- Partię,
- Ilość do przesunięcia,
- Jednostkę miary (z listy rozwijanej)
- Lokalizację początkową i końcową z listy rozwijanej.

System wyświetli dane towaru do przesunięcia. Po kliknięciu przycisku „Dodaj” system doda towar do listy towarów, do przesunięcia w tym zleceniu. Towar, na liście do przesunięcia, będzie miał następujące dane:

- Zdjęcie towaru,
- Symbol,
- Nazwa,
- Kod towaru,
- Ilość (wybrana do przesunięcia),
- JM (jednostka miary).

Widok towaru, dodanego do listy przesunięcia, może być rozwinięty przyciskiem, o następujące dane:

- Lokalizacja początkowa,
- Ilość,
- JM,
- Partia,
- Lokalizacja końcowa.

Dodany towar można również usunąć z listy. Można dodać kilka towarów do przesunięcia, w tworzonym dokumencie zlecenia przesunięcia.

Przed zapisaniem będą dostępne opcjonalnie pola do uzupełnienia::

- Termin realizacji,
- Rodzaj (przesunięcia):
  - Normalne,
  - Międzymagazynowe
- Wymuszaj przesunięcie do lokalizacji końcowej
- Priorytet
- Uwagi (jeśli potrzebne są dodatkowe informacje do obsługi przesunięcia)

Zlecenie będzie można zapisać przyciskami:

- Zapisz (na liście zlecenie będzie miało status „Wersja robocza”)
- Zapisz i przekaż do realizacji (na liście zlecenie otrzyma status „Oczekuje na przesunięcie”).

![1. Widok tworzenia zlecenia przesunięcia w systemie Asiston WMS.](\img\OIP.png)

1. Widok tworzenia zlecenia przesunięcia w systemie Asiston WMS.

### Realizacja zlecenia przesunięcia

Po otwarciu dokumentu ZZL, ze statusem „Oczekuje na przesunięcie” i kliknięciu przycisku „Rozpocznij przesunięcie”, dokument zmieni status na „W przygotowaniu”. Górna część widoku szczegółów dokumentu, będzie zawierać:

- Numer dokumentu
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Pasek postępu obsługi dokumentu
- Sekcję skanowania „Zeskanuj pozycję” z przyciskami wyboru sposobu obsługi przesunięcia:
  - Jednoetapowe
  - Dwuetapowe

Przesunięcie jednoetapowe zmienia położenie towaru bezpośrednio z lokalizacji początkowej do lokalizacji końcowej. Widok sekcji skanowania zawiera:

- Pola:
  - Lokalizacja początkowa
  - Nośnik początkowy
  - Kod towaru
  - Partia
  - Ilość
  - Nośnik końcowy
  - Lokalizacja końcowa
- Przyciski ukrywania:
  - Ukryj nośnik początkowy
  - Ukryj nośnik końcowy
  - Ukryj partie
  - Ukryj ilość
  - Resetuj (resetuje zawartość pól w sekcji skanowania)

Przesunięcie dwuetapowe przechodzi przez dwie fazy:

1. Zbierania towarów do przesunięcia z lokalizacji początkowych,
1. Rozkładania towarów do lokalizacji końcowych

Sekcja skanowania – w tym widoku – zawiera:

1. Na etapie zbierania:
- Pola:
  - Lokalizacja początkowa
  - Nośnik początkowy
  - Kod towaru
  - Partia
  - Ilość
- Przyciski ukrywania:
  - Ukryj nośnik początkowy
  - Ukryj partie
  - Ukryj ilość
  - Resetuj (resetuje zawartość pól w sekcji skanowania)
- Przycisk „Dodaj” (dodaje awizowane towary do zbierania) w przesunięciu dwuetapowym
- Przycisk „Przesuń” (dodaje awizowane towary przesunięte) w przesunięciu jednoetapowym
1. Na etapie rozkładania:
- Pola:
  - Lokalizacja końcowa
  - Nośnik końcowy
  - Kod towaru
  - Partia
  - Ilość
- Przyciski ukrywania:
  - Ukryj nośnik końcowy
  - Ukryj partie
  - Ukryj ilość
  - Resetuj (resetuje zawartość pól w sekcji skanowania)
- Przycisk „Przesuń” (dodaje awizowane towary do rozkładania)

Widok szczegółów dokumentu ZZL wyświetla również sekcję „Towary” z następującymi elementami:

  - Przycisk „Zbierz towary”/Rozłóż towary” – jeśli w sekcji skanowania zostało wybrane przesunięcie dwuetapowe
  - Pole wyszukiwania po frazie z dowolnej kolumny na liście
  - Listę awizowanych towarów w dokumencie, lista ma następujące kolumny:
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
    - Partia
    - Lokalizacja początkowa
    - Lokalizacja końcowa
    - Przycisk drukowania etykiety
    - Przycisk podglądu lokalizacji produktu
    - Przycisk pola rozwijanego z następującymi danymi:
      - Jednoetapowo (dane przesunięcia jednoetapowego):
        - Lokalizacja początkowa
        - Nośnik początkowy
        - Ilość
        - JM
        - Lokalizacja końcowa
        - Nośnik końcowy
      - Zbieranie:
        - Lokalizacja
        - Nośnik
        - Ilość
        - JM
      - Rozkładanie:
        - Lokalizacja
        - Nośnik
        - Ilość
        - JM

Sekcję „Podstawowe informacje” wyświetla

  - Status dokumentu
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Termin realizacji
  - Datę zakończenia
  - Rodzaj
  - Uwagi do przesunięcia
  - Pole „Uwagi”, magazynier, obsługujący przesunięcie, może wpisać uwagi.

Po wykonaniu przesunięcia awizowanych towarów (dokument podświetla się na kolor zielony), można zakończyć przesunięcie przyciskiem „Zakończ”. Przed zakończeniem można także użyć przycisku „Przerwij”, który powoduje przerwanie przyjęcia i zwraca dokument na listę dokumentów ZZL, ze statusem „Przerwano”.

![2. Widok szczegółów dokumentu ZZL.](\img\OIP.png)

2. Widok szczegółów dokumentu ZZL.

## Szybkie przesunięcia

Szybkie przesunięcie to zmiana lokalizacji towaru w magazynie, wykonywana od razu, tzn. bez awizowania dokumentem „ZZL” (zlecenia zmiany lokalizacji).

Górna część widoku będzie zawierać sekcję skanowania „Zeskanuj pozycję” z przyciskami wyboru sposobu obsługi przesunięcia:

  - Jednoetapowe
  - Dwuetapowe

Przesunięcie jednoetapowe zmienia położenie towaru bezpośrednio z lokalizacji początkowej do lokalizacji końcowej. Widok sekcji skanowania wyświetla:

- Pola:
  - Lokalizacja początkowa
  - Nośnik początkowy
  - Kod towaru
  - Partia
  - Ilość
  - Nośnik końcowy
  - Lokalizacja końcowa
- Przyciski ukrywania:
  - Ukryj nośnik początkowy
  - Ukryj nośnik końcowy
  - Ukryj partię
  - Ukryj ilość
  - Resetuj (resetuje zawartość pól w sekcji skanowania)

Przesunięcie dwuetapowe - podobnie jak w przesunięciach awizowanych - przechodzi przez dwie fazy:

1. Zbierania towarów do przesunięcia z lokalizacji początkowych,
1. Rozkładania towarów do lokalizacji końcowych

Sekcja skanowania – w tym widoku – zawiera:

1. Na etapie zbierania:
- Pola:
  - Lokalizacja początkowa
  - Nośnik początkowy
  - Kod towaru
  - Partia
  - Ilość
- Przyciski ukrywania:
  - Ukryj nośnik początkowy
  - Ukryj partie
  - Ukryj ilość
  - Resetuj (resetuje zawartość pól w sekcji skanowania)
- Przycisk „Dodaj” (dodaje awizowane towary do zbierania)
1. Na etapie rozkładania:
- Pola:
  - Lokalizacja końcowa
  - Nośnik końcowy
  - Kod towaru
  - Partia
  - Ilość
- Przyciski ukrywania:
  - Ukryj nośnik końcowy
  - Ukryj partie
  - Ukryj ilość
  - Resetuj (resetuje zawartość pól w sekcji skanowania)
- Przycisk „Dodaj” (dodaje awizowane towary do rozkładania)

W sekcji „Towary” widoczne będą następujące elementy:

  - Przycisk „Zbieraj towary”/Rozłóż towary” – jeśli w sekcji skanowania zostało wybrane przesunięcie dwuetapowe
  - Pole wyszukiwania po frazie z dowolnej kolumny na liście
  - Listę towarów w dokumencie, lista ma następujące kolumny:
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
    - Przycisk drukowania etykiety
    - Przycisk pola rozwijanego z następującymi danymi:
      - Zbieranie:
        - Lokalizacja
        - Nośnik
        - Ilość
        - Partia
        - JM
      - Rozkładanie:
        - Lokalizacja
        - Nośnik
        - Ilość
        - Partia
        - JM

![3. Widok szybkiego przesunięcia jednoetapowego, w systemie Asiston WMS.](\img\OIP.png)

3. Widok szybkiego przesunięcia jednoetapowego, w systemie Asiston WMS.

![4. Widok szybkiego przesunięcia dwuetapowego, etap zbierania.](\img\OIP.png)

4. Widok szybkiego przesunięcia dwuetapowego, etap zbierania.

![5.  Widok szybkiego przesunięcia dwuetapowego, etap rozkładania.](\img\OIP.png)

5.  Widok szybkiego przesunięcia dwuetapowego, etap rozkładania.

Pola lokalizacji, partii i nośników można zablokować, wówczas nie będzie możliwa zmiana ich zawartości. Możliwe będzie również nieuzupełnienie pól formularza, w sytuacjach, z których wybrane zostały opisane poniżej.

| Nazwa nieuzupełnionego pola (pozostałe uzupełnione) | Warunek nieuzupełnienia pola |
| --- | --- |
| Kod towaru | Przesuwamy wszystkie towary z nośnika z danej lokalizacji na drugą lokalizację z nośnikiem. |
| Lokalizacja początkowa | Przesuwamy towar z nośnika na lokalizację z nośnikiem. |
| Nośnik początkowy | Przesuwamy towar z lokalizacji (bez nośnika) na lokalizację z nośnikiem. |
| Lokalizacja końcowa | Przesuwamy towar z nośnika z danej lokalizacji do drugiego nośnika, pod warunkiem że drugi nośnik jest umieszczony na lokalizacji. |
| Nośnik końcowy | Przesuwamy towar z nośnika z danej lokalizacji do drugiej lokalizacji (bez nośnika). |
