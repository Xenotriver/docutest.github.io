---
title: "Kontrola jakości"
sidebar_label: "7.5. Kontrola jakości"
---

W module „Kontroli jakości” będą znajdować się dokumenty kontroli jakości, tworzone na podstawie zakończonych dokumentów z przyjęć awizowanych.

Dane na liście przyjęć:

- Numer kontroli jakości
- Status:
  - Bufor
  - Nowy
  - Przerwano
  - W przygotowaniu
  - Zakończony
- Dostawca
- Data utworzenia
- Data wykonania
- Dokument powiązany z przyjęcia
- Postęp realizacji
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru kontroli jakości – wyszukiwanie po znakach
- Dostawcy – wyszukiwanie po nazwie
- Statusu – wybór z listy rozwijanej:
  - Bufor
  - Nowy
  - Przerwano
  - W przygotowaniu
  - Zakończony
- Daty utworzenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Daty zakończenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)

![7. Widok listy kontroli jakości w systemie Asiston.](\img\OIP.png)

7. Widok listy kontroli jakości w systemie Asiston.

Widok szczegółów dokumentu kontroli jakości zawiera:

- Numer dokumentu,
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Pasek postępu w obsłudze dokumentu,
- Sekcję z listą towarów do kontroli jakości, sekcja zawiera:
  - Pole wyszukiwania frazy z dowolnej kolumny na liście,
  - Listę towarów z następującymi kolumnami:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Lokalizacja
    - Nośnik
    - Ilość przyjęta
    - JM
    - Ikonka wydruku etykiety
    - Przycisk „Sprawdź”
    - Przycisk widoku rozwijanego, który dla danego towaru zwraca dane o:
      - Statusie
      - Ilości
      - JM
      - Uwagach
      - Ikonkę usuwania
- Sekcję „Podstawowe informacje”, która wyświetla
  - Dostawcę
  - Status dokumentu
  - Dokument powiązany
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Datę zakończenia
  - Pole „Uwagi”, tu magazynier może wpisać uwagi, przy kontroli.

W nawigacji dokumentu dostępny jest przycisk „Przesuń towary”, który umożliwia użytkownikowi przesunięcie towarów do lokalizacji kontroli jakości.

Bieżącą prace z dokumentem można zakończyć przyciskami:

- Zakończ kontrolę
- Przerwij
- Powrót

![8. Widok szczegółów dokumentu kontroli jakości – sekcja „Towary”](\img\OIP.png)

8. Widok szczegółów dokumentu kontroli jakości – sekcja „Towary”

![9. Widok szczegółów dokumentu przyjęcia awizowanego – sekcja "Podstawowe informacje".](\img\OIP.png)

9. Widok szczegółów dokumentu przyjęcia awizowanego – sekcja "Podstawowe informacje".


## Opisy procesów kontroli jakości

#### Kontrola jakości prosta

![Diagram 11. Kontrola jakości - prosta.](\img\OIP.png)

Diagram 11. Kontrola jakości - prosta.

Po zakończeniu przyjęcia w widoku magazynowym automatycznie utworzy się dokument kontroli jakości. Dokument ten zostanie umieszczony na liście ze statusem „Nowy”. Magazynier, rozpoczynając realizację kontroli, zablokuje dokument, który wówczas automatycznie otrzyma status "W przygotowaniu". Na podstawie listy produktów, które podlegają kontroli, magazynier zweryfikuje ich jakość. Dla każdej pozycji, po wybraniu przycisku „Sprawdź”, Magazynier wprowadza zweryfikowaną ilość towaru oraz określa jej zgodność z przyjętymi kryteriami oceny. Może wybrać jedną z dwóch opcji: „Zgodna” lub „Niezgodna”. Magazynier może zlecić przesunięcie towaru na inną lokalizację bezpośrednio z poziomu dokumentu kontroli. Po sprawdzeniu wszystkich pozycji kończy kontrolę, klikając przycisk „Zakończ kontrolę”, co powoduje zmianę statusu dokumentu na „Zakończony”.

#### Kontrola jakości zaawansowana

![Diagram 12. Kontrola jakości - zaawansowana.](\img\OIP.png)

Diagram 12. Kontrola jakości - zaawansowana.

Po zakończeniu przyjęcia w widoku magazynowym automatycznie utworzy się dokument kontroli jakości, a stan towaru zostanie zablokowany w systemie WMS. Dokument zostanie umieszczony na liście kontroli ze statusem „Nowy”. Magazynier, rozpoczynając realizację kontroli, zablokuje dokument, który wówczas automatycznie otrzyma status "W przygotowaniu". Na podstawie listy produktów, które podlegają kontroli, magazynier zweryfikuje ich jakość. Dla każdej pozycji, po wybraniu przycisku „Sprawdź”, Magazynier wprowadza zweryfikowaną ilość towaru oraz określa jej zgodność z przyjętymi kryteriami oceny. Może wybrać jedną z dwóch opcji: „Zgodna” lub „Niezgodna”. Magazynier może zlecić przesunięcie towaru na inną lokalizację bezpośrednio z poziomu dokumentu kontroli. Po sprawdzeniu wszystkich pozycji kończy kontrolę, klikając przycisk „Zakończ kontrolę”, co powoduje zmianę statusu dokumentu na „Zakończony” oraz odblokowanie towaru w systemie WMS.
