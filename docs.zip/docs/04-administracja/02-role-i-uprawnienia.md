---
title: "Role i uprawnienia"
sidebar_label: "4.2. Role i uprawnienia"
---

Każdemu użytkownikowi będą przydzielane uprawnienia w systemie Asiston. Zakres tych ról uprawnień ustalany będzie przez administratora systemu. Role uprawnień zostaną ustalone podczas wdrożenia systemu.

Lista ról uprawnień zawiera takie informacje jak:

- Nazwa roli,
- Data dodania,
- Domyślna:
  - Tak
  - Nie,
- Aktywna:
  - Tak
  - Nie
- Akcje:
  - Użytkownicy w tej roli,
  - Edytuj
  - Usuń.

Listę uprawnień można filtrować wg:

- Nazwy roli,
- Data dodania użytkownika
- Roli domyślnej: True/False,
- Roli aktywnej: True/False.

![. Przykładowy widok listy ról uprawnień, w systemie Asiston WMS.](\img\Obrazy\Role_uprawnienia.png)

 Przykładowy widok listy ról uprawnień, w systemie Asiston WMS.

Dodanie roli nastąpi przyciskiem „Dodaj rolę”. System zwróci widok, w którym będzie należało:

- Wpisać nazwę roli,
- Zaznaczyć checkbox „Rola aktywna” i/lub „Rola domyślna”,
- Dodać uprawnienia z listy w sekcji po prawej stronie, stosownie do przewidywanego zakresu roli.

![. Widok dodawania roli uprawnień w systemie Asiston WMS.](\img\Obrazy\Dodanie_roli.png)

 Widok dodawania roli uprawnień w systemie Asiston WMS.

Opis ról uprawnień:

**Ustawienia ogólne**

- **Dostęp do panelu administracyjnego** - Uprawnienie pozwalająca na dostęp do zalogowania się do systemu.
- **Pełne uprawnienia administracyjne** - Jest to nadrzędne uprawnienie, które daje użytkownikowi pełny i nieograniczony dostęp do wszystkich funkcji i ustawień w panelu administracyjnym. Obejmuje to zarządzanie kontami, rolami, bezpieczeństwem, powiadomieniami oraz wszystkimi innymi konfiguracjami systemowymi.

**Administracja \ Użytkownicy**

- **Dostęp do modułu zarządzania użytkownikami** - Umożliwia dostęp do widoku "Administracja / Użytkownicy". Użytkownik może przeglądać listę wszystkich kont w systemie, widząc ich podstawowe dane oraz korzystać z opcji filtrowania listy według różnych kryteriów.
- **Dodawanie i edycja użytkowników** - Aktywuje przycisk "Dodaj użytkownika" oraz akcję "Edytuj" na liście użytkowników. Pozwala na tworzenie nowych kont oraz modyfikację istniejących.
- **Usuwanie użytkowników** - Aktywuje akcję "Usuń" na liście użytkowników, umożliwiając trwałe usunięcie konta z systemu.
- **Eksportowanie i importowanie użytkowników** - Umożliwia trwałe usuwanie kont użytkowników z systemu.

**Administracja \ Role i uprawnienia**

- **Dostęp do modułu zarządzania rolami** - Zapewnia dostęp do sekcji "Administracja / Role i uprawnienia", gdzie użytkownik może przeglądać listę zdefiniowanych ról oraz ich status.
- **Dodawanie i edycja ról** - Umożliwia tworzenie nowych ról oraz modyfikację istniejących. Kluczowa funkcja polega na przypisywaniu lub odbieraniu szczegółowych uprawnień do danej roli, co definiuje jej zakres działania w systemie.
- **Usuwanie ról** - Aktywuje akcję "Usuń" na liście ról, pozwalając na usunięcie nieużywanych lub błędnie skonfigurowanych ról.

**Administracja \ Monitoring \ Harmonogram zadań**

- **Dostęp do harmonogramu zadań** - Umożliwia wgląd w listę zadań cyklicznych wykonywanych automatycznie przez system (np. synchronizacje danych, generowanie raportów, czyszczenie logów) w module "Administracja / Monitoring / Harmonogram zadań".
- **Włączanie i wyłączanie zadań** - Pozwala na zmianę statusu "Aktywne" dla zadań w harmonogramie, co umożliwia tymczasowe zatrzymanie lub wznowienie automatycznych procesów systemowych.
- **Uruchamianie zadań** - Aktywuje akcję "Uruchom zadanie", pozwalając na manualne wyzwolenie zadania poza jego standardowym harmonogramem, na przykład w celu testowania lub natychmiastowej synchronizacji danych.

**Administracja \ Monitoring \ Monitor kolejek**

- **Dostęp do monitora zadań** - Zapewnia dostęp do modułu "Administracja / Monitoring / Monitor kolejek", który prezentuje wszystkie zadania wykonane przez system w tle, takie jak komunikacja z systemem ERP czy generowanie dokumentów.
- **Ponawianie zadań** - Umożliwia ponowne uruchomienie zadań, które zakończyły się błędem.

**Administracja \ Ustawienia \ Powiadomienia**

- **Dostęp do modułu zarządzania powiadomieniami** - Zapewnia dostęp do sekcji "Administracja / Ustawienia / Szablony powiadomień", gdzie można zarządzać szablonami powiadomień systemowych wysyłanych do użytkowników różnymi kanałami (e-mail, push).
- **Dodawanie i edycja powiadomień** - Umożliwia tworzenie i modyfikację szablonów powiadomień, w tym definiowanie ich nazwy, kategorii, typu, treści oraz kanałów komunikacji.
- **Usuwanie powiadomień** - Pozwala na usuwanie zbędnych lub nieaktualnych szablonów powiadomień.
- **Akceptacja wersji** - Pozwala na akceptację nowych wersji powiadomień.

**Administracja \ Ustawienia \ Centrum powiadomień**

- **Dostęp do modułu centrum powiadomień** - Zapewnia dostęp do modułu "Moje konto / Centrum powiadomień" z perspektywy administratora, co umożliwia zarządzanie powiadomieniami.
- **Dodawanie i edycja powiadomień zbiorowych** - Umożliwia tworzenie i wysyłanie masowych komunikatów do określonych grup użytkowników lub wszystkich użytkowników systemu.
- **Usuwanie powiadomień zbiorowych** - Pozwala na zarządzanie historią wysłanych powiadomień masowych, np. usuwanie nieaktualnych ogłoszeń.

**Administracja \ Pozostałe uprawnienia**

- **Dostęp do konfiguracji zasad bezpieczeństwa** - Umożliwia dostęp do sekcji "Administracja / Ustawienia / Bezpieczeństwo", gdzie administrator konfiguruje politykę haseł (minimalna długość, znaki specjalne) oraz zasady blokowania kont po nieudanych próbach logowania.
- **Dostęp do konfiguracji poczty** - Zapewnia dostęp do sekcji "Administracja / Ustawienia / Poczta", umożliwiając konfigurację serwera SMTP wymaganego do wysyłania powiadomień e-mail z systemu.
- **Dostęp do ustawień sesji** - Zapewnia dostęp do sekcji "Administracja / Ustawienia / Ustawienia sesji", pozwalając na konfigurację parametrów sesji użytkowników, takich jak czas jej trwania i wygaśnięcia.
- **Dostęp do konfiguracji monitoringu** - pozwala na konfigurację parametrów modułów monitorujących z zakresu historii logowania czy harmonogramu zadań.
- **Dostęp do konfiguracji logów** - Uprawnienie to pozwala na konfigurację poziomu szczegółowości logowania zdarzeń systemowych.
- **Dostęp do historii logowania** - Umożliwia dostęp do globalnego rejestru logowań wszystkich użytkowników w sekcji "Administracja / Monitoring / Historia logowania". W przeciwieństwie do wglądu tylko we własną historię w "Moje konto", to uprawnienie daje pełny obraz aktywności logowania w całym systemie.
- **Dostęp do rejestru zmian** - Zapewnia dostęp do modułu "Administracja / Monitoring / Rejestr zmian", który jest kluczowym narzędziem audytowym. Śledzi on wszystkie modyfikacje (dodanie, edycja) obiektów w systemie dokonane przez użytkowników, rejestrując kto, co i kiedy zmienił.
- **Pobieranie i zmiana konfiguracji LDAP** - Umożliwia zarządzanie integracją z usługą katalogową (np. Active Directory) w sekcji "Administracja / Ustawienia / Źródła LDAP". Pozwala na dodawanie, edycję i synchronizację użytkowników i grup z zewnętrznego źródła.
- **Dostęp do konfiguracji palety kolorów** - Zapewnia dostęp do sekcji "Administracja / Ustawienia / Paleta kolorów", pozwalając na dostosowanie wyglądu interfejsu systemu (kolory tła, tekstu, menu) do identyfikacji wizualnej firmy.

**Dashboardy**

- **Dostęp do** **dashboardów** - Umożliwia użytkownikowi dostęp do strony głównej systemu (pulpitu), na której wyświetlane są spersonalizowane widgety z kluczowymi danymi systemowymi i statystykami.
- **Dodawanie i edycja** **dashboardów** - Pozwala użytkownikowi na personalizację swojego pulpitu poprzez dodawanie, usuwanie i konfigurowanie dostępnych widgetów (np. Bestsellery, Użytkownicy online, Liczba niezakończonych wydań) w module "Moje konto / Dashboardy".
- **Usuwanie** **dashboardów** - Umożliwia usuwanie niestandardowych konfiguracji pulpitów stworzonych przez użytkownika.

**Wydania \ Listy przewozowe**

- **Może drukować więcej niż 1 raz dany list przewozowy** - system blokuje możliwość wielokrotnego drukowania tego samego listu przewozowego, aby uniknąć pomyłek. To uprawnienie znosi tę blokadę.

**Wydania \ Zbieranie zagregowane**

- **Usuwanie ZK z dokumentu zagregowanego** - Pozwala użytkownikowi na usunięcie pojedynczego zamówienia klienta (ZK) z utworzonego wcześniej zagregowanego dokumentu zbierania..

**Repozytorium plików**

- **Dostęp do repozytorium plików** - Zapewnia dostęp do modułu "Repozytorium plików", który służy jako centralne miejsce do przechowywania i zarządzania dokumentami (np. instrukcjami, specyfikacjami).
- **Przeglądanie zawartości katalogów** - Podstawowe uprawnienie do nawigacji po strukturze folderów w repozytorium i przeglądania ich zawartości.
- **Dodawanie i edycja plików i katalogów** - Umożliwia tworzenie nowych folderów oraz przesyłanie i modyfikowanie plików (np. .pdf, .docx, .jpg). Pozwala również na zmianę nazwy istniejących plików i katalogów.
- **Usuwanie plików i katalogów** - Pozwala na trwałe usuwanie plików i całych katalogów z repozytorium.
- **Nadawanie uprawnień do katalogów** – Umożliwia nadawanie uprawnień użytkownikom, którzy mają mieć dostęp do danego katalogu.

**Akceptacje**

- **Dostęp do modułu akceptacje** - Uprawnienie nadrzędne, które daje dostęp do głównej sekcji "Akceptacje" w menu systemu. Umożliwia przeglądanie dokumentów oczekujących na akceptację.
- **Dostęp do modułu przyjęcia awizowane** - Umożliwia dostęp do listy dokumentów przyjęć awizowanych, które wymagają akceptacji (początkowej, końcowej lub obu). Użytkownik może przeglądać, edytować i zatwierdzać te dokumenty, przekazując je do realizacji w magazynie lub odsyłając do korekty.
- **Dostęp do modułu przyjęcia bezpośrednie** - Zapewnia dostęp do listy dokumentów przyjęć bezpośrednich wymagających końcowej akceptacji po ich utworzeniu i realizacji w magazynie.
- **Dostęp do modułu wydań** - Umożliwia dostęp do listy dokumentów wydań, które wymagają akceptacji. Użytkownik może weryfikować dane zamówienia, kontrahenta, warunki dostawy, a następnie przekazać dokument do magazynu do realizacji.
- **Dostęp do modułu wydania bezpośrednie** - Zapewnia dostęp do listy dokumentów wydań bezpośrednich, które wymagają końcowej akceptacji.
- **Dostęp do modułu kompletacji** - Umożliwia dostęp do listy zleceń kompletacji, które wymagają akceptacji przed przekazaniem ich do realizacji w magazynie.
- **Dostęp do modułu reklamacji** - Zapewnia dostęp do modułu akceptacji reklamacji, gdzie użytkownik weryfikuje i zatwierdza poszczególne etapy procesu reklamacyjnego.
- **Dostęp do modułu zadań dodatkowych** - Zapewnia dostęp do modułu zadań dodatkowych, gdzie można zlecić nowe zadanie lub sprawdzić jego szczegóły.

**Komplety**

- **Dostęp do modułu kompletów** - Uprawnienie nadrzędne, dające dostęp do głównej sekcji "Komplety" w menu systemu.
- **Dostęp do modułu kompletacji** - Umożliwia tworzenie i realizację zleceń kompletacji, czyli łączenia kilku towarów składowych w jeden gotowy produkt (zestaw).
- **Dostęp do modułu dekompletacji** - Pozwala na tworzenie i realizację zleceń dekompletacji, czyli procesu odwrotnego – rozkładania zestawu na jego poszczególne elementy składowe.

**Przyjęcia**

- **Dostęp do modułu przyjęcia** - Uprawnienie nadrzędne, dające dostęp do sekcji "Przyjęcia" w menu, która grupuje wszystkie typy operacji przyjęć.
- **Dostęp do modułu przyjęcia awizowane** - Umożliwia magazynierowi dostęp do listy awizowanych przyjęć i ich realizację poprzez skanowanie towarów, lokalizacji i nośników.
- **Dostęp do modułu przyjęcia bezpośrednie** - Pozwala na tworzenie i realizację dokumentów przyjęć bezpośrednio w systemie WMS, bez wcześniejszej awizacji z systemu ERP.
- **Dostęp do modułu kalendarz** - Zapewnia wgląd w graficzny kalendarz awizowanych przyjęć. Użytkownik może zobaczyć zaplanowane dostawy w widoku dnia, tygodnia lub miesiąca.
- **Zbiorcze skanowanie ZD** – Umożliwia dostęp do używania przycisku zbiorczego skanowania w dokumencie przyjęcia awizowanego.

**Przesunięcia**

- **Dostęp do modułu przesunięcia** - Uprawnienie nadrzędne dla wszystkich operacji związanych z przesunięciami międzymagazynowymi i wewnątrzmagazynowymi.
- **Dostęp do modułu listy przesunięć** - Umożliwia dostęp do listy zleceń zmiany lokalizacji i ich realizację. Proces ten jest awizowany i opiera się na wcześniej utworzonym dokumencie.
- **Dostęp do modułu szybkich przesunięć** - Pozwala na wykonywanie nieawizowanych, ad-hoc'owych przesunięć towarów poprzez proste zeskanowanie towaru, lokalizacji początkowej i końcowej.
- **Tworzenie zleceń** - Umożliwia tworzenie nowych dokumentów zlecenia zmiany lokalizacji (ZZL), które następnie trafiają na listę przesunięć do realizacji przez magazynierów.

**Wydania**

- **Dostęp do modułu wydań** - Uprawnienie nadrzędne, dające dostęp do sekcji "Wydania" w menu, która grupuje wszystkie typy operacji wydań.
- **Dostęp do modułu zbieranie** - Pozwala na realizację etapu zbierania (kompletacji) towarów z lokalizacji magazynowych na podstawie dokumentu wydania.
- **Dostęp do modułu pakowanie** - Umożliwia dostęp do etapu pakowania, gdzie zebrane towary są weryfikowane, pakowane do opakowań zbiorczych i przygotowywane do wysyłki. Użytkownik może również generować etykiety i listy przewozowe.
- **Dostęp do modułu wydanie do kuriera** - Zapewnia dostęp do interfejsu obsługi wydań do kurierów, gdzie spakowane paczki są skanowane i formalnie przekazywane przewoźnikowi.
- **Dostęp do modułu odbioru osobistego** - Pozwala na obsługę wydań dla klientów odbierających towar osobiście w magazynie.
- **Dostęp do modułu wydania bezpośrednie** - Umożliwia tworzenie i realizację dokumentów wydań bezpośrednio w systemie WMS bez awizacji z systemu ERP.
- **Może cofać paczki po zakończeniu wydania** – Uprawnienie pozwalające na wycofanie paczek po formalnym zakończeniu procesu pakowania jeśli zostało zamówienie anulowane.
- **Dostęp do dokumentów pakowania bez aktywnego stanowiska pakowacza** - Umożliwia elastyczne zarządzanie procesem pakowania. Pozwala na dostęp do dokumentów i rozpoczęcie pakowania nawet jeśli użytkownik nie jest zalogowany na dedykowanym stanowisku pakowacza.
- **Dostęp do wszystkich dokumentów zbierania ignorując ustawienia kolejek** - Uprawnienie pozwalające menedżerowi na podjęcie dowolnego zlecenia zbierania, omijając standardowe zasady przydziału zadań (kolejki).

**Inwentaryzacje**

- **Dostęp do modułu inwentaryzacji** - Zapewnia dostęp do wszystkich funkcjonalności związanych z przeprowadzaniem spisu z natury, w tym tworzeniem inwentaryzacji zbiorczych (całościowych, wg produktu, wg lokalizacji) oraz częściowych, a także ich realizacją i zamykaniem.

**Zwroty**

- **Dostęp do modułu zwroty**** - **Umożliwia dostęp do listy awizowanych zwrotów i ich realizację w magazynie, włączając w to skanowanie zwracanych towarów i odkładanie ich na wskazane lokalizacje.

**Informator**

- **Dostęp do modułu informatora** - Zapewnia dostęp do narzędzia "Informator", które pozwala na szybkie uzyskanie kompleksowych informacji na temat zeskanowanego kodu (produktu, lokalizacji, nośnika), w tym jego aktualny stan, lokalizację i powiązane dokumenty.

**Produkty**

- **Dostęp do modułu produktów** - Umożliwia dostęp do listy produktów, gdzie użytkownik może przeglądać towary, ich stany (WMS i ERP), lokalizacje oraz inne dane podstawowe.
- **Widzi zdjęcia** - Pozwala na wyświetlanie zdjęć produktów na liście oraz w szczegółach produktu, co ułatwia identyfikację wizualną towarów.
- **Widzi lokalizacje produktu** - W szczegółach produktu wyświetla sekcję z listą wszystkich lokalizacji magazynowych, na których znajduje się dany towar, wraz z ilością, partią i nośnikiem.
- **Edycja produktów** - Pozwala na edycje danych podstawowych produktu.
- **Dostęp do funkcji Przyjmij/Wydaj** – W szczegółach produktu wyświetla przycisk Przymij/Wydaj, za pomocą którego możliwa jest korekta stanu magazynowego na lokalizacjach.
- **Dostęp do funkcji Przyjmij/Wydaj z dokumentem** – W szczegółach produktu wyświetla przycisk Przymij/Wydaj, za pomocą którego możliwa jest korekta stanu magazynowego na lokalizacjach oraz wygenerowanie dokumentu PW/RW w ERP.

**Partie**

- **Edycja daty ważności** - Umożliwia modyfikację daty ważności przypisanej do konkretnej partii produktu.

**Nośniki**

- **Dostęp do modułu zarządzania nośnikami** - Zapewnia dostęp do modułu "Nośniki", gdzie można przeglądać, dodawać i edytować nośniki używane w procesach magazynowych.
- **Tworzenie i edycja nośników** - Pozwala na definiowanie nowych nośników w systemie, określanie ich nazwy, kodu, typu (stały, opakowanie) oraz parametrów fizycznych (wymiary, waga).
- **Tworzenie i edycja rodzajów nośników** - Umożliwia tworzenie i edycję predefiniowanych rodzajów nośników stałych, co ułatwia późniejsze dodawanie nośników tego samego typu poprzez dziedziczenie parametrów.
- **Usuwanie nośników** - Pozwala na usuwanie nośników z systemu.

**Zadania dodatkowe**

- **Dostęp do modułu zadań dodatkowych** - Zapewnia dostęp do modułu zadań dodatkowych w menu.
- **Dostęp do zleceń zadań dodatkowych** - Umożliwia dostęp do listy zleceń zadań dodatkowych. Proces ten jest awizowany i opiera się na wcześniej utworzonym dokumencie.
- **Wykonywanie zleceń zadań dodatkowych** - Umożliwia dostęp do realizacji zleceń dodatkowych. Proces ten jest awizowany i opiera się na wcześniej utworzonym dokumencie.
- **Dostęp do szybkich zadań** - Umożliwia dostęp do modułu szybkich zadań dodatkowych.
- **Wykonywanie szybkich zadań** - Pozwala na wykonywanie nieawizowanych, ad-hoc'owych zadań dodatkowych.

**Oddziały**

- **Dostęp do modułu zarządzania oddziałami** – Zapewnia dostęp do modułu oddziałów, gdzie możliwe jest połączenie dwóch różnych aplikacji.
- **Tworzenie i edycja oddziałów** - Pozwala na pełne zarządzanie utworzonymi oddziałami.
- **Usuwanie oddziałów** – Pozwala na usuwanie powiązań między oddziałami

**Oddziały \ Przypisani użytkownicy**

- **Dostęp do modułu zarządzania przypisanymi użytkownikami** – Umożliwia dostęp do sekcji „Oddziały” w szczegółach użytkownika.
- **Edycja przypisani** – Pozwala na zarządzaniem dostępem użytkownika do danego oddziału.

**Reklamacje**

- **Dostęp do modułu reklamacji** - Zapewnia dostęp do modułu reklamacji, gdzie użytkownik może tworzyć zgłoszenia reklamacyjne, śledzić ich status oraz realizować poszczególne etapy procesu, takie jak przyjęcie reklamowanego towaru czy wydanie nowego/naprawionego.

**Dokumentacja techniczna**

- **Dostęp do modułu dokumentacji technicznej** - Umożliwia dostęp do sekcji "Administracja / Dokumentacja techniczna", która prowadzi do interfejsu "Swagger". Zawiera on zbiór metod API, które mogą być wykorzystane do integracji programów zewnętrznych z systemem Asiston WMS.

**Konfiguracja WMS**

- **Dostęp do modułu konfiguracji WMS** - Uprawnienie nadrzędne, dające dostęp do głównej sekcji "Konfiguracja" w menu systemu, z której dostępne są wszystkie poniższe moduły konfiguracyjne.

**Konfiguracja WMS \ Priorytety dokumentów**

- **Dostęp do modułu konfiguracji priorytetów dokumentów** - Umożliwia dostęp do modułu "Konfiguracja / Priorytety", gdzie można definiować poziomy ważności dla dokumentów w różnych modułach (np. przyjęć, wydań). Pozwala to na wizualne oznaczanie pilnych zadań (np. za pomocą gwiazdek) i wymuszanie ich realizacji w pierwszej kolejności.

**Konfiguracja WMS \ Lokalizacje**

- **Dostęp do modułu zarządzania strefami** - Daje dostęp do modułu "Konfiguracja / Lokalizacje / Strefy", gdzie można definiować, edytować i usuwać strefy magazynowe.
- **Dostęp do modułu zarządzania lokalizacjami** - Uprawnienie ogólne do zarządzania pojedynczymi miejscami składowania, w tym ich parametrami (wymiary, nośność).
- **Dostęp do modułu zarządzania rzędami** - Umożliwia zarządzanie rzędami w ramach stref, co jest częścią procesu budowania struktury magazynu.
- **Dostęp do modułu zarządzania dozwolonymi produktami** - Pozwala na dostęp do funkcji przypisywania konkretnych produktów do określonych lokalizacji.
- **Dostęp do modułu zarządzania zablokowanymi użytkownikami** - Umożliwia dostęp do funkcji blokowania dostępu wybranym użytkownikom do konkretnych lokalizacji magazynowych.
- **Tworzenie i edycja stref / Usuwanie stref** - Pozwala na pełne zarządzanie cyklem życia stref magazynowych.
- **Tworzenie i edycja lokalizacji / Usuwanie lokalizacji** - Pozwala na pełne zarządzanie pojedynczymi miejscami składowania.
- **Tworzenie i edycja rzędów / Usuwanie rzędów** - Pozwala na pełne zarządzanie rzędami w magazynie.
- **Edycja dozwolonych produktów / Usuwanie dozwolonych produktów** - Umożliwia modyfikowanie i usuwanie przypisanych produktów do lokalizacji.
- **Edycja zablokowanych użytkowników / Usuwanie zablokowanych użytkowników** - Pozwala na modyfikowanie i usuwanie blokad dostępu użytkowników do lokalizacji.

**Konfiguracja WMS \ Lokalizacje \ Budynki**

- **Dostęp do modułu zarządzania budynkami** - Zapewnia dostęp do modułu "Konfiguracja / Lokalizacje / Budynki", gdzie można definiować budynki, w których znajdują się magazyny.
- **Tworzenie i edycja budynków / Usuwanie budynków** - Pełne uprawnienia do zarządzania listą budynków w systemie.

**Konfiguracja WMS \ Lokalizacje \ Typy stref**

- **Dostęp do modułu zarządzania typami stref** - Umożliwia dostęp do modułu "Konfiguracja / Lokalizacje / Typy stref", gdzie tworzy się słownik typów stref używany przy definiowaniu nowych stref.
- **Tworzenie i edycja typów stref / Usuwanie typów stref** - Pełne uprawnienia do zarządzania słownikiem typów stref.

**Konfiguracja WMS \ Lokalizacje \ Rodzaje lokalizacji**

- **Dostęp do modułu zarządzania rodzajami lokalizacji** - Zapewnia dostęp do modułu "Konfiguracja / Lokalizacje / Rodzaje lokalizacji", gdzie tworzy się słownik rodzajów lokalizacji.
- **Tworzenie i edycja rodzajów lokalizacji / Usuwanie rodzajów lokalizacji** - Pełne uprawnienia do zarządzania słownikiem rodzajów lokalizacji.

**Konfiguracja WMS \ Lokalizacje \ Konfiguracja ścieżki**

- **Dostęp do modułu konfiguracji ścieżki** - Umożliwia dostęp do modułu "Konfiguracja / Lokalizacje / Konfiguracja ścieżki".

**Konfiguracja WMS \ Procesy**

- **Dostęp do modułu procesów** - Zapewnia dostęp do modułu "Konfiguracja / Procesy", gdzie administrator definiuje przebieg kluczowych procesów magazynowych

**Konfiguracja WMS \ Zadania dodatkowe**

- **Dostęp do modułu zarządzania zadaniami dodatkowymi** – Umożliwia dostęp do modułu „Konfiguracja / Zadania dodatkowe”, gdzie możliwe jest tworzenie szablonów zadań.
- **Tworzenie i edycja zadań dodatkowych** - Pełne uprawnienia do zarządzania słownikiem szablonami zadań dodatkowych.
- **Usuwanie zadań dodatkowych** - Pozwala na usuwanie utworzonych szablonów zadań dodatkowych z systemu.

**Konfiguracja WMS \ Kody zbiorcze**

- **Dostęp do modułu kodów zbiorczych** - Umożliwia dostęp do modułu "Konfiguracja / Kody zbiorcze", gdzie można definiować kody kreskowe dla opakowań zbiorczych, przypisując im konkretny produkt i ilość jednostkową.
- **Edycja kodów zbiorczych** - Pozwala na modyfikację istniejących kodów zbiorczych.
- **Usuwanie kodów zbiorczych**- Pozwala na usuwanie zdefiniowanych kodów zbiorczych.

**Konfiguracja WMS \ Drukarki**

- **Dostęp do modułu drukarek** - Zapewnia dostęp do modułu "Konfiguracja / Drukarki", gdzie administrator zarządza drukarkami etykiet i dokumentów zintegrowanymi z systemem.
- **Tworzenie i edycja drukarek** - Umożliwia dodawanie nowych drukarek (sieciowych lub podłączonych lokalnie) i konfigurowanie ich parametrów (adres IP, port, wymiary strony, DPI).
- **Usuwanie drukarek** - Pozwala na usuwanie drukarek z konfiguracji systemu.

**Konfiguracja WMS \ Kurierzy**

- **Dostęp do modułu kurierów** - Zapewnia dostęp do modułu "Konfiguracja / Kurierzy", który służy do zarządzania kurierami.
- **Dostęp do edycji kurierów** - Pozwala na edycję ustawień dla poszczególnych kurierów, takich jak przypisanie domyślnej lokalizacji w magazynie, na którą odkładane są paczki dla danego przewoźnika, czy konfiguracja wymiarów paczek.

**Konfiguracja WMS \ Szablony CMR**

- **Dostęp do modułu szablonów CMR** - Zapewnia dostęp do modułu "Konfiguracja / Szablony CMR", który służy do zarządzania szablonami dokumentów CMR.

**Konfiguracja WMS \ Szablony etykiet**

- **Dostęp do modułu szablonów etykiet** - Umożliwia dostęp do modułu "Konfiguracja / Szablony etykiet", gdzie można projektować wygląd etykiet generowanych przez system (np. etykiety produktowe, lokalizacyjne, logistyczne).
- **Tworzenie i edycja etykiet** - Zapewnia dostęp do edytora szablonów, w którym użytkownik może definiować treść, układ, rozmiar, orientację oraz dodawać dynamiczne pola.

**Konfiguracja WMS \ Ustawienia**

- **Dostęp do modułu globalnych ustawień WMS** - Zapewnia dostęp do modułu "Konfiguracja / Ustawienia", gdzie znajdują się globalne parametry pracy systemu, takie jak domyślne jednostki miary, obsługa partii, obsługa nośników, zasady walidacji umieszczania towarów na lokalizacjach czy standardy GS1.
- **Edycja globalnych ustawień WMS** - Pozwala na modyfikację globalnych ustawień systemu, co ma wpływ na działanie wszystkich procesów magazynowych.

**Raporty**

- **Dostęp do raportów systemowych** - Uprawnienie nadrzędne dające dostęp do sekcji "Raporty" w menu.
- **Dostęp do raportu historii ruchów magazynowych** - Uprawnienie dające dostęp do raportu "Raportu ruchów magazynowych".
- **Dostęp do raportu sprzedażowego** - Uprawnienie dające dostęp do raportu "Raportu sprzedażowego".
- **Dostęp do raportu XYZ** - Uprawnienie dające dostęp do raportu "Raportu XYZ".
- **Dostęp do raportu uzupełnień lokalizacji (Replenishment)** - Uprawnienie dające dostęp do raportu "Raportu uzupełnień lokalizacji".
- **Dostęp do raportu zerowych lokalizacji** - Uprawnienie dające dostęp do raportu "Raportu zerowych lokalizacji".
- **Dostęp do raportu komasacji** - Uprawnienie dające dostęp do raportu "Raportu komasacji".
- **Dostęp do raportu towarów uszkodzonych** - Uprawnienie dające dostęp do raportu "Raportu towarów uszkodzonych".
- **Dostęp do raportu rozchodu opakowań** - Uprawnienie dające dostęp do raportu "Raportu rozchodu opakowań".
- **Dostęp do raportu wydajności zbieraczy** -** **Uprawnienie dające dostęp do raportu "Raportu wydajności zbieraczy".
- **Dostęp do raportu wydajności pakowaczy** - Uprawnienie dające dostęp do raportu "Raportu wydajności pakowaczy".
- **Dostęp do raportu rozbieżności przesunięć** - Uprawnienie dające dostęp do raportu "Raportu rozbieżności przesunięć".
- **Dostęp do raportów AI** - Uprawnienie nadrzędne dające dostęp do sekcji "Raporty AI" w menu.
- **Widzi wszystkie raporty AI** - Uprawnienie dające dostęp do widoczności wszystkich raportów AI.
- **Może dodawać raporty AI** -Uprawnienie dające dostęp do dodawania nowych raportów AI.
- **Może edytować raporty AI** - Uprawnienie dające dostęp do edytowania raportów AI.
- **Może usuwać raporty AI** - Uprawnienie dające dostęp do usuwania raportów AI.
- **Dostęp do Chat AI** - Uprawnienie dające dostęp do korzystania z Chata AI.
- **Dostęp do SQL** - Uprawnienie dające dostęp do tworzenia raportów SQL.
- **Dostęp do uprawnień raportu** - Uprawnienie dające dostęp do modyfikacji uprawnień do raportów AI.

**Kontrola jakości**

- **Dostęp do modułu kontroli jakości** - Umożliwia dostęp do modułu "Kontrola jakości", gdzie trafiają towary z przyjęć awizowanych, które wymagają weryfikacji. Użytkownik może przeglądać listę dokumentów kontroli jakości i realizować je.
- **Możliwość kontroli towarów** - Pozwala na przeprowadzenie inspekcji towaru, określenie jego zgodności lub niezgodności z zamówieniem oraz ewentualne przesunięcie na dedykowaną lokalizację kontroli.

**Pozostałe**

- **Możliwość odblokowania zablokowanego dokumentu** - System blokuje dokumenty, nad którymi pracuje dany użytkownik, aby uniknąć konfliktów. To uprawnienie, przeznaczone dla kierowników lub administratorów, pozwala na siłowe odblokowanie dokumentu, np. w przypadku nagłej nieobecności pracownika, który go zablokował.
- **Dostęp do modułu** **marketplace** - Umożliwia dostęp do sekcji "Administracja / Marketplace", gdzie można zarządzać zainstalowanymi integracjami i aplikacjami rozszerzającymi funkcjonalność systemu Asiston WMS.
