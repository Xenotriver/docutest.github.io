---
title: "Inwentaryzacja"
sidebar_label: "7.10. Inwentaryzacja"
---

Moduł Inwentaryzacji służy do sprawdzania zgodności rzeczywistych stanów magazynowych z danymi znajdującymi się w systemie Asiston WMS oraz systemem ERP. System obsługuje rodzaje inwentaryzacji, wyróżnione ze względu na rodzaj i zakres, i są to:

1. Rodzaj:
  1. Zbiorcza – ustala zakres inwentaryzacji oraz umożliwia tworzenie i prowadzenie inwentaryzacji częściowych, w ustalonym zakresie;
  1. Częściowa – odbywa się w zakresie, ustalonym na poziomie inwentaryzacji zbiorczej i pokrywa część lub całość zakresu inwentaryzacji zbiorczej (w celu zrealizowania inwentaryzacji zbiorczej, można tworzyć jedną lub kilka inwentaryzacji częściowych).
1. Zakres:
  1. Całościowa - spisem obejmujemy cały, wybrany magazyn,
  1. Produktu – sprawdzamy stan danego produktu, na wszystkich lokalizacjach,
  1. Lokalizacji – sprawdzamy zgodność stanu towarów na danej lokalizacji.

## Inwentaryzacja zbiorcza

Po przejściu do modułu „Inwentaryzacja”, w menu systemu Asiston WMS, użytkownik dostanie widok listy wszystkich utworzonych dokumentów inwentaryzacji zbiorczych.

Lista będzie zawierać kolumny:

- Numer dokumentu,
- Typ:
- Inwentaryzacja całościowa,
- Inwentaryzacja produktu,
- Inwentaryzacja lokalizacji,
- Magazyn,
- Status:
- Błąd zakańczania inwentaryzacji,
- Oczekuje na liczenie,
- W przygotowaniu,
- Zakańczanie,
- Zakończony.
- Data utworzenia,
- Data zakończenia,
- Akcje:
- Szczegóły,
- Usuń.

Filtrowanie listy możliwe będzie według:

- Nr inwentaryzacji – wyszukiwanie po znakach zarówno inwentaryzacji całościowej jak i częściowej,
- Typu inwentaryzacji – lista rozwijana:
- Inwentaryzacja całościowa,
- Inwentaryzacja produktu,
- Inwentaryzacja lokalizacji,
- Magazynu – lista rozwijana,
- Statusu – lista rozwijana:
  - Błąd zakańczania inwentaryzacji,
  - Oczekuje na liczenie,
  - W przygotowaniu,
  - Zakańczanie,
  - Zakończony.
- Daty utworzenia (od – do),
- Daty zakończenia (od – do).

![0. Widok listy inwentaryzacji zbiorczych w systemie Asiston WMS.](\img\OIP.png)

0. Widok listy inwentaryzacji zbiorczych w systemie Asiston WMS.

Tworzenie nowej inwentaryzacji zbiorczej odbywać się będzie za pomocą przycisku „Utwórz nową inwentaryzację zbiorczą”. Kliknięcie przycisku zwróci widok z następującymi polami do wypełnienia:

- Typ inwentaryzacji – lista rozwijana:
- Inwentaryzacja całościowa,
- Inwentaryzacja lokalizacji,
- Inwentaryzacja produktu.
- Magazyn – lista rozwijana,
- Uwagi – pole do wpisania dodatkowych informacji potrzebnych podczas inwentaryzacji.

![1. Tworzenie inwentaryzacji zbiorczej.](\img\OIP.png)

1. Tworzenie inwentaryzacji zbiorczej.

### Tworzenie inwentaryzacji zbiorczej całościowej

Aby utworzyć inwentaryzację zbiorczą – całościową należy użyć przycisku „Utwórz nową inwentaryzację zbiorczą”. W widoku tworzenia inwentaryzacji zbiorczej, w sekcji „Podstawowe informacje”, wybieramy:

- Typ inwentaryzacji – lista rozwijana:
- Inwentaryzacja całościowa,
- Magazyn – lista rozwijana,
- Uwagi – możemy wykorzystać to pole do wpisania dodatkowych informacji potrzebnych podczas inwentaryzacji.

Wybór potwierdzamy przyciskiem „Utwórz”. Widok tworzenia inwentaryzacji zbiorczej – całościowej.

![2. Tworzenie inwentaryzacji zbiorczej, całościowej.](\img\OIP.png)

2. Tworzenie inwentaryzacji zbiorczej, całościowej.

Po utworzeniu nowej inwentaryzacji zbiorczej – całościowej, system Asiston WMS automatycznie doda ją do listy inwentaryzacji zbiorczych, z typem „Inwentaryzacja całościowa” i statusem „Oczekuje na liczenie”.

### Tworzenie inwentaryzacji zbiorczej produktu

Aby utworzyć inwentaryzację zbiorczą produktu należy użyć przycisku „Utwórz nową inwentaryzację zbiorczą”. W widoku tworzenia inwentaryzacji zbiorczej, w sekcji „Podstawowe informacje”, wybieramy:

- Typ inwentaryzacji – lista rozwijana:
- Inwentaryzacja produktu,
- Magazyn – lista rozwijana,
- Uwagi – możemy wykorzystać to pole do wpisania dodatkowych informacji potrzebnych podczas inwentaryzacji,
- Blokuj ruch produktów podczas inwentaryzacji – checkbox – jego zaznaczenie uniemożliwi obsługę przyjęcie, wydanie i przesunięcie spisywanych produktów do czasu zakończenia inwentaryzacji,
- Dodaj towary – tu z listy rozwijanej wybieramy towary, które chcemy inwentaryzować, wybór potwierdzamy przyciskiem „Dodaj”,

Kolejna pozycja widoku to lista towarów, dodanych do inwentaryzacji. Lista zwiera kolumny:

- Zdjęcie towaru,
- Symbol
- Nazwa,
- Kod towaru,
- Ikonka usuwania towaru z listy

Towar z listy można wyszukać wpisując frazę z dowolnej kolumny listy, w polu wyszukiwania.

Utworzenie inwentaryzacji zbiorczej produktu potwierdzamy przyciskiem „Utwórz”. Widok tworzenia inwentaryzacji zbiorczej produktu.

![3. Tworzenie inwentaryzacji zbiorczej produktu.](\img\OIP.png)

3. Tworzenie inwentaryzacji zbiorczej produktu.

Po utworzeniu nowej inwentaryzacji zbiorczej – całościowej, system Asiston WMS automatycznie doda ją do listy inwentaryzacji zbiorczych, z typem „Inwentaryzacja produktu” i statusem „Oczekuje na liczenie”.

### Tworzenie inwentaryzacji zbiorczej - lokalizacji

Aby utworzyć inwentaryzację zbiorczą lokalizacji należy użyć przycisku „Utwórz nową inwentaryzację zbiorczą”. W widoku tworzenia inwentaryzacji zbiorczej, w sekcji „Podstawowe informacje”, wybieramy:

- Typ inwentaryzacji – lista rozwijana:
- Inwentaryzacja lokalizacji,
- Magazyn – lista rozwijana,
- Rodzaj – lista rozwijana:
  - Powiązana (należy sprawdzić towary na podanej lokalizacji oraz na innych, na których dane towary się znajdują),
  - Niepowiązana (Należy sprawdzić towary tylko, na podanej lokalizacji. Jeśli towary znajdują się na innych lokalizacjach, wówczas ich stan zostanie automatycznie dodany).
- Uwagi – możemy wykorzystać to pole do wpisania dodatkowych informacji potrzebnych podczas inwentaryzacji,
- Blokuj lokalizacje podczas inwentaryzacji – checkbox – jego zaznaczenie uniemożliwi obsługę przyjęcie, wydanie i przesunięcie spisywanych produktów do czasu zakończenia inwentaryzacji,
- Dodaj lokalizacje – tu z listy rozwijanej wybieramy lokalizacje, które chcemy inwentaryzować, wybór potwierdzamy przyciskiem „Dodaj”,

Kolejna pozycja widoku to lista lokalizacji, dodanych do inwentaryzacji. Lista zwiera kolumny:

- Kod lokalizacji,
- Ikonka usuwania lokalizacji z listy

Lokalizację z listy można wyszukać wpisując frazę jej kodu w polu wyszukiwania.

Utworzenie inwentaryzacji zbiorczej lokalizacji potwierdzamy przyciskiem „Utwórz”. Widok tworzenia inwentaryzacji zbiorczej lokalizacji.

![4. Tworzenie inwentaryzacji zbiorczej lokalizacji.](\img\OIP.png)

4. Tworzenie inwentaryzacji zbiorczej lokalizacji.

Po utworzeniu nowej inwentaryzacji zbiorczej lokalizacji, system Asiston WMS automatycznie doda ją do listy inwentaryzacji zbiorczych, z typem „Inwentaryzacja lokalizacji” i statusem „Oczekuje na liczenie”.

### Szczegóły inwentaryzacji zbiorczej

Przejście do szczegółów inwentaryzacji zbiorczej zwróci listę wszystkich utworzonych dokumentów inwentaryzacji cząstkowych.

Widok listy inwentaryzacji częściowych będzie zawierał:

- Numer dokumentu – numer wewnętrzny w systemie Asiston WMS,
- Numer dokumentu – numer pobrany z systemu ERP po zakończeniu procesu inwentaryzacji częściowej,
- Magazyn,
- Status:
- Oczekuje na liczenie,
- Przerwano,
- W przygotowaniu,
- Zakończony,
- Data utworzenia,
- Data zakończenia,
- Osoba blokująca,
- Akcje:
- Szczegóły,
- Usuń.

Filtrowanie listy możliwe będzie według:

- Nr dokumentu – wyszukiwanie po znakach zarówno inwentaryzacji całościowej jak i częściowej,
- Nr ERP – wyszukiwanie po znakach,
- Statusu – lista rozwijana:
  - Oczekuje na liczenie,
  - Przerwano,
  - W przygotowaniu,
  - Zakończony.
- Daty utworzenia (od – do),
- Daty zakończenia (od – do),
- Osoba blokująca.

W widoku listy inwentaryzacji częściowych będą się również znajdować przyciski:

- Powrót,
- Dodaj inwentaryzację częściową,
- Zakończ inwentaryzację.

![5. Widok szczegółów inwentaryzacji zbiorczej – lista inwentaryzacji częściowych.](\img\OIP.png)

5. Widok szczegółów inwentaryzacji zbiorczej – lista inwentaryzacji częściowych.

### Zakończenie inwentaryzacji zbiorczej

Inwentaryzację zbiorczą można zakończyć przyciskiem „Zakończ inwentaryzację”, w widoku szczegółów inwentaryzacji zbiorczej – listy inwentaryzacji częściowych. System Asiston WMS:

- Sprawdzi automatycznie czy nie ma różnic między ilościami spisanymi z natury i ilościami w systemie. Na ilości w pozycjach, w których te różnice wystąpią wygeneruje odpowiednio dokumenty RW/PW,
- Pokaże postęp zamykania inwentaryzacji, na popupie.

![6. Widok zakończenia inwentaryzacji zbiorczej.](\img\OIP.png)

6. Widok zakończenia inwentaryzacji zbiorczej.

## Inwentaryzacja częściowa

Nową inwentaryzację częściową będzie można dodać za pomocą przycisku „Dodaj inwentaryzację częściową”. Kliknięcie przycisku zwróci dokument inwentaryzacji częściowej, ze statusem „Oczekuje na liczenie”. Zawartość dokumentu będzie zmieniać wraz z jego statusem.

### Status „Oczekuje na liczenie”

Dokument ze statusem „Oczekuje na liczenie” wyświetli:

- Numer dokumentu, wraz z datą jego zapisania,
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów do inwentaryzacji, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Lokalizacja,
    - RW,
    - PW,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja,
      - Nośnik,
      - Stan przed
      - Ilość,
      - JM,
      - Partia,
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Typ inwentaryzacji,
  - Status „Oczekuje na liczenie”,
  - Nr dokumentu z ERP,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Magazyn
  - Uwagi do inwentaryzacji zbiorczej,
- Przyciski:
  - „Powrót”,
  - „Rozpocznij”.

![7. Widok szczegółów inwentaryzacji częściowej, status: "Oczekuje na liczenie",    sekcja: "Towary".](\img\OIP.png)

7. Widok szczegółów inwentaryzacji częściowej, status: "Oczekuje na liczenie",   
sekcja: "Towary".

![8. Widok szczegółów inwentaryzacji częściowej, status: "Oczekuje na liczenie",    sekcja”: „Podstawowe informacje”.](\img\OIP.png)

8. Widok szczegółów inwentaryzacji częściowej, status: "Oczekuje na liczenie",   
sekcja”: „Podstawowe informacje”.

### Status „W przygotowaniu”

Dokument ze statusem „W przygotowaniu” wyświetli:

- Numer dokumentu, wraz z datą jego zapisania,
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika,
    - Kodu towaru,
    - Partii,
    - Ilości,
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik,
    - Ukryj partię,
    - Ukryj ilość,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Lokalizacja
    - RW,
    - PW
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja,
      - Nośnik,
      - Stan przed
      - Ilość,
      - JM,
      - Partia,
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Typ inwentaryzacji,
  - Status „W przygotowaniu”,
  - Nr dokumentu z ERP,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Magazyn
  - Uwagi do inwentaryzacji zbiorczej,
- Przyciski:
  - „Powrót”,
  - „Przerwij”
  - „Zakończ inwentaryzację cząstkową”.

![9. Widok szczegółów inwentaryzacji częściowej, status: "W przygotowaniu",    sekcja: „Zeskanuj pozycje”.](\img\OIP.png)

9. Widok szczegółów inwentaryzacji częściowej, status: "W przygotowaniu",   
sekcja: „Zeskanuj pozycje”.

![0. Widok szczegółów inwentaryzacji częściowej, status: "W przygotowaniu", sekcja „Towary”.](\img\OIP.png)

0. Widok szczegółów inwentaryzacji częściowej, status: "W przygotowaniu", sekcja „Towary”.

![1. Widok szczegółów inwentaryzacji częściowej, status: "W przygotowaniu", sekcja „Podstawowe informacje”.](\img\OIP.png)

1. Widok szczegółów inwentaryzacji częściowej, status: "W przygotowaniu", sekcja „Podstawowe informacje”.

### Status „Zakończona”

Dokument ze statusem „Zakończony” wyświetli:

- Numer dokumentu, wraz z datą jego zapisania,
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania i spakowanych, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - RW,
    - PW,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja,
      - Nośnik,
      - Stan przed,
      - Ilość,
      - JM,
      - Partia,
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Typ inwentaryzacji,
  - Status „Zakończony”,
  - Nr dokumentu z ERP,
  - Przez kogo dokument został zablokowany,
  - Datę utworzenia,
  - Datę zakończenia,
  - Magazyn
  - Uwagi do inwentaryzacji zbiorczej (pole tekstowe),
  - Przyciski:
    - „Powrót”
    - „Logi”

![2. Widok szczegółów inwentaryzacji częściowej, status: "Zakończony", sekcja „Towary”.](\img\OIP.png)

2. Widok szczegółów inwentaryzacji częściowej, status: "Zakończony", sekcja „Towary”.

![3. Widok szczegółów inwentaryzacji częściowej, status: "Zakończony",    sekcja „Podstawowe informacje”.](\img\OIP.png)

3. Widok szczegółów inwentaryzacji częściowej, status: "Zakończony",   
sekcja „Podstawowe informacje”.

## Inwentaryzacja

![Diagram 40. Inwentaryzacja.](\img\OIP.png)

Diagram 40. Inwentaryzacja.

Proces rozpocznie się od utworzenia nowej inwentaryzacji zbiorczej, przyciskiem "Utwórz nową inwentaryzację zbiorczą", w widoku listy inwentaryzacji zbiorczych, systemu WMS. Użycie przycisku zwróci formularz, w którym należy wybrać:

- Typ inwentaryzacji:
  - Całościowa
  - Lokalizacji
  - Produktu
- Magazyn, w którym inwentaryzacja będzie prowadzona (wybór nastąpi z listy magazynów, pobranych z ERP i udostępnionych w widoku formularza WMS)

Jeśli zostanie wskazany typ inwentaryzacji „Całościowa”, to w formularzu będzie można – przy pomocy checkboxa – zablokować cały ruch magazynowy w magazynie, wybranym do przeprowadzenia inwentaryzacji. Domyślnie opcja ta będzie aktywna.

Jeśli będzie to typ inwentaryzacji „Lokalizacji”, to:

- W widoku formularza będzie można – z listy rozwijanej – wybrać jeden z dwóch sposobów prowadzenia inwentaryzacji lokalizacji:
  - Inwentaryzacja produktów z wybranej lokalizacji i innych lokalizacji, na których znajdują się te produkty,
  - Inwentaryzacja produktów z wybranej lokalizacji, stany tych produktów na innych lokalizacjach zostaną, automatycznie pobrane z systemu WMS (ta funkcjonalność będzie dostępna w wersji 2.0).
- Do widoku formularza system doda pole listy rozwijanej, z której użytkownik będzie mógł wybrać lokalizację do przeprowadzenia inwentaryzacji i dodać ją do listy, tworzonej w kolejnej sekcji formularza.

Jeśli zostanie wskazany typ inwentaryzacji „Produktu”, to użytkownik będzie mógł wybrać produkty do przeprowadzenia inwentaryzacji i dodać je do listy w kolejnej sekcji.

Zakończenie tworzenia nowej inwentaryzacji zbiorczej nastąpi przyciskiem „Utwórz”. System WMS sprawdzi następnie czy spełnione są warunki dla wybranego typu inwentaryzacji zbiorczej, tj.:

- Całościowa:
  - Może być aktywna tylko jedna inwentaryzacja całościowa
- Lokalizacji:
  - Może być aktywnych wiele inwentaryzacji lokalizacji
  - Nie można utworzyć drugiej inwentaryzacji lokalizacji, jeśli jest już aktywna inwentaryzacja na wybranej lokalizacji
- Produktu:
  - Może być aktywnych wiele inwentaryzacji produktu
  - Nie można utworzyć drugiej inwentaryzacji produktu, który jest już w procesie inwentaryzacji.

Jeżeli odpowiednie warunki nie będą spełnione, system nie utworzy nowej inwentaryzacji zbiorczej i proces wróci na początek. W przypadku spełnienia warunków, nowy dokument inwentaryzacji zbiorczej zostanie utworzony i dodany do listy inwentaryzacji zbiorczych w systemie WMS.

W widoku szczegółów wybranej inwentaryzacji zbiorczej użytkownik utworzy nowy dokument inwentaryzacji cząstkowej, przyciskiem "Rozpocznij nową inwentaryzację cząstkową". System doda nowy dokument, o statusie "Oczekuje na liczenie", do listy inwentaryzacji cząstkowych, a użytkownik zostanie od razu przekierowany do szczegółów nowo utworzonego dokumentu. W ramach obsługi dokumentu inwentaryzacji cząstkowej, pracownik:

- Zeskanuje kod towaru,
- Wypełni pozostałe, wymagane pola,
- Doda towar do listy zinwentaryzowanych.

Zakończenie inwentaryzacji użytkownik potwierdzi przyciskiem „Zakończ inwentaryzację cząstkową”, a system WMS:

- Powróci na listę inwentaryzacji cząstkowych, i nada zakończonej właśnie inwentaryzacji, status „Zakończone”,
- Wyśle do systemu ERP sygnał do utworzenia dokumentu inwentaryzacji cząstkowej. System ERP wygeneruje taki dokument i doda go do swojej listy inwentaryzacji cząstkowych.

Po zakończeniu wszystkich inwentaryzacji cząstkowych, utworzonych w ramach danej inwentaryzacji zbiorczej, w systemie WMS, w widoku listy inwentaryzacji cząstkowych (widok szczegółów inwentaryzacji zbiorczej), wyświetli się przycisk "Zakończ inwentaryzację". Jego użycie spowoduje zakończenie inwentaryzacji zbiorczej.

System WMS automatycznie skoryguje stany towarów na lokalizacjach, wg ilości ustalonych w trakcie spisu z natury.

Na podstawie zebranych i zaznaczonych dokumentów inwentaryzacji cząstkowych, utworzonych w ERP, użytkownik będzie mógł wygenerować dokument inwentaryzacji zbiorczej oraz zaktualizować stany magazynowe, wykorzystując odpowiednie funkcjonalności systemu ERP.
