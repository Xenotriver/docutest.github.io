---
title: "Zwroty"
sidebar_label: "7.9. Zwroty"
---

W module „Zwroty” będą znajdować się dokumenty awizacji zwrotów, tworzone na podstawie dokumentów inicjujących zwrot z systemu ERP.

Dane na liście zwrotów:

- Numer dokumentu
- Status:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zakończony
- Kontrahent
- Data utworzenia
- Data zakończenia
- Sposób dostawy
- Osoba blokująca
- Postęp realizacji
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Kontrahencie – wyszukiwanie po nazwie
- Statusie – wybór z listy rozwijanej:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zakończony
- Daty utworzenia (od – do)
- Daty zakończenia (od – do)
- Sposób dostawy
- Osoba blokująca

![7. Widok listy zwrotów, w systemie Asiston WMS.](\img\OIP.png)

7. Widok listy zwrotów, w systemie Asiston WMS.

Lista Zwrotów jest na bieżąco aktualizowana w tle. Oznacza to, że system Asiston WMS automatycznie pobiera dokumenty awizujące zwrot, dodane w systemie ERP, i udostępnia je w widoku listy.

Widok szczegółów dokumentu zwrotu zawiera:

- Numer dokumentu,
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Pasek postępu w obsłudze dokumentu,
- Sekcję do skanowania zwracanych towarów, z następującymi polami:
  - Lokalizacja
  - Nośnik
  - Kod towaru
  - Partia
  - Ilość
  - Przyciski do ukrywania pól:
    - Ukryj lokalizację
    - Ukryj nośnik
    - Ukryj partię
    - Ukryj ilość
    - Przycisk resetowania wartości pól z sekcji skanowania,
    - Przycisk „Dodaj”, który dodaje ilość zeskanowanego towaru do listy poniżej,
- Sekcję z listą towarów, awizowanych do zwrotu, sekcja zawiera:
  - Pole wyszukiwania frazy z dowolnej kolumny na liście,
  - Listę awizowanych towarów z następującymi kolumnami:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
    - Ikonka wydruku etykiety
    - Uzupełnij wagę – jeśli towar nie ma uzupełnionej wagi
    - Uzupełnij wymiary – jeśli towar nie ma uzupełnionych wymiarów
    - Przycisk widoku rozwijanego, który dla danego towaru zwraca dane o:
      - Lokalizacji
      - Nośniku
      - Ilości
      - JM
      - Numerze partii
      - Ikonkę usuwania
- Sekcję „Podstawowe informacje”, która wyświetla
  - Nazwę kontrahenta
  - Status dokumentu
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Datę zakończenia przyjęcia zwrotu
  - Pole „Uwagi”, tu magazynier może wpisać uwagi, przy zwrocie.

Wiersze awizowanych towarów podświetlają się na kolory:

- Brak podświetlenia – towar niezeskanowany
- Zielony – towar zwrócony w ilości awizowanej
- Żółty – towar zwrócony w mniejszej ilości niż ilość awizowana

Bieżącą pracę z dokumentem można zakończyć przyciskami:

- Zakończ zwrot
- Przerwij
- Powrót

![8. Widok szczegółów dokumentu zwrotu – sekcja skanowania    oraz lista towarów do przyjęcia.](\img\OIP.png)

8. Widok szczegółów dokumentu zwrotu – sekcja skanowania   
oraz lista towarów do przyjęcia.

![9. Widok szczegółów dokumentu zwrotu – sekcja "Podstawowe informacje".](\img\OIP.png)

9. Widok szczegółów dokumentu zwrotu – sekcja "Podstawowe informacje".

## Zwroty

![C:\Users\k.feret\AppData\Local\Packages\Microsoft.Windows.Photos_8wekyb3d8bbwe\TempState\ShareServiceTempFolder\Obsługa zwrotow WMS.jpeg](\img\OIP.png)

Diagram 39. Zwroty.

W systemie ERP zostanie utworzony dokument inicjujący zwrot. System Asiston WMS pobierze dane z tego dokumentu, utworzy swój dokument zwrotu i doda go do listy awizowanych zwrotów ze statusem „Nowy”.

Magazynier przejdzie do szczegółów dokumentu zwrotu i rozpocznie jego obsługę. System Asiston WMS automatycznie zmieni status dokumentu na "W przygotowaniu". Magazynier może przerwać obsługę dokumentu przyjęcia, wówczas dokument przyjmie status „Przerwano”.

Na podstawie listy produktów, w dokumencie ze statusem „W przygotowaniu”, magazynier zweryfikuje stan faktyczny zwracanych towarów. Obsługa przyjęcia zwrotu odbywać się będzie poprzez zeskanowanie produktów. W jego ramach magazynier poda:

- Kod lokalizacji przyjęcia zwrotu,
- Kod nośnika,
- Kod towaru,
- Numer partii,
- Ilość.

Magazynier zakończy proces przyjęcia zwrotu przyciskiem „Zakończ zwrot”. System WMS automatycznie wyśle do systemu ERP informację o zakończeniu System ERP, na dokumencie inicjującym zwrot, wykona akcje zgodnie z warunkami, ustawionymi w integracji systemów ERP i Asiston WMS.

*Powrót do konfiguracji*