---
title: "Przyjęcia"
sidebar_label: "7.4. Przyjęcia"
---

## Przyjęcia awizowane

W module „Przyjęcia awizowane” będą znajdować się dokumenty awizacji przyjęć, tworzone na podstawie dokumentów ZD z ERP.

Dane na liście przyjęć:

- Numer dokumentu
- Status:
  - Oczekuje na przyjęcie
  - W przygotowaniu
  - Przerwano
  - Zwrócone
  - Zakończony
- Kontrahent
- Pierwotny dokument
- Data utworzenia
- Data dostawy
- Data zakończenia
- Nr dokumentu realizującego
- Osoba blokująca
- Postęp realizacji
- Priorytet
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Kontrahenta – wyszukiwanie po nazwie
- Statusu – wybór z listy rozwijanej:
  - Oczekuje na przyjęcie
  - W przygotowaniu
  - Przerwano
  - Zwrócone
  - Zakończony
- Daty utworzenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Daty dostawy
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Daty zakończenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Osoby blokującej
- Priorytet

![0. Widok listy przyjęć awizowanych, w systemie Asiston WMS.](\img\OIP.png)

0. Widok listy przyjęć awizowanych, w systemie Asiston WMS.

Lista dokumentów ZD jest na bieżąco aktualizowana w tle. Oznacza to, że system Asiston WMS automatycznie pobiera dokumenty ZD, dodane w systemie ERP, i udostępnia je w widoku listy.

Widok szczegółów dokumentu przyjęcia awizowanego zawiera:

- Numer dokumentu,
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Pasek postępu w obsłudze dokumentu,
- Sekcję do skanowania przyjmowanych towarów, z następującymi polami:
  - Lokalizacja
  - Nośnik
  - Kod towaru
  - Partia
  - Ilość
  - Przyciski do ukrywania pól:
    - Ukryj lokalizację
    - Ukryj nośnik
    - Ukryj partię
    - Ukryj ilość
    - Przycisk resetowania wartości pól z sekcji skanowania,
    - Przycisk „Dodaj”, który dodaje ilość zeskanowanego towaru do listy poniżej,
- Sekcję z listą towarów, awizowanych do przyjęcia, sekcja zawiera:
  - Pole wyszukiwania frazy z dowolnej kolumny na liście,
  - Listę awizowanych towarów z następującymi kolumnami:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Kod towaru
    - Ilość
    - JM
    - Ikonka wydruku etykiety
    - Ikonka Kontroli jakości (dla pozycji spełniających warunek przeprowadzenia kontroli)
    - Ikona podglądu lokalizacji produktu
    - Uzupełnij wagę – jeśli towar nie ma uzupełnionej wagi
    - Uzupełnij wymiary – jeśli towar nie ma uzupełnionych wymiarów
    - Przycisk widoku rozwijanego, który dla danego towaru zwraca dane o:
      - Lokalizacji
      - Nośniku
      - Ilości
      - JM
      - Numerze partii
      - Ikona zgłoszenia uszkodzenia
      - Ikonkę usuwania
- Sekcję „Podstawowe informacje”, która wyświetla
  - Nazwę kontrahenta
  - Status dokumentu
  - Nr dokumentu realizującego,
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Datę dostawy
  - Datę zakończenia przyjęcia
  - Priorytet
  - Pole „Uwagi”, tu magazynier może wpisać uwagi, przy przyjęciu.
  - Ilość palet
  - Numer dokumentu zewnętrznego

Wiersze awizowanych towarów podświetlają się na kolory:

- Brak podświetlenia – towar niezeskanowany
- Zielony – towar przyjęty w ilości awizowanej
- Żółty – towar przyjęty mniejszej ilości niż ilość awizowana
- Niebieski - towar przyjęty większej ilości niż ilość awizowana.

Bieżącą prace z dokumentem można zakończyć przyciskami:

- Zakończ przyjęcie
- Przerwij
- Powrót

![1. Widok szczegółów dokumentu przyjęcia awizowanego – sekcja skanowania    oraz lista towarów do przyjęcia.](\img\OIP.png)

1. Widok szczegółów dokumentu przyjęcia awizowanego – sekcja skanowania   
oraz lista towarów do przyjęcia.

![2. Widok szczegółów dokumentu przyjęcia awizowanego – sekcja "Podstawowe informacje".](\img\OIP.png)

2. Widok szczegółów dokumentu przyjęcia awizowanego – sekcja "Podstawowe informacje".

## Przyjęcia bezpośrednie

Moduł przyjęć bezpośrednich służy do obsługi przyjęć, które można utworzyć bezpośrednio w systemie Asiston WMS i nie są one awizowane z systemu ERP.

Podstawowym widokiem po wejściu do modułu będzie lista dokumentów przyjęć. Lista zawiera kolumny:

- Numer dokumentu
- Status:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zwrócone
  - Zakończony
- Data utworzenia
- Data zakończenia
- Numer dokumentu realizującego
- Osoba blokująca
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Statusu – wybór z listy rozwijanej:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zwrócone
  - Zakończony
- Daty utworzenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Daty zakończenia
  - Bieżący dzień
  - Ostatnie 7 dni
  - Bieżący miesiąc
  - Bieżący rok
  - Niestandardowe (od – do)
- Osoby blokującej

![3. Przykładowy widok listy przyjęć bezpośrednich, w systemie Asiston WMS,](\img\OIP.png)

3. Przykładowy widok listy przyjęć bezpośrednich, w systemie Asiston WMS,

Utworzenie nowego dokumentu przyjęcia bezpośredniego nastąpi przy użyciu przycisku „Dodaj przyjęcie”.

Kliknięcie przycisku zwróci widok z następującymi polami do wypełnienia:

- Typ przyjęcia do wyboru z listy rozwijanej
  - Przyjęcie zewnętrzne
  - Przyjęcie zewnętrzne z vat
  - Przyjęcie wewnętrzne
- Kontrahent – jeśli wybrano przyjęcie zewnętrzne PZ,
- Magazyn ERP,
- Numer oryginalny,
- Tytuł,
- Opis

Dodanie przyjęcia do listy nastąpi przyciskiem „Zapisz”. Cofnięcie do poprzedniego widoku jest możliwe przyciskiem „Powrót”.

![4. Widok dodania przyjęcia bezpośredniego, w systemie Asiston WMS.](\img\OIP.png)

4. Widok dodania przyjęcia bezpośredniego, w systemie Asiston WMS.

Widok szczegółów dokumentu przyjęcia bezpośredniego zawiera:

- Numer dokumentu,
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Sekcję do skanowania przyjmowanych towarów, z następującymi polami:
  - Lokalizacja
  - Nośnik
  - Kod towaru
  - Partia
  - Ilość
  - Przyciski do ukrywania pól:
    - Ukryj lokalizację
    - Ukryj nośnik
    - Ukryj partia
    - Ukryj ilość
    - Przycisk resetowania wartości pól z sekcji skanowania,
    - Przycisk „Dodaj”, który dodaje zeskanowany towar do listy poniżej.
- Sekcję z listą dodanych towarów, sekcja zawiera:
  - Pole wyszukiwania frazy z dowolnej kolumny na liście,
  - Listę towarów z następującymi kolumnami:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Ilość
    - JM
    - Ikonka wydruku etykiety
    - Ikonka Kontroli jakości (dla pozycji spełniających warunek przeprowadzenia kontroli)
    - Ikona podglądu lokalizacji produktu
    - Uzupełnij wagę – jeśli towar nie ma uzupełnionej wagi
    - Uzupełnij wymiary – jeśli towar nie ma uzupełnionych wymiarów
    - Przycisk widoku rozwijanego, który dla danego towaru zwraca dane o:
      - Lokalizacja
      - Nośnik
      - Ilości
      - JM
      - Partia
      - Ikonkę usuwania
      - Ikonę zgłoszenia uszkodzenia
- Sekcję „Podstawowe informacje”, która wyświetla
  - Status dokumentu
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Data zakończenia
  - Pole „Uwagi”, tu magazynier może wpisać uwagi, przy przyjęciu.
  - Ilość palet
  - Priorytet

Bieżącą pracę z dokumentem można zakończyć przyciskami:

- Zakończ przyjęcie
- Przerwij
- Powrót

![5. Widok szczegółów dokumentu przyjęcia bezpośredniego.](\img\OIP.png)

5. Widok szczegółów dokumentu przyjęcia bezpośredniego.

## Kalendarz

Kalendarz to funkcjonalność służąca do informowania o awizowanych przyjęciach do magazynu.

Widok kalendarza zawiera:

- Przedział czasowy, w którym pokazywane są awizacje przyjęć
- Przyciski przewijania do przodu i do tyłu
- Przyciski przełączania widoków kalendarza:
  - Dzień
  - Tydzień
  - Miesiąc
- Legenda kolorów, określających statusy zamówienia
  - Niebieski – Nowe/Oczekuje na przyjęcie
  - Pomarańczowy – W przygotowaniu
  - Czerwony – Przerwano
  - Zielony – Do akceptacji/Zakończony
- Listę towarów, awizowanych na dany dzień, pozycje na liście pokazywane są:
  - W kolorze, określającym aktualny status zamówienia
  - Z nazwą awizowanego produktu
  - Z numerem zamówienia

Kliknięcie danej pozycji na liście przeniesie użytkownika do widoku szczegółów dokumentu przyjęcia.

![6. Przykładowy widok kalendarza przyjęć w systemie Asiston WMS.](\img\OIP.png)

6. Przykładowy widok kalendarza przyjęć w systemie Asiston WMS.


## Opisy procesów przyjęcia

### Przyjęcia awizowane

#### Przyjęcie awizowane, bez akceptacji

![Diagram 1. Przyjęcie awizowane, bez akceptacji.](\img\OIP.png)

Diagram 1. Przyjęcie awizowane, bez akceptacji.

W systemie ERP zostanie utworzony dokument zamówienia do dostawcy. System Asiston WMS pobierze dane z tego dokumentu i utworzy swój dokument zamówienia u dostawcy (ZD/WMS).

System WMS automatycznie:

1. pobierze datę dostawy z ZD i pozycje produktowe z numerem zamówienia do kalendarza dostaw,
1. prześle dokument do obsługi w magazynie.

Przekazane do magazynu zamówienie, system Asiston WMS doda do listy awizowanych dostaw w magazynie i nada mu status „Oczekuje na przyjęcie”.

Magazynier, rozpoczynając obsługę przyjęcia dostawy, zablokuje dokument zamówienia, który wówczas automatycznie otrzyma status "W przygotowaniu". Magazynier może przerwać obsługę dokumentu przyjęcia, wówczas dokument przyjmie status „Przerwano”.

Na podstawie listy produktów, w dokumencie ze statusem „W przygotowaniu”, magazynier zweryfikuje stan faktyczny dostawy. Proces przyjęcia odbywać się będzie poprzez zeskanowanie produktów. W jego ramach magazynier poda:

- Kod lokalizacji przyjęcia,
- Kod nośnika,
- Kod towaru,
- Numer partii,
- Ilość.

Magazynier zakończy proces przyjęcia przyciskiem „Zakończ przyjęcie”. System WMS następnie sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu i przyjętych do magazynu. Jeśli ilości te będą zgodne, system WMS automatycznie zatwierdzi przyjęcie do magazynu i zmieni status zamówienia na "Zakończone". System ERP utworzy natomiast dokument przyjęcia zewnętrznego PZ.

Jeżeli ilość przyjętych towarów będzie większa od zadeklarowanych, system przejdzie automatycznie do podprocesu obsługi nadwyżki w przyjęciu. Jeśli ilość przyjętych towarów będzie mniejsza od zadeklarowanych, system przejdzie automatycznie do podprocesu obsługi niedoboru w przyjęciu. W konfiguracji procesów zostanie na stałe określone która z tych ścieżek będzie miała zastosowanie. Szczegółowy sposób postępowania z nadwyżką oraz sposób postępowania z niedoborem - w obu możliwych ścieżkach - zostały opisane w punktach:

- Przyjęcie z zamówieniem różnicowym,
- Obsługa nadwyżki w przyjęciu,
- Częściowa realizacja przyjęcia.

Jeżeli w dostawie będzie towar na paletach, a w konfiguracji procesu przyjęcia awizowanego („Konfiguracja WMS/Procesy/Przyjęcia awizowane”), będzie zaznaczony checkbox „Przyjęcie palet”, to przyjęcie palet nastąpi odrębnym podprocesem, opisanym w punkcie Przyjęcie palet zwrotnych

Jeśli w konfiguracji procesów, proces kontroli jakości („Konfiguracja WMS/Procesy/Kontrola jakości”) nie będzie wyłączony, przyjmowane towary zostaną poddane kontroli jakości w sposób określony w konfiguracji procesu.

*Powrót do konfiguracji*

#### Przyjęcie awizowane, z początkową akceptacją

![Diagram 2. Przyjęcie awizowane, z początkową akceptacją.](\img\OIP.png)

Diagram 2. Przyjęcie awizowane, z początkową akceptacją.

Dane z dokumentu zamówienia od dostawcy – w systemie ERP – zostaną pobrane do WMS , który utworzy swój dokument zamówienia u dostawcy. Dokument ten umieści na liście zamówień ze statusem „Nowy”.

„Akceptacja”, po wejściu w szczegóły nowo pobranego zamówienia, sprawdzi poprawność danych, skoryguje planowaną datę dostawy dla wszystkich towarów w zamówieniu (z automatu daty pobrane z ZD z ERP). System WMS automatycznie pobierze tę datę i doda pozycję z zamówieniem do kalendarza dostaw. Zatwierdzenie przyciskiem „Zapisz i przekaż dalej” prześle dokument do obsługi w magazynie. Przekazane do magazynu zamówienie, system doda do listy awizowanych dostaw w magazynie i nada mu status „Oczekuje na przyjęcie”.

Magazynier, rozpoczynając obsługę przyjęcia dostawy, zablokuje dokument zamówienia, który wówczas automatycznie otrzyma status "W przygotowaniu". Na podstawie listy produktów, które powinny znaleźć się w dostawie, magazynier zweryfikuje stan faktyczny dostawy. Proces przyjęcia odbywać się będzie poprzez zeskanowanie produktów. W jego ramach magazynier poda:

- Kod lokalizacji przyjęcia (opcja, domyślna lokalizacja do skonfigurowania w konfiguracji procesu) (kłódka do zablokowania lokalizacji),
- Kod nośnika, jeśli obsługa nośników została włączona w ustawieniach WMS („Konfiguracja/Ustawienia”),
- Kod towaru,
- Numer partii,
- Ilość.

Magazynier zakończy proces przyjęcia przyciskiem „Zakończ przyjęcie”. System WMS automatycznie doda ilości towarów, przyjętych przez magazyniera, do dokumentu zamówienia u dostawcy WMS. Zmieni też status dokumentu na "Do akceptacji". WMS następnie sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu i przyjętych do magazynu. Jeśli ilości te będą zgodne, WMS automatycznie zatwierdzi przyjęcie do magazynu i zmieni status zamówienia na "Zakończone". System ERP utworzy następnie dokument przyjęcia zewnętrznego PZ.

Jeżeli ilość przyjętych towarów będzie większa od zadeklarowanych, system przejdzie automatycznie do podprocesu obsługi nadwyżki w przyjęciu. Jeśli ilość przyjętych towarów będzie mniejsza od zadeklarowanych, system przejdzie automatycznie do podprocesu obsługi niedoboru w przyjęciu, wg ścieżki „Przyjęcie z zamówieniem różnicowym” lub „Częściowa realizacja przyjęcia” W konfiguracji procesów zostanie na stałe określone która z tych ścieżek będzie miała zastosowanie. Szczegółowy sposób postępowania z nadwyżką oraz sposób postępowania z niedoborem - w obu możliwych ścieżkach - zostały opisane w punkcie „Obsługa nadwyżki w przyjęciu”.

Jeżeli w dostawie będzie towar na paletach, a w konfiguracji procesu przyjęcia awizowanego („Konfiguracja WMS/Procesy/Przyjęcia awizowane”), zostanie zaznaczony checkbox „Przyjęcie palet”, to przyjęcie palet nastąpi odrębnym podprocesem, opisanym w punkcie „Przyjęcie palet zwrotnych”.

Jeśli w konfiguracji procesów, proces kontroli jakości („Konfiguracja WMS/Procesy/Kontrola jakości”) nie będzie wyłączony, przyjmowane towary zostaną poddane kontroli jakości w sposób określony w konfiguracji procesu.

*Powrót do konfiguracji*

#### Przyjęcie awizowane, z końcową akceptacją

![Diagram 3. Przyjęcie awizowane, z końcową akceptacją.](\img\OIP.png)

Diagram 3. Przyjęcie awizowane, z końcową akceptacją.

Dane z dokumentu zamówienia od dostawcy – w systemie ERP – zostaną pobrane do WMS, który utworzy swój dokument zamówienia u dostawcy. Dokument ten umieści na liście zamówień ze statusem „Nowy”.

System WMS automatycznie:

- pobierze datę dostawy z ZD i doda pozycję z zamówieniem do kalendarza dostaw.
- prześle ten dokument do obsługi w magazynie. Przekazane zamówienie, system doda do listy awizowanych dostaw w magazynie i nada mu status „Oczekuje na przyjęcie”.

Magazynier, rozpoczynając obsługę przyjęcia dostawy, zablokuje dokument zamówienia, który wówczas automatycznie otrzyma status "W przygotowaniu". Na podstawie listy produktów, które powinny znaleźć się w dostawie, magazynier zweryfikuje stan faktyczny dostawy. Proces przyjęcia odbywać się będzie poprzez zeskanowanie produktów. W jego ramach magazynier poda:

- Kod lokalizacji przyjęcia (opcja, domyślna lokalizacja do skonfigurowania w konfiguracji procesu) (kłódka do zablokowania lokalizacji),
- Kod nośnika, jeśli obsługa nośników została włączona w ustawieniach WMS („Konfiguracja/Ustawienia”),
- Kod towaru,
- Numer partii,
- Ilość.

Magazynier zakończy proces przyjęcia przyciskiem „Zakończ przyjęcie”. System WMS automatycznie doda ilości towarów, przyjętych przez magazyniera, do dokumentu zamówienia u dostawcy WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane z przyjęcia i będzie mógł ręcznie wprowadzić zmiany (zmiana ilości towaru przyjętego na każdej lokalizacji). Jeśli nie zaakceptuje dokumentu, zwróci go do magazynu na listę awizowanych dostaw, w celu przeprowadzenia ponownego przyjęcia (magazynier widzi przyjęcie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone". Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu i przyjętych do magazynu. Jeśli ilości te będą zgodne, WMS automatycznie zatwierdzi przyjęcie do magazynu i zmieni status zamówienia na "Zakończone". System ERP utworzy natomiast dokument przyjęcia zewnętrznego PZ.

Jeżeli ilość przyjętych towarów będzie większa od zadeklarowanych, system przejdzie automatycznie do podprocesu obsługi nadwyżki w przyjęciu. Jeśli ilość przyjętych towarów będzie mniejsza od zadeklarowanych, system przejdzie automatycznie do podprocesu obsługi niedoboru w przyjęciu, wg ścieżki „Przyjęcie z zamówieniem różnicowym” lub „Częściowa realizacja przyjęcia”. W konfiguracji procesów zostanie na stałe określone która z tych ścieżek będzie miała zastosowanie. Szczegółowy sposób postępowania z nadwyżką oraz sposób postępowania z niedoborem - w obu możliwych ścieżkach - zostały opisane w punkcie „Obsługa nadwyżki w przyjęciu”.

Jeżeli w dostawie będzie towar na paletach, a w konfiguracji procesu przyjęcia awizowanego („Konfiguracja WMS/Procesy/Przyjęcia awizowane”), zostanie zaznaczony checkbox „Przyjęcie palet”, to przyjęcie palet nastąpi odrębnym podprocesem, opisanym w punkcie  „Przyjęcie palet zwrotnych”.

Jeśli w konfiguracji procesów, proces kontroli jakości („Konfiguracja WMS/Procesy/Kontrola jakości”) nie będzie wyłączony, przyjmowane towary zostaną poddane kontroli jakości w sposób określony w konfiguracji procesu.

*Powrót do konfiguracji*

#### Przyjęcie awizowane, z początkową i końcową akceptacją

![Diagram 4. Przyjęcie awizowane, z początkową i końcową akceptacją.](\img\OIP.png)

Diagram 4. Przyjęcie awizowane, z początkową i końcową akceptacją.

Dane z dokumentu zamówienia od dostawcy – w systemie ERP – zostaną pobrane do WMS , który utworzy swój dokument zamówienia u dostawcy. Dokument ten umieści na liście zamówień ze statusem „Nowy”.

„Akceptacja”, po wejściu w szczegóły nowo pobranego zamówienia, sprawdzi poprawność danych, skoryguje planowaną datę dostawy dla wszystkich towarów w zamówieniu (z automatu daty pobrane z ZD z ERPa). System WMS automatycznie pobierze tę datę i doda pozycję z zamówieniem do kalendarza dostaw. Zatwierdzenie przyciskiem „Zapisz i przekaż dalej” prześle dokument do obsługi w magazynie. Przekazane do magazynu zamówienie, system doda do listy awizowanych dostaw w magazynie i nada mu status „Oczekuje na przyjęcie”.

Magazynier, rozpoczynając obsługę przyjęcia dostawy, zablokuje dokument zamówienia, który wówczas automatycznie otrzyma status "W przygotowaniu". Na podstawie listy produktów, które powinny znaleźć się w dostawie, magazynier zweryfikuje stan faktyczny dostawy. Proces przyjęcia odbywać się będzie poprzez zeskanowanie produktów. W jego ramach magazynier poda:

- Kod lokalizacji przyjęcia (opcja, domyślna lokalizacja do skonfigurowania w konfiguracji procesu) (kłódka do zablokowania lokalizacji),
- Kod nośnika, jeśli obsługa nośników została włączona w ustawieniach WMS („Konfiguracja/Ustawienia”),
- Kod towaru,
- Numer partii,
- Ilość.

Magazynier zakończy proces przyjęcia przyciskiem „Zakończ przyjęcie”. System WMS automatycznie doda ilości towarów, przyjętych przez magazyniera, do dokumentu zamówienia u dostawcy WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane z przyjęcia i będzie mógł ręcznie wprowadzić zmiany (zmiana ilości towaru przyjętego na każdej lokalizacji). Jeśli nie zaakceptuje dokumentu, zwróci go do magazynu na listę awizowanych dostaw, w celu przeprowadzenia ponownego przyjęcia (magazynier widzi przyjęcie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone". Jeśli „Akceptacja” zatwierdzi dokument, to system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu i przyjętych do magazynu. Jeśli ilości te będą zgodne, WMS automatycznie zatwierdzi przyjęcie do magazynu i zmieni status zamówienia na "Zakończone". System ERP utworzy natomiast dokument przyjęcia zewnętrznego PZ.

Jeżeli ilość przyjętych towarów będzie większa od zadeklarowanych, system przejdzie automatycznie do podprocesu obsługi nadwyżki w przyjęciu. Jeśli ilość przyjętych towarów będzie mniejsza od zadeklarowanych, system przejdzie automatycznie do podprocesu obsługi niedoboru w przyjęciu, wg ścieżki „Przyjęcie z zamówieniem różnicowym” lub „Częściowa realizacja przyjęcia”. W konfiguracji procesów zostanie na stałe określone która z tych ścieżek będzie miała zastosowanie. Szczegółowy sposób postępowania z nadwyżką oraz sposób postępowania z niedoborem - w obu możliwych ścieżkach - zostały opisane w punkcie „Obsługa nadwyżki w przyjęciu”.

Jeżeli w dostawie będzie towar na paletach, a w konfiguracji procesu przyjęcia awizowanego („Konfiguracja WMS/Procesy/Przyjęcia awizowane”), zostanie zaznaczony checkbox „Przyjęcie palet”, to przyjęcie palet nastąpi odrębnym podprocesem, opisanym w punkcie „Przyjęcie palet zwrotnych”.

Jeśli w konfiguracji procesów, proces kontroli jakości („Konfiguracja WMS/Procesy/Kontrola jakości”) nie będzie wyłączony, przyjmowane towary zostaną poddane kontroli jakości w sposób określony w konfiguracji procesu.

*Powrót do konfiguracji*

#### Podprocesy w procesach przyjęć awizowanych

##### Obsługa niedoboru w przyjęciu

###### Przyjęcie z zamówieniem różnicowym

![Diagram 5. Przyjęcie z zamówieniem różnicowym.](\img\OIP.png)

Diagram 5. Przyjęcie z zamówieniem różnicowym.

Po stwierdzeniu niedoboru towarów w dostawie i podjęciu decyzji o dokonaniu przyjęcia z zamówieniem różnicowym, "Akceptacja" zatwierdzi przyjęcie towaru do magazynu, w ilości jaka przyjechała w dostawie. Zatwierdzenie to spowoduje, że w systemie ERP zostanie wygenerowany dokument PZ na przyjętą ilość. Na brakującą ilość towaru system ERP utworzy zamówienie różnicowe do zamówienia, z którego nastąpiło niepełne przyjęcie.

*Powrót do konfiguracji*

###### Częściowa realizacja przyjęcia

![Diagram 6. Częściowa realizacja przyjęcia.](\img\OIP.png)

Diagram 6. Częściowa realizacja przyjęcia.

Po stwierdzeniu niedoboru towarów w dostawie i podjęciu decyzji o dokonaniu częściowej realizacji przyjęcia, "Akceptacja" zatwierdzi przyjęcie towaru do magazynu, w ilości jaka przyjechała w dostawie. Zatwierdzenie to spowoduje, że w systemie ERP zostanie wygenerowany dokument PZ na przyjętą ilość towaru. Dokument zostanie przekazany ponownie do magazynu. Tam magazyn po dostarczeniu towarów ponownie będzie skanował do tego dokumentu. Towarów przyjętych za pierwszym razem nie będzie można usunąć.

*Powrót do konfiguracji*

##### Obsługa nadwyżki w przyjęciu

![Diagram 7. Obsługa nadwyżki w przyjęciu.](\img\OIP.png)

Diagram 7. Obsługa nadwyżki w przyjęciu.

Po stwierdzeniu nadwyżki towarów w dostawie i podjęciu decyzji o dokonaniu przyjęcia „Akceptacja” zatwierdzi przyjęcie towaru do magazynu, w ilości która przyjechała w dostawie. Zatwierdzenie to spowoduje, że w systemie ERP będzie utworzony PZ na zamówioną ilość towaru oraz drugi dokument PZ  na przyjętą nadwyżkę.

*Powrót do konfiguracji*

##### Przyjęcie palet zwrotnych

![Diagram 8. Przyjęcie palet zwrotnych.](\img\OIP.png)

Diagram 8. Przyjęcie palet zwrotnych.

Zdarzeniem uruchamiającym proces jest stwierdzenie przez magazyniera, że przyjmowany w dostawie towar, jest umieszczony na paletach zwrotnych. Magazynier na swoim widoku przyjęcia, z dokumentu zamówienia u dostawcy, będzie miał dostępne pole do wpisania liczby palet. Wpisze następnie liczbę przyjmowanych palet zwrotnych z towarem. Po zakończeniu przyjęcia w systemie ERP zostanie utworzony osobny dokument PZ na wpisaną przez magazyniera liczbę palet.

Warunkiem przejścia procesu opisaną ścieżką będzie wcześniejszy wybór opcji "Przyjęcie palet" w procesie przyjęcia. Opcja ta będzie powodować wybór kartoteki towarowej z systemu ERP, na którą będzie robiło się osobne PZ na ilość wskazaną przez magazyniera w przyjęciu.

*Powrót do konfiguracji** przyjęć awizowanych*

*Powrót do konfiguracji przyjęć bezpośrednich*

### Przyjęcia bezpośrednie

#### Przyjęcia bezpośrednie bez akceptacji

![Diagram 9. Przyjęcia bezpośrednie bez akceptacji](\img\OIP.png)

Diagram 9. Przyjęcia bezpośrednie bez akceptacji

Po podjęciu decyzji o bezpośrednim przyjęciu towaru, magazynier – w widoku magazynowym listy przyjęć bezpośrednich - utworzy nowy dokument przyjęcia bezpośredniego, wybierając przycisk „Dodaj przyjęcie”. Użycie przycisku zwróci formularz z polami do wypełnienia. Wypełnianie magazynier rozpocznie od wybrania typu przyjęcia: PZ – przyjęcie zewnętrzne lub PW – przyjęcie wewnętrzne. Jeśli wybierze przyjęcie zewnętrzne wskaże kontrahenta z listy rozwijanej. Jeżeli przyjęcie wewnętrzne, pole kontrahenta zostanie automatycznie ukryte. Dalej magazynier wypełni pola z danymi podstawowymi, tj.:

- Numer oryginalny (numer z dokumentu dostawcy + numer generowany),
- Tytuł,
- Opis.

Po zakończeniu wypełniania pól formularza, magazynier zapisze wprowadzone dane. Dokument przyjęcia bezpośredniego zostanie utworzony w systemie WMS i będzie dodany do listy dokumentów przyjęć bezpośrednich w widoku magazynowym ze statusem „Nowe”. Rozpoczynając przyjęcie, magazynier otworzy wybrany dokument z listy i zablokuje go do obsługi przez siebie. System WMS automatycznie nada dokumentowi na liście status „W przygotowaniu”.

Magazynier zeskanuje kod każdego towaru, uzupełni aktywne pola dokumentu i kliknie przycisk „Zapisz”. System WMS automatycznie zatwierdzi przyjęcie i nada dokumentowi status "Zakończone". System ERP wygeneruje natomiast odpowiedni dokument przyjęcia (PZ lub PW).

Jeżeli w dostawie będzie towar na paletach, a w konfiguracji procesu przyjęcia awizowanego („Konfiguracja WMS/Procesy/Przyjęcia bezpośrednie”), zostanie zaznaczony checkbox „Przyjęcie palet”, to przyjęcie palet nastąpi odrębnym podprocesem, opisanym w punkcie „Przyjęcie palet zwrotnych”.

Jeśli w konfiguracji procesów, proces kontroli jakości („Konfiguracja WMS/Procesy/Kontrola jakości”) nie będzie wyłączony, przyjmowane towary zostaną poddane kontroli jakości w sposób określony w konfiguracji procesu.

*Powrót do konfiguracji*

#### Przyjęcia bezpośrednie z końcową akceptacją

![Diagram 10. Przyjęcia bezpośrednie, z końcową akceptacją.](\img\OIP.png)

Diagram 10. Przyjęcia bezpośrednie, z końcową akceptacją.

Po podjęciu decyzji o bezpośrednim przyjęciu towaru, magazynier – w widoku magazynowym listy przyjęć bezpośrednich - utworzy nowy dokument przyjęcia bezpośredniego, wybierając przycisk „Dodaj przyjęcie”. Użycie przycisku zwróci formularz z polami do wypełnienia. Wypełnianie magazynier rozpocznie od wybrania typu przyjęcia: PZ – przyjęcie zewnętrzne lub PW – przyjęcie wewnętrzne. Jeśli wybierze przyjęcie zewnętrzne wskaże kontrahenta z listy rozwijanej. Jeżeli przyjęcie wewnętrzne, pole kontrahenta zostanie automatycznie ukryte. Dalej magazynier wypełni pola z danymi podstawowymi, tj.:

- Numer oryginalny (numer z dokumentu dostawcy + numer generowany),
- Tytuł,
- Opis.

Po zakończeniu wypełniania pól formularza, magazynier zapisze wprowadzone dane. Dokument przyjęcia bezpośredniego zostanie utworzony w systemie WMS i będzie dodany do listy dokumentów przyjęć bezpośrednich w widoku magazynowym ze statusem „Nowe”. Rozpoczynając przyjęcie, magazynier otworzy wybrany dokument z listy i zablokuje go do obsługi przez siebie. System WMS automatycznie nada dokumentowi na liście status „W przygotowaniu”.

Magazynier zeskanuje kod każdego towaru, uzupełni aktywne pola dokumentu i kliknie przycisk „Zapisz i przekaż dalej”. System WMS automatycznie przekaże dokument do akceptacji, nadając mu status "Do akceptacji". „Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane z przyjęcia i będzie mógł ręcznie wprowadzić zmiany (zmiana ilości towaru przyjętego na każdej lokalizacji). Jeśli nie zaakceptuje dokumentu, zwróci go do magazynu na listę przyjęć bezpośrednich, w celu przeprowadzenia ponownego przyjęcia (magazynier widzi przyjęcie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone". Jeśli „Akceptacja” zaakceptuje dokument, zatwierdzi go, a system WMS zmieni status zamówienia na "Zakończone". System ERP utworzy natomiast odpowiedni dokument przyjęcia (PZ lub PW).

Jeżeli w dostawie będzie towar na paletach, nastąpi przyjęcie palet odrębnym podprocesem (jeśli będzie zaznaczona ta opcja), dalej zostanie przeprowadzona kontrola jakości (również osobnym podprocesem), jeśli towar podlega kontroli jakości.

*Powrót do konfiguracji*