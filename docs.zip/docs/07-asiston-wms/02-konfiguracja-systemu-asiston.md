---
title: "Konfiguracja systemu Asiston"
sidebar_label: "7.2. Konfiguracja systemu Asiston"
---

Ustawienia konfiguracyjne będą dostępne jako lista rozwijana, w menu bocznym, pod pozycją „Konfiguracja”. Na liście dostępne będą następujące pozycje:

- „Ustawienia”,
- „Procesy”,
- „Drukarki”,
- „Szablony etykiet”,
- „Lokalizacje”,
- „Priorytety”,
- „Kody zbiorcze”,
- „Kurierzy”,

Pełne uprawnienia do konfigurowania systemu Asiston WMS będzie miał administrator. Możliwość dokonywania bieżących ustawień w systemie, przez pozostałych użytkowników, będzie wynikała z przypisanych im ról uprawnień.

## Ustawienia

Moduł „Konfiguracja /Ustawienia” służy włączania/wyłączania opcjonalnych cech i funkcjonalności, mających wpływ na sposób obsługi procesów magazynowych przez system Asiston WMS oraz na zawartość wyświetlanych informacji dla użytkownika.

### *Ustawienia ogólne*

Widok ustawień ogólnych zawiera elementy:

- Liczniki dokumentów - zliczanie dokumentów i wyświetlanie wyników w menu
  - Włączone: w menu bocznym będą wyświetlane liczby poszczególnych dokumentów oczekujących na realizację
  - Wyłączone: w menu bocznym nie będą wyświetlane liczby dokumentów.
- Waga :
  - Jednostka miary dla wagi:
    - kilogram – masa towaru i nośność lokalizacji będzie określana w kilogramach,
    - gram – masa towaru i nośność lokalizacji będzie określana w gramach,
  - Dokładność miejsc po przecinku dla wagi – pole do ręcznego wpisania liczby miejsc po przecinku, do wyświetlania wagi towaru i nośności lokalizacji.
- Wymiary:
  - Jednostka miary dla wymiarów
    - metr – wymiary towaru i lokalizacji będą określane w metrach,
    - centymetr – wymiary towaru i lokalizacji będą określane w centymetrach,
    - milimetr – wymiary towaru i lokalizacji będą określane w milimetrach
  - Dokładność miejsc po przecinku dla wymiarów – pole do ręcznego wpisania liczby miejsc po przecinku, do wyświetlania wymiarów towaru i lokalizacji.
- Dokładność miejsc po przecinku dla ilości - pole do ręcznego wpisania liczby miejsc po przecinku, do wyświetlania ilości towarów, składowanych i w trakcie operacji magazynowych.

![. Widok ustawień ogólnych, w konfiguracji systemu Asiston.](\img\Obrazy\Widok_ustawien.png)

 Widok ustawień ogólnych, w konfiguracji systemu Asiston.

### Ustawienia WMS

Włączane i wyłączane za pośrednictwem pól wyboru (checkboxów) lub list rozwijalnych. Są to:

#### Lokalizacje:

Obsługa lokalizacji w WMS:

1. Włączone: można dodawać i usuwać lokalizacje oraz ich składowe – strefa, rząd, przęsło, poziom, lokalizacja (miejsce składowania),
1. Wyłączone: możliwość dodawania i usuwania składowych lokalizacji wyłączona.

#### Strefy:

Powiązanie stref z magazynem ERP:

      1. Włączone: nazwy stref pobierane z systemu ERP, oprócz tego w systemie Asiston WMS, można dodawać i konfigurować „własne” strefy,
      1. Wyłączone: dodawanie i konfiguracja stref możliwa tylko w systemie Asiston WMS.

#### Nośniki:

Obsługa nośników systemie WMS:

  1. Włączone: można dodawać i usuwać nośniki oraz wybierać je ręcznie w operacjach magazynowych,
  1. Wyłączone, obsługa: dodawanie, usuwanie i ręczny wybór nośników są nieaktywne.

#### Partie:

Ewidencja partii w systemie WMS:

      1. Włączone: system WMS :
- Automatycznie nadaje numer partii towaru przy przyjęciu w przypadku jej nie podania
- Ręczne nadanie numeru partii towaru przy przyjęciu
- Ewidencjonuje numer partii razem z towarem w magazynie i obsługuje wyszukiwanie towaru wg partii,
- Pozwala ręcznie wybrać partię towaru, przy realizacji dokumentów magazynowych: przesunięcia, wydania, inwentaryzacja itp.
- Pozwala na ustawienia metody rozchodowania zapasu:
    - Brak – kolejność przyjęcia towaru do magazynu nie wpływa na kolejność wydania towaru;
    - FIFO – przy tworzeniu dokumentów wydania system automatycznie proponuje wydanie tych partii towaru, które były najwcześniej przyjęte do magazynu;
    - LIFO - przy tworzeniu dokumentów wydania system automatycznie proponuje wydanie tych partii towaru, które były najpóźniej przyjęte do magazynu;
- Pozwala na ewidencjonowanie dat ważności w systemie WMS
  - Włączone: dla wybranych grup produktowych. Dla towarów z wybranych grup produktowych, metoda rozchodu zapasu będzie realizowana wg FEFO.
  - Wyłączone: Ewidencja dat ważności  w systemie nieaktywna
      1. Wyłączone: Ewidencja i obsługa partii towarów nieaktywna.

![. Widok ustawień WMS, w konfiguracji systemu Asiston.](\img\Obrazy\Widok_ustawien_WMS.png)

 Widok ustawień WMS, w konfiguracji systemu Asiston.

#### Cross-Docking

        1. Włączone:
- Umożliwia powiązanie zamówienia klienta, którego nie można zrealizować z magazynu, z odpowiednim zamówieniem do dostawcy, zapewniając dostępność towaru.
- Pozwala na ograniczenie czasu magazynowania do minimum
- Umożliwia wskazanie domyślnej lokalizacji dla towarów z cross- dockingu (dodatkowe pole wyboru)
  1. Wyłączone: Obsługa zamówień cross-docking jest nieaktywna

#### Zaawansowane ustawienia lokalizacji

1. Umieszczanie towarów na lokalizacji
    - Możliwość umieszczania tylko jednego rodzaju towaru na jednej lokalizacji
    - Możliwość umieszczania wielu różnych rodzajów towarów na jednej lokalizacji
1. Sposób przeliczania zajętości lokalizacji
    - Według objętości – łączna objętość towaru na lokalizacji / objętość lokalizacji x 100%,
    - Według masy - łączna waga towaru na lokalizacji / nośność lokalizacji x 100%,
1. Walidacja umieszczania towarów na lokalizacji
    - Wyłączona
    - Wymiar produktu - system sprawdza, czy lokalizacja pozwala na przyjęcie towarów po obliczeniu objętości towarów i lokalizacji
    - Waga produktu – system sprawdza, czy waga produktu nie przekracza dopuszczalnej nośności lokalizacji
    - Wymiar nośnika – system sprawdza, czy lokalizacja pozwala na przyjęcie nośnika po obliczeniu objętości nośnika i lokalizacji
    - Wymiar nośnika + produktu – system waliduje po sumarycznej objętości nośnika i produktu
    - Ilość nośników – walidacja po polu „Ilość palet na lokalizacji”

#### Blokowanie dokumentów:

    1. Jeden użytkownik – jeżeli jeden użytkownik rozpoczął pracę z danym dokumentem magazynowym, pozostali użytkownicy nie mogą go obsługiwać, mają tylko podgląd ostatnio zapisanej zawartości dokumentu;
    1. Wielu użytkowników – system dopuszcza pracę kilku użytkowników z dokumentem magazynowym, przed zakończeniem operacji magazynowej, którą ten dokument obsługuje.

#### QR:

    1. Schemat kodu QR – pole do ręcznego wpisania schematu kodów QR, które będą tworzone w systemie Asiston.

#### Skanowanie:

1. Maksymalna ilość do zeskanowania – powyżej ustalonej wartości system będzie blokował jednorazowe skanowanie
1. Kod towaru – identyfikacja produktu – możliwość wybrania po czym system WMS będzie sprawdzał produkty
1. Automatyczne uzupełnianie pól skanera po zeskanowaniu produktu lub lokalizacji w wydaniach

#### Wyszukiwanie:

  1. Sposób działania filtrów tekstowych w module produktów
  - Ciąg znaków - system wyszukuje na podstawie następujących po sobie znaków z zachowaniem ich kolejności
- Pojedyncze słowa (Wyszukiwanie po Symbolu/Nazwie) - system wyszukuje na podstawie słów kluczowych zawartych w tekście z pominięciem wartości pomiędzy nimi

#### GS1

    1. Właczona: System WMS obsługiwany jest zgodnie z wymagami standardów GS1
    - Numery GTIN
      - Wyłączona walidacja numerów GTIN
      - Włączona walidacja numerów GTIN zgodna z GS1
      - Prefix GS1 firmy – pole umożliwiające wprowadzenie wartości testowej
      - Numery GLN - unikalny numer identyfikacyjny,  nadawany w standardzie GS1, który służy do precyzyjnego określania lokalizacji fizycznych i organizacyjnych w łańcuchu dostaw.
        - Domyślne kodowanie lokalizacji
        - Kodowanie lokalizacji zgodnie z GS1
      - Numery SSCC - umożliwiające monitorowanie paczek i palet w magazynach i transporcie
        - Wyłączona obsługa numerów  SSCC
        - Obsługa numerów SSCC zgodna z GS1
      - Obsługa kodów IZ i DataMatrix  - możliwość generowania kodów zawierzających duża ilość danych

#### Towary Uszkodzone

    1. włączona obsługa towarów uszkodzonych -
    - Generowanie dokumentu MM – możliwość wygenerowania dokumentu MM na wskazany magazyn
    - Domyślna lokalizacja końcowa – możliwość określenia domyślnej lokalizacji końcowej dla towarów uszkodzonych
    - Obsługa utylizacji dla towarów uszkodzonych
      - Generowanie dokumentu RW na towary uszkodzone
      - Brak obsługi utylizacji
    1. wyłączona obsługa towarów uszkodzonych

![. Widok ustawień za pośrednictwem list rozwijanych, w konfiguracji systemu Asiston WMS](\img\Obrazy\Ustawienia_listy.png)

 Widok ustawień za pośrednictwem list rozwijanych, w konfiguracji systemu Asiston WMS

## Procesy

Konfiguracja procesów służy do określenia:

- Przebiegu poszczególnych procesów, obsługiwanych w systemie Asiston WMS, tj. wyboru jednej z predefiniowanych ścieżek przebiegu, stosownie do specyfiki i oczekiwań klienta
- Opcji dodatkowych, mających zastosowanie do obsługi procesu,
- Konfiguracji widoków, związanych z obsługą danego procesu, dla poszczególnych ról uprawnień.

Konfiguracja procesów będzie się rozpoczynać od widoku listy nazw predefiniowanych procesów, obsługiwanych w systemie Asiston WMS. Pełny widok listy będzie zawierał dwie następujące kolumny:

- „Nazwa”,
- Akcje:
  - „Szczegóły”.

Lista może być filtrowana po nazwie, przy użyciu przycisku „Nazwa”. Przycisk zwróci popup z polem wyszukiwania, w którym należy wpisać nazwę lub fragment nazwy szukanego procesu.

![. Widok listy procesów, obsługiwanych w systemie Asiston WMS.](\img\Obrazy\Widok_lista_procesow.png)

 Widok listy procesów, obsługiwanych w systemie Asiston WMS.

Na liście procesów, obsługiwanych przez system Asiston WMS, będą:

- „Przyjęcia bezpośrednie”,
- „Zwroty”,
- „Inwentaryzacje”,
- „Wydanie awizowane”,
- „Odbiór osobisty”,
- „Kontrola jakości”,
- „Przyjęcia awizowane”,
- „Przesunięcia”,
- „Reklamacje”,
- „Wydania bezpośrednie”,
- „Kompletacje/dekompletacje”.

Po kliknięciu wiersza z nazwą procesu na liście lub przycisku akcji „Szczegóły”, użytkownik przejdzie do widoku szczegółów wybranego procesu. Widok ten będzie miał następujące sekcje:

1. „Proces główny” – z listą rozwijaną, zawierającą predefiniowane warianty wybranego procesu głównego, do wyboru;
1. „Ustawienia dodatkowe” (jeśli występują w danym procesie) – w tej sekcji będzie można – z listy rozwijanej - wybrać typ (rodzaj) dla danego wariantu procesu głównego. Wybór będzie mógł dotyczyć jednego typu (jedna lista rozwijana) albo kilku typów (dwie lub więcej list);
1. „Rozbieżności”* *(sekcja występuje w przyjęciach awizowanych, wydaniach awizowanych, odbiorach osobistych i przesunięciach) *– *z list rozwijanych pozwala wybrać sposoby postępowania w przypadku stwierdzenia nadwyżki lub niedoboru;
1. „Opcje” – miejsce wyboru obsługi dodatkowych zadań w procesie (np. agregacja zamówień i sposób ich podziału, generowanie listów przewozowych, automatyczne tworzenie dokumentu sprzedaży ).
1. „Konfiguracja widoków” – daje możliwość ustawienia jakie informacje, związane z obsługą danego procesu, będzie mógł widzieć użytkownik z określoną rolą uprawnień,
1. „Klasyfikacja towaru do kontroli jakości” (sekcja występuje w kontroli jakości)

### *Konfiguracja procesu przyjęć awizowanych*

#### Proces główny

Wybór wariantu procesu głównego będzie dokonywany przy pomocy listy rozwijanej wariantów, predefiniowanych w systemie Asiston WMS.

![. Widok wariantów procesu przyjęć awizowanych w systemie Asiston WMS.](\img\Obrazy\Wydania_awizowane_main.png)

 Widok wariantów procesu przyjęć awizowanych w systemie Asiston WMS.

##### Warianty procesu głównego

Wybór danego wariantu będzie oznaczał sposób działania systemu Asiston WMS, wg opisu dostępnego w tabeli poniżej.

| Warianty procesu głównego | Opis sposobu działania |
| --- | --- |
| Wyłączone |  |
| Przyjęcia bez akceptacji | Przyjęcia bez akceptacji. |
| Przyjęcia z końcową akceptacją | Przyjęcie awizowane z końcową akceptacją |
| Przyjęcia z początkową akceptacją | Przyjęcie awizowane, z początkową akceptacją |
| Przyjęcia z początkową i końcową akceptacją | Przyjęcie awizowane, z początkowa i końcową akceptacją |

Do szczegółowego opisu działania procesu można przejść klikając w odwołanie do nagłówka w tabeli, przy nazwie procesu *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Rozbieżności - niedobór

Sposób postępowania, w razie wystąpienia niedoboru, będzie wybierany z listy rozwijanej, w sekcji *Rozbieżności*.

![. Dostępne, do wyboru, sposoby postępowania z niedoborami w przyjęciu awizowanym.](\img\Obrazy\Wydania_awizowane_rozbieznosci.png)

 Dostępne, do wyboru, sposoby postępowania z niedoborami w przyjęciu awizowanym.

##### Podprocesy do wyboru

Wybór danego sposobu postępowania spowoduje, że system Asiston WMS obsłuży procesowo niedobór w sposób, udostępniony w tabeli poniżej.

| Podprocesy do wyboru | Opis sposobu działania |
| --- | --- |
| Wyłączone | Pozwoli na przyjęcie<br />z niedoborem (zamówienie zostanie zrealizowane częściowo). |
| Niedozwolone | Nie pozwoli na przyjęcie<br />z niedoborem. |
| Zamówienie różnicowe dla niedoborów | Przyjęcie z zamówieniem różnicowym |
| Częściowa realizacja głównego zamówienia | Częściowa realizacja przyjęcia |

Do szczegółowego opisu działania można przejść klikając w odwołanie do nagłówka w tabeli, przy nazwie wybranego podprocesu *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Rozbieżności - nadwyżki

W sekcji *Rozbieżności* należy również wybrać sposób postępowania z nadwyżką w przyjęciu. Dostępne sposoby postępowania znajdują się na liście rozwijanej.

![. . Dostępne, do wyboru, sposoby postępowania z nadwyżką w przyjęciu awizowanym.](\img\Obrazy\Wydania_awizowane_nadwyzka.png)

 Dostępne, do wyboru, sposoby postępowania z nadwyżką w przyjęciu awizowanym.

##### Podprocesy do wyboru

Wybór możliwości *Niedozwolone* oznacza, że nadwyżka w przyjęciu nie będzie obsługiwana w systemie Asiston WMS.

| Podprocesy do wyboru | Opis sposobu działania |
| --- | --- |
| Niedozwolone |  |
| Osobne PZ na towary nadwyżkowe | Obsługa nadwyżki w przyjęciu |

Do szczegółowego opisu działania, po wyborze drugiej możliwości, można przejść klikając tytuł nagłówka w tabeli *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Opcje

##### Domyślna lokalizacja przyjęć

Domyślną lokalizację przyjęć można wybrać z listy rozwijanej, na którą system Asiston WMS  pobiera wcześniej skonfigurowane lokalizacje.

![. Lista wyboru domyślnej lokalizacji przyjęć.](\img\Obrazy\Wydania_awizowane_domyslna_lokalizacja.png)

. Lista wyboru domyślnej lokalizacji przyjęć.

Jeśli zostanie zaznaczony checkbox i wybrana lokalizacja z listy, to towar będzie automatycznie przyjmowany na tę lokalizację w systemie Asiston WMS, chyba że magazynier wskaże inną lokalizację, w dokumencie danego przyjęcia.

Niezaznaczenie checkboxa lub zaznaczenie go i niewybranie domyślnej lokalizacji, spowoduje że przy każdym przyjęciu, magazynier będzie musiał – w dokumencie przyjęcia – ręcznie wpisać lokalizację, na którą przyjmowany jest towar.

##### Przyjęcie palet zwrotnych

Po zaznaczeniu checkboxa „Przyjęcie palet” system Asiston WMS obsłuży przyjęcie palet zwrotnych, razem z przyjęciem towarów do magazynu. Palety będą przyjmowane pod nazwą, którą należy wybrać z listy rozwijanej, poniżej checkboxa.

Opis przebiegu procesu przyjęcia palet został udostępniony poniżej.

| Przyjęcie palet zwrotnych | Przyjęcie palet zwrotnych |
| --- | --- |

Do opisu można przejść klikając w tytuł nagłówka, w tabeli *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

##### Numeracja dokumentów

Ustawienie to pozwala wybrać możliwość nadawania wewnętrznych numerów dla dokumentów, tworzonych w systemie Asiston WMS.

![Miejsce konfiguracji generowania wewnętrznych numerów dla dokumentów w systemie Asiston WMS.](\img\Obrazy\Wydania_awizowane_numery.png)

 Miejsce konfiguracji generowania wewnętrznych numerów dla dokumentów   
w systemie Asiston WMS.

##### Domyślny dokument realizujący przyjęcie

Ustawienie to pozwala wybrać dokument, który będzie generowany w systemie ERP po realizacji przyjęcia:

- Przyjęcie zewnętrzne (PZ),
- Przyjęcie zewnętrzne z vat (PZ z vat),
- Faktura zakupu.

##### Podpowiedzi lokalizacji przy przyjęciu

Ustawienie to pozwala na wyliczenie i wyświetlenie podpowiedzi sugerowanej lokalizacji odłożenia towaru przy przyjęcia dla magazyniera, zgodnie z wyliczeniami raportu XYZ.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia, np. magazynier.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

 Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków przedstawiają tabele poniżej.

1. Grupa „Widoki magazynu”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Ilość przyjęta | Wł./Wył. |
| JM | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Uzupełnij wagę | Wł./Wył. |
| Uzupełnij wymiary | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Pokaż lokalizacje produktu | Wł./Wył. |
| Uszkodzenia | Wł./Wył. |
| Pokaż sugerowaną lokalizację produktu | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Nr dokumentu realizującego (np. PZ) | Wł./Wył. |
| Nr dokumentu zewnętrznego | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data dostawy | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |
| Ilość palet | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |

1. Grupa „Widoki akceptacji”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Ilość przyjęta | Wł./Wył. |
| JM | Wł./Wył. |
| Termin realizacji | Wł./Wył. |
| Opis pozycji | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Nr dokumentu realizującego (np. PZ) | Wł./Wył. |
| Nr dokumentu zewnętrznego | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data dostawy | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |
| Ilość palet | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Logi | Wł./Wył. |
| Edytuj | Wł./Wył. |
| Zwróć do magazynu | Wł./Wył. |
| Wyślij do ERP | Wł./Wył. |
| Anuluj | Wł./Wył. |

### Konfiguracja procesu przyjęć bezpośrednich

#### Proces główny

Wybór wariantu procesu głównego będzie dokonywany przy pomocy listy rozwijanej wariantów, predefiniowanych w systemie Asiston WMS.

![. Widok wariantów procesu przyjęć bezpośrednich w systemie Asiston WMS.](\img\Obrazy\Przyjecia_bezposrednie_warianty.png)

. Widok wariantów procesu przyjęć bezpośrednich w systemie Asiston WMS.

##### Warianty procesu głównego

Wybór danego wariantu będzie oznaczał sposób działania, którego opis dostępny jest w tabeli poniżej.

| Warianty procesu głównego | Opis sposobu działania |
| --- | --- |
| Nie obsługuje przyjęć bezpośrednich |  |
| Przyjęcie z końcową akceptacją | Przyjęcia bezpośrednie z końcową akceptacją |
| Przyjęcie bez akceptacji | Przyjęcia bezpośrednie bez akceptacji |

Do szczegółowego opisu procesu można przejść klikając tytuł nagłówka, w tabeli, przy nazwie procesu *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Opcje

##### Domyślna lokalizacja przyjęć

Domyślną lokalizację przyjęć można wybrać z listy rozwijanej, na którą system Asiston WMS  pobiera wcześniej skonfigurowane lokalizacje.

![. Lista wyboru domyślnej lokalizacji przyjęć.](\img\Obrazy\Przyjecia_bezposrednie_lokalizacja.png)

. Lista wyboru domyślnej lokalizacji przyjęć.

Jeśli zostanie zaznaczony checkbox i wybrana lokalizacja z listy, to towar będzie automatycznie przyjmowany na tę lokalizację w systemie Asiston WMS, chyba że magazynier wskaże inną lokalizację, w dokumencie danego przyjęcia.

Niezaznaczenie checkboxa lub zaznaczenie go i niewybranie domyślnej lokalizacji, spowoduje że przy każdym przyjęciu, magazynier będzie musiał – w dokumencie przyjęcia – ręcznie wpisać lokalizację, na którą przyjmowany jest towar.

##### Przyjęcie palet zwrotnych

Po zaznaczeniu checkboxa „Przyjęcie palet” system Asiston WMS obsłuży przyjęcie palet zwrotnych, razem z przyjęciem towarów do magazynu. Palety będą przyjmowane pod nazwą, którą należy wybrać z listy rozwijanej, poniżej checkboxa.

Opis przebiegu procesu przyjęcia palet został udostępniony poniżej.

| Przyjęcie palet zwrotnych | Przyjęcie palet zwrotnych |
| --- | --- |

Do opisu można przejść klikając tytuł nagłówka, w tabeli *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

. Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których – w danej roli uprawnień -  będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków, przedstawiają tabele poniżej.

1. Grupa „Widoki magazynu”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość przyjęta | Wł./Wył. |
| JM ilości przyjętej | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Uzupełnij wymiary | Wł./Wył. |
| Uzupełnij wagę | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Pokaż lokalizacje produktu | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Nr dokumentu realizującego (np. PZ) | Wł./Wył. |
| Nr oryginalny | Wł./Wył. |
| Tytuł | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |
| Opis | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Logi | Wł./Wył. |

1. Grupa „Widoki akceptacji”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość przyjęta | Wł./Wył. |
| JM ilości przyjętej | Wł./Wył. |
| Opis pozycji | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Uszkodzenia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Nr dokumentu realizującego (np. PZ) | Wł./Wył. |
| Nr oryginalny | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Zwróć do magazynu | Wł./Wył |
| Edytuj | Wł./Wył |
| Wyślij do ERP | Wł./Wył |

### Konfiguracja procesu kontroli jakości

#### Proces główny

Wybór wariantu procesu głównego będzie dokonywany przy pomocy listy rozwijanej wariantów, predefiniowanych w systemie Asiston WMS. Po wybraniu wariantu, pod polem listy rozwijanej, pojawi się krótka informacja jak kontrola jakości będzie obsługiwana w systemie WMS.

![. Widok wyboru wariantów obsługi procesu kontroli jakości.](\img\Obrazy\Kontrola_jakosci_warianty.png)

. Widok wyboru wariantów obsługi procesu kontroli jakości.

#### Opcje

W opcjach konfiguracji procesu kontroli jakości można ustawić:

- Cechy produktu i cechy kontrahenta - w konfiguracji wyboru towaru do kontroli jakości w systemie Asiston WMS, będzie można zdecydować, czy kontroli będą poddawane towary z określoną cechą, w kartotece towarów systemu ERP, czy towary, pochodzące od kontrahentów z określną w kartotece kontrahentów systemu ERP. Cechy te należy wybrać do odpowiednich pól w widoku konfiguracji procesu.

![. Widok wyboru cechy, na podstawie której będzie wykonywana kontrola jakości.](\img\Obrazy\Kontrola_jakosci_cechy.png)

. Widok wyboru cechy, na podstawie której będzie wykonywana kontrola jakości.

- *Odrębna lokalizacja dla kontroli jakości* (checkbox):
  - Zaznaczenie checkboxa spowoduje, że w celu przeprowadzenia kontroli jakości, towar będzie przesunięty na odrębną lokalizację,
  - Odznaczenie checkboxa będzie oznaczać prowadzenie kontroli jakości na lokalizacji przyjęć.
- Postępowanie z niepełną realizacją dokumentu kontroli jakości:

![. Widok wyboru sposobu postępowania z niepełną realizacją dokumentu kontroli jakości.](\img\Obrazy\Kontrola_jakosci_niepelna.png)

. Widok wyboru sposobu postępowania z niepełną realizacją dokumentu kontroli jakości.

Po wybraniu wariantu, pod polem listy rozwijanej, pojawi się krótka informacja jak system WMS będzie go obsługiwał.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia, np. magazynier.

![Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których – w danej roli uprawnień – będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków przedstawiają tabele poniżej.

1. Grupa „Widok magazynu”
1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Zdjęcie produktu | Wł./Wył. |
| Ilość przyjęta | Wł./Wył. |
| JM ilości przyjętej | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Partia | Wł./Wył. |
| Nośnik | Wł./Wył. |

1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Dokument powiązany z przyjęcia | Wł./Wył. |
| Dostawca | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |

### Konfiguracja procesu przesunięć

#### Proces główny

W konfiguracji procesu głównego będzie dokonywany wybór włączenia lub wyłączenia obsługi przez system Asiston WMS:

1. Szybkiego przesunięcia

![ Widok wyboru włączenia/wyłączenia obsługi szybkich przesunięć.](\img\OIP.png)

 Widok wyboru włączenia/wyłączenia obsługi szybkich przesunięć.

1. Zlecenia zmiany lokalizacji

![. Widok wyboru włączenia/wyłączenia obsługi zleceń zmiany lokalizacji.](\img\OIP.png)

. Widok wyboru włączenia/wyłączenia obsługi zleceń zmiany lokalizacji.

#### Rozbieżności

W sekcji rozbieżności należy wybrać sposób postępowania w przypadku wystąpienia niedoborów podczas realizacji zlecenia zmiany lokalizacji. Do wyboru są dostępne opcje:

- Niedobór – Zlecenie zmiany lokalizacji
  - Dozwolone – będzie możliwe zakończenie przesunięcia z niedoborem,
  - Niedozwolone – nie będzie możliwe zakończenie przesunięcia z niedoborem.
- Nadwyżka – Zlecenie zmiany lokalizacji
  - Dozwolone – będzie możliwe zakończenie przesunięcia z nadwyżką,
  - Niedozwolone – nie będzie możliwe zakończenie przesunięcia z nadwyżką.

#### Opcje

- Sposób generowania ZZL dla replenishemntu – opcja dla raportu min max:
  - Jedno SKU – zostanie utworzone oddzielne zlecenie przesunięcia dla każdego towaru,
  - Wiele SKU – zostanie utworzone zbiorcze zlecenie przesunięcia z wieloma towarami
- Generuj dokument MM w ERP przy szybkim przesunięciu w przypadku kiedy lokalizacje są przypisane do innych magazynów – opcja działa tylko w przypadku, jeśli strefy są powiązane z magazynem ERP
- Podpowiedzi lokalizacji przy przyjęciu - ustawienie to pozwala na wyliczenie i wyświetlenie podpowiedzi sugerowanej lokalizacji odłożenia towaru podczas przesunięcia dla magazyniera, zgodnie z wyliczeniami raportu XYZ.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia, np. magazynier.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

. Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których – w danej roli uprawnień – będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków przedstawiają tabele poniżej.

1. Grupa „Widok magazynu”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość zebrana | Wł./Wył. |
| Ilość rozłożona | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| JM | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Pokaż sugerowaną lokalizację produktu | Wł./Wył. |

  1. Zbieranie

| Zbieranie | Wł./Wył. |
| --- | --- |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| JM | Wł./Wył. |
| Partia w zebranych pozycjach | Wł./Wył. |

  1. Rozkładanie

| Rozkładanie | Wł./Wył. |
| --- | --- |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| JM | Wł./Wył. |
| Partia w rozłożonych pozycjach | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Jednoetapowe | Wł./Wył. |
| Dwuetapowe | Wł./Wył. |
| Logi | Wł./Wył. |
| Anuluj | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Termin realizacji | Wł./Wył. |
| Rodzaj | Wł./Wył. |
| Uwagi | Wł./Wył. |
| Z magazynu | Wł./Wył. |
| Do magazynu | Wł./Wył. |

1. Grupa „Widok Tworzenia”
  1. Dodaj towary

| Dodaj towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Ilość | Wł./Wył. |
| JM | Wł./Wył. |

  1. Towary

| Towar | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość zebrana | Wł./Wył. |
| Ilość rozłożona | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Data utworzenia | Wł./Wył. |
| Termin realizacji | Wł./Wył. |
| Rodzaj | Wł./Wył. |
| Uwagi | Wł./Wył. |

### Konfiguracja procesu wydań awizowanych

#### Proces główny

Wybór wariantu procesu głównego będzie dokonywany przy pomocy listy rozwijanej wariantów, predefiniowanych w systemie Asiston WMS (jak na rysunku 34).

![.  Widok wariantów procesu wydań w systemie Asiston WMS.](\img\OIP.png)

 Widok wariantów procesu wydań w systemie Asiston WMS.

Wraz z wyborem wariantu procesu głównego, należy określić rodzaj wydań, który będzie obsługiwany w systemie Asiston WMS. Rodzaj należy wybrać z listy rozwijanej w *Ustawieniach dodatkowych*. Po wybraniu rodzaju wydań, pod polem listy rozwijanej pojawi się krótka informacja jak dany rodzaj wydania będzie obsługiwany w systemie WMS.

![. Widok wyboru rodzaju wydań.](\img\OIP.png)

 Widok wyboru rodzaju wydań.

##### Warianty procesu głównego i rodzaje wydań

Wybór danego wariantu, wraz z określonym rodzajem procesu, spowoduje, że proces będzie przebiegał w jeden ze sposobów, udostępnionych w tabeli poniżej.

| Warianty procesu głównego i rodzaje wydań | Opis sposobu działania |
| --- | --- |
| Wyłączone |  |
| Wydanie bez akceptacji |  |
| Jednoetapowe | Wydanie jednoetapowe, bez akceptacji |
| Dwuetapowe (Jednoetapowe + Kurier) | Wydanie dwuetapowe (Jednoetapowe + Kurier), bez akceptacji |
| Dwuetapowe (Zbieranie + Pakowanie) | Wydanie dwuetapowe (Zbieranie + Pakowanie), bez akceptacji |
| Trzyetapowe | Wydanie trzyetapowe, bez akceptacji |
| Wydanie z końcową akceptacją |  |
| Jednoetapowe | Wydanie jednoetapowe, z końcową akceptacją |
| Dwuetapowe (Jednoetapowe + Kurier) | Wydanie dwuetapowe (Jednoetapowe + Kurier), z końcową akceptacją |
| Dwuetapowe (Zbieranie + Pakowanie) | Wydanie dwuetapowe (Zbieranie + Pakowanie), z końcową akceptacją |
| Trzyetapowe | Wydanie trzyetapowe, z końcową akceptacją |
| Wydanie z początkową akceptacją |  |
| Jednoetapowe | Wydanie jednoetapowe, z początkową akceptacją |
| Dwuetapowe (Jednoetapowe + Kurier) | Wydanie dwuetapowe (Jednoetapowe + Kurier), z początkową akceptacją |
| Dwuetapowe (Zbieranie + Pakowanie) | Wydanie dwuetapowe (Zbieranie + Pakowanie), z początkową akceptacją |
| Trzyetapowe | Wydanie trzyetapowe, z początkową akceptacją |
| Wydanie z początkową i końcową akceptacją |  |
| Jednoetapowe | Wydanie jednoetapowe, z początkową i końcową akceptacją |
| Dwuetapowe (Jednoetapowe + Kurier) | Wydanie dwuetapowe (Jednoetapowe + Kurier), z początkową i końcową akceptacją |
| Dwuetapowe (Zbieranie + Pakowanie) | Wydanie dwuetapowe (Zbieranie + Pakowanie), z początkową i końcową akceptacją |
| Trzyetapowe | Wydanie trzyetapowe, z początkową i końcową akceptacją |

Do szczegółowego opisu działania procesu można przejść klikając tytuł nagłówka w tabeli, przy nazwie procesu *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Warunek przekazania towarów do magazynu dla towarów z niepełnym stanem

W sekcji ustawień dodatkowych istnieje możliwość wybrania warunku, na podstawie jakiego system Asiston WMS ma przekazywać towary z zamówienia do realizacji magazynu. Do wyboru są następujące opcje:

- Niedozwolone – system przekaże do realizacji towary z zamówienia tylko w przypadku, kiedy dostępność towarów pozwoli na realizację 100% zamówienia,
- Dozwolone – system przekaże do realizacji te towary z zamówienia, dla których jest jakakolwiek dostępność.

#### Rozbieżności

W sekcji rozbieżności należy wybrać sposób postępowania w przypadku wystąpienia niedoborów na etapach zbierania i pakowania. Do wyboru są dostępne opcje:

- Niedobór – zbieranie
  - Wyłączone – będzie możliwe zakończenie zbierania z niedoborem,
  - Niedozwolone – nie będzie możliwe zakończenie zbierania z niedoborem,
- Niedobór – pakowanie
  - Wyłączone – będzie możliwe zakończenie pakowania z niedoborem,
  - Niedozwolone – nie będzie możliwe zakończenie zbierania z niedoborem.
  - Zamówienie różnicowe dla niedoborów – będzie możliwe zakończenie pakowania z niedoborem. Oprócz wygenerowania dokumentu realizującego w ERP, zostanie wygenerowany także dokument różnicowy na towary, które nie zostały spakowane.

#### Opcje

W opcjach konfiguracji procesu wydań można ustawić:

##### Ogólne

- Numeracja dokumentów, do wyboru na liście rozwijanej:
  - Generowanie numerów wewnętrznych dla dokumentów,
  - Numeracja z systemu ERP.
- Aktualizacja wydań, do wyboru na liście rozwijanej:
  - Wyłączone – system Asiston WMS nie będzie pobierał aktualizacji dokumentu wydania z ERPa,
  - Włączone (bez ograniczeń) – system Asiston WMS będzie aktualizował dokument wydania do momentu jego zakończenia,
  - Włączone (ograniczenie do określonej godziny) - system Asiston WMS będzie aktualizował dokument wydania do momentu określonej godziny,
  - Włączone (określone statusy) - system Asiston WMS będzie aktualizował dokument wydania tylko dla wybranych statusów.
- Generowanie listów przewozowych, do wyboru na liście rozwijanej:
  - Brak,
  - W trakcie pakowania.
- Drukowanie listów przewozowych (opcja dostępna, jeśli „Generowanie listów przewozowych jest włączone)
  - Automatyczne, po wygenerowaniu listów przewozowych – system od razu po wygenerowaniu listów przewozowych wysyła je na drukarkę w celu wydrukowania
  - Ręcznie, po kliknięciu przycisku drukowania – po wygenerowaniu listów przewozowych, aby je wydrukować należy ręcznie wybrać przycisk do drukowania
- Wymagaj wybrania kuriera przed przekazaniem do zbierania – system Asiston WMS będzie wymagał określenia przewoźnika na dokumencie wydania,
- Domyślny dokument realizujący wydanie:
  - Brak dokumentu – po zakończeniu wydania w Asiston WMS nie będzie generowany żaden dokument w ERP
  - Wydanie zewnętrzne (WZ),
  - Faktura sprzedaży.
- Sposób podpowiedzi lokalizacji towarów do wydania – możliwość wybrania spośród:
  - Sugeruj pobranie dokładnie według najkrótszej ścieżki
  - Sugeruj w pierwszej kolejności lokalizacje, które zapewnią całe pokrycie zamówienia

##### Zbieranie

Opcje dostępne dla rodzaju wydań ze zbieraniem:

- Możliwość  agregacji zamówień do zbierania,
- Zablokowanie możliwości wyboru nośnika, jeśli jest używany w zbieraniu zagregowanym na innym zamówieniu
  - Automatyzacja agregacji
    - Sugeruj dokumenty do agregacji – system w momencie rozpoczęcia zbierania będzie sugerował, jakie dokumenty można zagregować
    - Automatyczna agregacja – system cyklicznie będzie sam agregował dokumenty do zbierania
      - Interwał sprawdzania dokumentów – ustawienie co jaki czas system ma agregować dokumenty
    - Kryteria automatycznej agregacji
      - Ilość SKU – system będzie sugerował/agregował liczbę dokumentów odpowiadającej liczbie SKU
      - Ilość dokumentów – system będzie sugerował/agregował podaną liczbę dokumentów
- Pojawianie się wskazówek dotyczących wykorzystania nośnika końcowego w procesie zbierania
- Wymaganie przez system nośnika końcowego w zbieraniu
- Zablokowanie możliwości wyboru nośnika, jeśli jest używany w innym zamówieniu
- Drukowanie etykiety kompletacyjnej po zeskanowaniu ostatniego towaru z dokumentu na zbieraniu
  - Drukowanie automatyczne – po zeskanowaniu ostatniego towaru z zamówienia zostanie wydrukowana etykieta kompletacyjna
  - Drukowanie etykiety kompletacyjnej po zeskanowaniu ostatniego towaru z dokumentu na zbieraniu – po zeskanowaniu ostatniego towaru z zamówienia zostanie najpierw wyświetlony popup z pytaniem, czy wydrukować etykietę. Po potwierdzeniu etykieta zostanie wydrukowana na drukarce.
- Podział zamówień, możliwość skonfigurowania kolejek zbierania:
  - Nazwa kolejki
  - Priorytet kolejki – określane, która kolejka ma większy priorytet
  - Typ – możliwość wybrania warunku kolejki spośród opcji:
    - Kurier
    - Cecha produktu
    - Ilość pozycji
    - Objętość zamówienia
    - Waga zamówienia
    - Strefa
    - Grupa towarowa
  - Wartość – po określeniu typu możliwość wybrania wartości dla kolejki

![. Podział zamówień](\img\OIP.png)

 Podział zamówień

##### Pakowanie

- Dostępność wyboru opakowania zbiorczego:
  - Wyłączone
  - Włączone (opakowanie wymagane) – system będzie wymagał wybrania opakowania w procesie pakowania zamówienia
  - Włączone (opakowanie opcjonalne) – możliwość opcjonalnego wybrania opakowania w procesie pakowania zamówienia
- Stanowiska pakowaczy, możliwość skonfigurowania
  - Dodanie nowego stanowiska
    - Nazwa stanowiska
    - Kod dostępu stanowiska
    - Strefy – możliwość wskazania lokalizacji pakowacza w strefie, do której magazynierzy kompletujący zamówienie będą dostarczać towary,
    - Lokalizację – możliwość wskazania konkretnej lokalizacji pakowacza, do której magazynierzy kompletujący zamówienie będą dostarczać towary
    - Drukarki – możliwość wybrania drukarek dla danego stanowiska pakowacza
    - Warunki – możliwość określenia specjalnych warunków dla stanowiska, np.:
      - Maksymalna waga dokumentu
      - Maksymalna ilość SKU
      - Grupy produktowe

![. Konfiguracja stanowisk pakowaczy](\img\OIP.png)

Konfiguracja stanowisk pakowaczy

  - Buforowa lokalizacja stanowisk pakowaczy – możliwość wybrania lokalizacji, do której będą dostarczane towary z zamówień w przypadku, kiedy ani jedno stanowisko pakowacza nie będzie aktywne
  - Warunki podziału dokumentów do pakowaczy – możliwość wybrania, czy system ma przydzielać dokumenty do spakowania wg ilości dokumentów czy ilości SKU
  - Godziny zwalniania stanowisk – możliwość określenia godziny, o której codziennie zostaną usunięciu użytkownicy ze stanowisk
  - Warunek odłożenia towarów do stanowisk pakowaczy – możliwość określenia, czy system ma wymagać odłożenie towarów do przydzielonego pakowacza czy nie.
- Generowanie i drukowanie dokumentów realizujących na pakowaniu – w pakowaniu możliwość wygenerowania i wydrukowania dokumentu WZ/FS pobranego z systemu ERP. Możliwość wyboru:
  - Dla wszystkich zamówień
  - Dla zamówień od wybranych kontrahentów (oznaczenie ustawiane w marketplace)

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień i przy wybranym wariancie procesu głównego.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia, np. magazynier.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

 Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których – w danej roli uprawnień – będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków przedstawiają tabele poniżej.

1. Grupa „Widok akceptacji”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość dostępna | Wł./Wył. |
| Ilość przekazana do realizacji | Wł./Wył. |
| Ilość zebrana | Wł./Wył. |
| Ilość wydana/spakowana | Wł./Wył. |
| JM | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Nr dokumentu realizującego (np. PZ) | Wł./Wył. |
| Pierwotny dokument | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Termin realizacji | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Logi | Wł./Wył. |
| Przekaż do magazynu | Wł./Wył. |
| Zwróć do magazynu | Wł./Wył. |
| Anuluj | Wł./Wył. |

  1. Kontrahent

| Kontrahent | Wł./Wył. |
| --- | --- |
| Adres dostawy | Wł./Wył. |
| Dokument realizujący | Wł./Wył. |

  1. Dostawa

| Dostawa | Wł./Wył. |
| --- | --- |
| Listy przewozowe | Wł./Wył. |
| Kurier | Wł./Wył. |
| Rodzaj przesyłki | Wł./Wył. |
| Ilość paczek/palet | Wł./Wył. |
| Opcje dodatkowe | Wł./Wył. |
| Dłużyca | Wł./Wył. |
| Suma obj. zamówienia | Wł./Wył. |
| Suma wagi zamówienia | Wł./Wył. |

1. Grupa „Widok wydań do kuriera”
  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Nr rejestracyjny | Wł./Wył. |

  1. Załadunek

| Załadunek | Wł./Wył. |
| --- | --- |
| Opakowanie | Wł./Wył. |
| List przewozowy | Wł./Wył. |

  1. Paczki oczekujące

| Paczki oczekujące | Wł./Wył. |
| --- | --- |
| Opakowanie | Wł./Wył. |
| List przewozowy | Wł./Wył. |
| Załaduj wszystko | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |

1. Grupa „Widok zbierania”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Ilość wydana | Wł./Wył. |
| JM | Wł./Wył. |
| Pobierz z | Wł./Wył. |
| Partia | Wł./Wył. |
| Pokaż lokalizację produktu | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Opakowanie | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Lokalizacja początkowa | Wł./Wył. |
| Nośnik początkowy | Wł./Wył. |
| Nośnik końcowy | Wł./Wył. |
| Zbieranie agregacyjne - zamówienie | Wł./Wył. |
| Zbieranie agregacyjne - widok pojedynczy | Wł./Wył. |
| Zbieranie agregacyjne - widok zbiorczy | Wł./Wył. |
| Zbieranie agregacyjne - podgląd towarów wg zamówień | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |
| Logi | Wł./Wył. |
| Zbieranie agregacyjne - dokumenty | Wł./Wył. |

1. Grupa „Widok pakowania”
1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Ilość wydana | Wł./Wył. |
| JM | Wł./Wył. |
| Pobierz z | Wł./Wył. |
| Partia | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Opakowanie | Wł./Wył. |
| Zeskanuj wszystko | Wł./Wył. |

1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |
| Logi | Wł./Wył. |

1. Dostawa

| Dostawa | Wł./Wył. |
| --- | --- |
| Listy przewozowe | Wł./Wył. |

### Konfiguracja procesu odbioru osobistego

#### Proces główny

Wybór wariantu procesu głównego będzie dokonywany przy pomocy listy rozwijanej wariantów, predefiniowanych w systemie Asiston WMS (jak na rysunku 53).

![.  Widok wariantów procesu wydań w systemie Asiston WMS.](\img\OIP.png)

  Widok wariantów procesu wydań w systemie Asiston WMS.

Wraz z wyborem wariantu procesu głównego, należy określić rodzaj wydań, który będzie obsługiwany w systemie Asiston WMS. Rodzaj należy wybrać z listy rozwijanej w *Ustawieniach dodatkowych*. Po wybraniu rodzaju wydań, pod polem listy rozwijanej pojawi się krótka informacja jak dany rodzaj wydania będzie obsługiwany w systemie WMS.

![. Widok wyboru rodzaju wydań.](\img\OIP.png)

 Widok wyboru rodzaju wydań.

##### Warianty procesu głównego i rodzaje wydań

Wybór danego wariantu, wraz z określonym rodzajem procesu, spowoduje, że proces będzie przebiegał w jeden ze sposobów, udostępnionych w tabeli poniżej.

| Warianty procesu głównego i rodzaje wydań | Opis sposobu działania |
| --- | --- |
| Wyłączone |  |
| Wydanie bez akceptacji |  |
| Jednoetapowe | Odbiór osobisty - bez akceptacji - jednoetapowy |
| Dwuetapowe (Zbieranie + Odbiór osobisty) | Odbiór osobisty - bez akceptacji - dwuetapowy |
| Wydanie z początkową akceptacją |  |
| Jednoetapowe | Odbiór osobisty - z początkową akceptacją - jednoetapowy |
| Dwuetapowe (Zbieranie + Odbiór osobisty) | Odbiór osobisty - z początkową akceptacją - dwuetapowy |
| Wydanie z końcową akceptacją |  |
| Jednoetapowe | Odbiór osobisty - z końcową akceptacją - jednoetapowy |
| Dwuetapowe (Zbieranie + Odbiór osobisty) | Odbiór osobisty - z końcową akceptacją - dwuetapowy |
| Wydanie z początkową i końcową akceptacją |  |
| Jednoetapowe | Odbiór osobisty - z początkową i końcową akceptacją - jednoetapowy |
| Dwuetapowe (Zbieranie + Odbiór osobisty) | Odbiór osobisty - z początkową i końcową akceptacją - dwuetapowy |

Do szczegółowego opisu działania procesu można przejść klikając tytuł nagłówka w tabeli, przy nazwie procesu *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Warunek przekazania towarów do magazynu dla towarów z niepełnym stanem

W sekcji ustawień dodatkowych istnieje możliwość wybrania warunku, na podstawie jakiego system Asiston WMS ma przekazywać towary z zamówienia do realizacji magazynu. Do wyboru są następujące opcje:

- Niedozwolone – system przekaże do realizacji towary z zamówienia tylko w przypadku, kiedy dostępność towarów pozwoli na realizację 100% zamówienia,
- Dozwolone – system przekaże do realizacji te towary z zamówienia, dla których jest jakakolwiek dostępność.

#### Rozbieżności

W sekcji rozbieżności należy wybrać sposób postępowania w przypadku wystąpienia niedoborów na etapach zbierania i pakowania. Do wyboru są dostępne opcje:

- Niedobór – zbieranie
  - Dozwolone – będzie możliwe zakończenie zbierania z niedoborem,
  - Niedozwolone – nie będzie możliwe zakończenie zbierania z niedoborem,
- Niedobór – odbiór osobisty
  - Dozwolone – będzie możliwe zakończenie pakowania z niedoborem,
  - Niedozwolone – nie będzie możliwe zakończenie zbierania z niedoborem.
  - Zamówienie różnicowe dla niedoborów - będzie możliwe zakończenie dokumentu z niedoborem. Oprócz wygenerowania dokumentu realizującego w ERP, zostanie wygenerowany także dokument różnicowy na towary, które nie zostały zebrane.

#### Opcje

W opcjach konfiguracji procesu wydań można ustawić:

##### Ogólne

- Numeracja dokumentów, do wyboru na liście rozwijanej:
  - Generowanie numerów wewnętrznych dla dokumentów,
  - Numeracja z systemu ERP.
- Aktualizacja wydań, do wyboru na liście rozwijanej:
  - Wyłączone – system Asiston WMS nie będzie pobierał aktualizacji dokumentu wydania z ERPa,
  - Włączone (bez ograniczeń) – system Asiston WMS będzie aktualizował dokument wydania do momentu jego zakończenia,
  - Włączone (ograniczenie do określonej godziny) - system Asiston WMS będzie aktualizował dokument wydania do momentu określonej godziny,
  - Włączone (określone statusy) - system Asiston WMS będzie aktualizował dokument wydania tylko dla wybranych statusów.
- Domyślny dokument realizujący wydanie:
  - Brak dokumentu – po zakończeniu wydania w Asiston WMS nie będzie generowany żaden dokument w ERP
  - Wydanie zewnętrzne (WZ),
  - Faktura sprzedaży.
- Sposób podpowiedzi lokalizacji towarów do wydania – możliwość wybrania spośród:
  - Sugeruj pobranie dokładnie według najkrótszej ścieżki
  - Sugeruj w pierwszej kolejności lokalizacje, które zapewnią całe pokrycie zamówienia

##### Zbieranie

Opcje dostępne dla rodzaju wydań ze zbieraniem:

- Możliwość  agregacji zamówień do zbierania,
  - Zablokowanie możliwości wyboru nośnika, jeśli jest używany w zbieraniu zagregowanym na innym zamówieniu
  - Automatyzacja agregacji
    - Sugeruj dokumenty do agregacji – system w momencie rozpoczęcia zbierania będzie sugerował, jakie dokumenty można zagregować
    - Automatyczna agregacja – system cyklicznie będzie sam agregował dokumenty do zbierania
      - Interwał sprawdzania dokumentów – ustawienie co jaki czas system ma agregować dokumenty
    - Kryteria automatycznej agregacji
      - Ilość SKU – system będzie sugerował/agregował liczbę dokumentów odpowiadającej liczbie SKU
      - Ilość dokumentów – system będzie sugerował/agregował podaną liczbę dokumentów
- Wyświetlanie wskazówek dotyczących wykorzystania nośnika końcowego w procesie zbierania
- Wymaganie przez system nośnika końcowego w zbieraniu
- Zablokowanie możliwości wyboru nośnika, jeśli jest używany w innym zamówieniu
- Drukowanie etykiety kompletacyjnej po zeskanowaniu ostatniego towaru z dokumentu na zbieraniu
  - Drukowanie automatyczne – po zeskanowaniu ostatniego towaru z zamówienia zostanie wydrukowana etykieta kompletacyjna
  - Drukowanie etykiety kompletacyjnej po zeskanowaniu ostatniego towaru z dokumentu na zbieraniu – po zeskanowaniu ostatniego towaru z zamówienia zostanie najpierw wyświetlony popup z pytaniem, czy wydrukować etykietę. Po potwierdzeniu etykieta zostanie wydrukowana na drukarce.
- Wymuszaj realizację zbierania do odbioru osobistego w pierwszej kolejności, jeśli status dokumentu ma „Oczekuje na zbieranie”
- Podział zamówień, możliwość skonfigurowania kolejek zbierania:
  - Nazwa kolejki
  - Priorytet kolejki – określane, która kolejka ma większy priorytet
  - Typ – możliwość wybrania warunku kolejki spośród opcji:
    - Kurier
    - Cecha produktu
    - Ilość pozycji
    - Objętość zamówienia
    - Waga zamówienia
    - Strefa
    - Grupa towarowa
  - Wartość – po określeniu typu możliwość wybrania wartości dla kolejki

![. Podział zamówień](\img\OIP.png)

 Podział zamówień

Opcjonalnie istnieje możliwość korzystania z takiego samego podziału, jaki został skonfigurowany w wydaniach awizowanych.

##### Odbiór osobisty

- Generowanie i drukowanie dokumentów realizujących na pakowaniu
  - Dla wszystkich zamówień
  - Dla zamówieni wybranych kontrahentów (oznaczenie ustawiane w marketplace)
- Ekran odbiorów osobistych – możliwość włączenia monitora oraz skonfigurowania danych, jakie będzie wyświetlał:
  - Widoczność kolumny 'Nr ZK'
  - Wyodrębniony numer dokumentu
  - Widoczność kolumny „Status”
  - Widoczność kolumny „Kontrahent”
  - Widoczność kolumny „Nr klienta”
  - Widoczność kolumny „Data wystawienia dokumentu
  - Widoczność kolumny „Pasek postępu”
  - Widoczność kolumny „Szacowany czas realizacji”
  - Ogranicz widoczność dokumentów do (liczba dni) – ustawienie, które ukrywa przestarzałe dokumenty na monitorze

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień i przy wybranym wariancie procesu głównego.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia, np. magazynier.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

 Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których – w danej roli uprawnień – będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków przedstawiają tabele poniżej.

1. Grupa „Widok akceptacji”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Ilość dostępna | Wł./Wył. |
| Ilość przekazana do realizacji | Wł./Wył. |
| JM | Wł./Wył. |
| Ilość zebrana | Wł./Wył. |
| Ilość wydana/spakowana | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Nr dokumentu realizującego (np. PZ) | Wł./Wył. |
| Pierwotny dokument | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Termin realizacji | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Logi | Wł./Wył. |
| Przekaż do magazynu | Wł./Wył. |
| Zwróć do magazynu | Wł./Wył. |
| Anuluj | Wł./Wył. |

  1. Kontrahent

| Kontrahent | Wł./Wył. |
| --- | --- |
| Adres dostawy | Wł./Wył. |
| Dokument realizujący | Wł./Wył. |

  1. Dostawa

| Dostawa | Wł./Wył. |
| --- | --- |
| Listy przewozowe | Wł./Wył. |

1. Grupa „Widok zbierania”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Ilość wydana | Wł./Wył. |
| JM | Wł./Wył. |
| Pobierz z | Wł./Wył. |
| Partia | Wł./Wył. |
| Pokaż lokalizacje produktu | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Opakowanie | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Lokalizacja początkowa | Wł./Wył. |
| Nośnik początkowy | Wł./Wył. |
| Nośnik końcowy | Wł./Wył. |
| Zbieranie agregacyjne - zamówienie | Wł./Wył. |
| Zbieranie agregacyjne - widok pojedynczy | Wł./Wył. |
| Zbieranie agregacyjne - widok zbiorczy | Wł./Wył. |
| Zbieranie agregacyjne - podgląd towarów wg zamówień | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |
| Logi | Wł./Wył. |
| Zbieranie agregacyjne - dokumenty | Wł./Wył. |

1. Grupa „Widok odbioru osobistego”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Zeskanuj wszystko | Wł./Wył. |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Ilość wydana | Wł./Wył. |
| JM | Wł./Wył. |
| Pobierz z | Wł./Wył. |
| Partia | Wł./Wył. |
| Pokaż lokalizację produktu | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |
| Logi | Wł./Wył. |

### *Konfiguracja procesu wydania bezpośredniego*

#### Proces główny

Wybór wariantu procesu głównego będzie dokonywany przy pomocy listy rozwijanej wariantów, predefiniowanych w systemie Asiston WMS.

![. Widok wariantów procesu wydań bezpośrednich w systemie Asiston WMS.](\img\OIP.png)

 Widok wariantów procesu wydań bezpośrednich w systemie Asiston WMS.

##### Warianty procesu głównego

Wybór danego wariantu będzie oznaczał sposób działania, którego opis dostępny jest w tabeli poniżej.

| Warianty procesu głównego | Opis sposobu działania |
| --- | --- |
| Nie obsługuje wydań bezpośrednich |  |
| Wydanie bezpośrednie z końcową akceptacją | Wydanie bezpośrednie z końcową akceptacją |
| Wydanie bezpośrednie bez akceptacji | Wydanie bezpośrednie bez akceptacji |

Do szczegółowego opisu procesu można przejść klikając tytuł nagłówka w tabeli, przy nazwie procesu *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

 Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których – w danej roli uprawnień -  będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków, przedstawiają tabele poniżej.

1. Grupa „Widoki magazynu”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość | Wł./Wył. |
| JM ilości | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Uzupełnij wymiary | Wł./Wył. |
| Uzupełnij wagę | Wł./Wył. |
| Pokaż lokalizacje produktu | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Nr dokumentu realizującego (np. WZ) | Wł./Wył. |
| Nr oryginalny | Wł./Wył. |
| Tytuł | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Logi | Wł./Wył. |

1. Grupa „Widoki akceptacji”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość wydana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Nr dokumentu realizującego (np. PZ) | Wł./Wył. |
| Nr oryginalny | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Zwróć do magazynu | Wł./Wył |
| Edytuj | Wł./Wył |
| Wyślij do ERP | Wł./Wył |

### Konfiguracja procesu zwrotów

#### Proces główny

Wybór wariantu procesu głównego będzie dokonywany przy pomocy listy rozwijanej wariantów, predefiniowanych w systemie Asiston WMS.

![. Widok wariantów procesu zwrotów w systemie Asiston WMS.](\img\OIP.png)

 Widok wariantów procesu zwrotów w systemie Asiston WMS.

##### Warianty procesu głównego

Wybór danego wariantu będzie oznaczał sposób działania systemu Asiston WMS, wg opisu dostępnego w tabeli poniżej.

| Warianty procesu głównego | Opis sposobu działania |
| --- | --- |
| Wyłączony | System nie obsługuje zwrotów, moduł zwrotów jest niewidoczny w menu systemu Asiston WMS |
| Włączony | Zwroty |

Do szczegółowego opisu działania procesu można przejść klikając nazwę nagłówka w tabeli, przy nazwie procesu *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Opcje

##### Numeracja dokumentów

Ustawienie to pozwala wybrać możliwość nadawania wewnętrznych numerów dla dokumentów, tworzonych w systemie Asiston WMS. Dostępne są dwie opcje na liście rozwijanej:

- Generowanie numerów wewnętrznych dokumentów,
- Numeracja z systemu ERP.

![. Miejsce konfiguracji generowania wewnętrznych numerów dla dokumentów    w systemie Asiston WMS.](\img\OIP.png)

 Miejsce konfiguracji generowania wewnętrznych numerów dla dokumentów   
w systemie Asiston WMS.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia, np. magazynier.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

 Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków przedstawiają tabele poniżej.

1. Grupa „Widoki magazynu”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość awizowana | Wł./Wył. |
| Ilość przyjęta | Wł./Wył. |
| JM | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Uzupełnij wagę | Wł./Wył. |
| Uzupełnij wymiary | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Pierwotny dokument | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Opis z ERP | Wł./Wył. |
| Uwagi z WMS | Wł./Wył. |
| Sposób dostawy | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |

### Konfiguracja procesu inwentaryzacji

#### Proces główny

Na wybór wariantu procesu głównego będą się składać decyzje dotyczące obsługi typów inwentaryzacji:

1. Inwentaryzacja całościowa, która obejmuje spis z natury całego stanu magazynowego:
  1. Włączona
  1. Wyłączona

![. Widok pola wyboru wariantu inwentaryzacji całościowej w systemie Asiston WMS.](\img\OIP.png)

 Widok pola wyboru wariantu inwentaryzacji całościowej w systemie Asiston WMS.

1. Inwentaryzacja produktu – spis danego produktu w magazynie:
  1. Włączona
  1. Wyłączona

![. Widok pola wyboru wariantu inwentaryzacji produktu w systemie Asiston WMS.](\img\OIP.png)

 Widok pola wyboru wariantu inwentaryzacji produktu w systemie Asiston WMS.

1. Inwentaryzacja lokalizacji – spis wszystkich produktów na danej lokalizacji w magazynie:
  1. Włączona
  1. Wyłączona

![. Widok pola wyboru wariantu inwentaryzacji lokalizacji w systemie Asiston WMS.](\img\OIP.png)

 Widok pola wyboru wariantu inwentaryzacji lokalizacji w systemie Asiston WMS.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

 Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których – w danej roli uprawnień - będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków, przedstawiają tabele poniżej.

Grupa „Widoki magazynu”

  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Zdjęcia | Wł./Wył. |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość | Wł./Wył. |
| JM | Wł./Wył. |
| RW | Wł./Wył. |
| PW | Wł./Wył. |
| Drukarka | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Stan przed | Wł./Wył. |
| Partia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Typ inwentaryzacji | Wł./Wył. |
| Nr dokumentu z ERP | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Magazyn | Wł./Wył. |
| Uwagi | Wł./Wył. |
| Uwagi do inwentaryzacji zbiorczej | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Utwórz inwentaryzację zbiorczą | Wł./Wył. |
| Dodaj inwentaryzację częściową | Wł./Wył. |
| Zakończ inwentaryzację | Wł./Wył |
| Rozpocznij | Wł./Wył |
| Zakończ inwentaryzację cząstkową | Wł./Wył |
| Przerwij | Wł./Wył |
| Usuń | Wł./Wył |
| Logi | Wł./Wył |
| Skanowanie zbiorcze strefy | Wł./Wył |

### Konfiguracja procesu reklamacji

#### Proces główny

Wybór wariantu procesu głównego będzie dokonywany przy pomocy listy rozwijanej wariantów, predefiniowanych w systemie Asiston WMS.

![ Widok wariantów procesu zwrotów w systemie Asiston WMS.](\img\OIP.png)

 Widok wariantów procesu zwrotów w systemie Asiston WMS.

##### Warianty procesu głównego

Wybór danego wariantu będzie oznaczał sposób działania systemu Asiston WMS, wg opisu dostępnego w tabeli poniżej.

| Warianty procesu głównego | Opis sposobu działania |
| --- | --- |
| Wyłączony | System nie obsługuje reklamacji, moduł reklamacji jest niewidoczny w menu systemu Asiston WMS |
| Reklamacje z końcową akceptacja | Zwroty |
| Reklamacje bez akceptacji | Zwroty |

Do szczegółowego opisu działania procesu można przejść klikając nazwę nagłówka, w tabeli, przy nazwie procesu *(**Ctrl** + Kliknięcie lewym klawiszem myszy)*.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia, np. magazynier.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

 Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków przedstawiają tabele poniżej.

1. Grupa „Widok Akceptacji”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod towaru | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Ilość na dokumencie sprzedaży | Wł./Wył. |
| Ilość reklamowana | Wł./Wył. |
| Ilość przyjęta | Wł./Wył. |
| JM | Wł./Wył. |
| Wydruk etykiety | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Status | Wł./Wył. |
| Numer dokumentu sprzedaży | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Żądanie reklamującego | Wł./Wył. |
| Data powstania wady | Wł./Wył. |
| Data zgłoszenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Sposób odesłania zgłaszanego towaru | Wł./Wył. |
| Opis usterki | Wł./Wył. |
| Powód odrzucenia reklamacji | Wł./Wył. |
| Załączniki | Wł./Wył. |
| Uwagi | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |
| Powiązane dokumenty | Wł./Wył. |

1. Grupa „Widok przyjęcia”
  1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod towaru | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Ilość | Wł./Wył. |
| JM | Wł./Wył. |
| Wydruk etykiety | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Status | Wł./Wył. |
| Numer dokumentu sprzedaży | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Żądanie reklamującego | Wł./Wył. |
| Data powstania wady | Wł./Wył. |
| Data zgłoszenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Sposób odesłania zgłaszanego towaru | Wł./Wył. |
| Opis usterki | Wł./Wył. |
| Powód odrzucenia reklamacji | Wł./Wył. |
| Załączniki | Wł./Wył. |
| Uwagi | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |

1. Grupa „Widok wydania”
1. Towary

| Towary | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod towaru | Wł./Wył. |
| Zdjęcia | Wł./Wył. |
| Ilość | Wł./Wył. |
| JM | Wł./Wył. |
| Podgląd lokalizacji | Wł./Wył. |
| Wydruk etykiety | Wł./Wył. |

1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Kontrahent | Wł./Wył. |
| Status | Wł./Wył. |
| Numer dokumentu sprzedaży | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Żądanie reklamującego | Wł./Wył. |
| Data powstania wady | Wł./Wył. |
| Data zgłoszenia | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Sposób odesłania zgłaszanego towaru | Wł./Wył. |
| Opis usterki | Wł./Wył. |
| Uwagi | Wł./Wył. |

1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |

### Konfiguracja procesu kompletacji i dekompletacji

#### Proces główny

W konfiguracji procesu głównego będzie dokonywany wybór włączenia lub wyłączenia obsługi przez system Asiston WMS:

1. Kompletacji

![ Widok wyboru wariantu procesu kompletacji](\img\OIP.png)

 Widok wyboru wariantu procesu kompletacji

1. Dekompletacja

![. Widok wyboru wariantu procesu dekompletacji](\img\OIP.png)

 Widok wyboru wariantu procesu dekompletacji

#### Opcje

- Domyślną lokalizację dla kompletacji  - możliwość określenia - z listy rozwijanej – domyślnej lokalizację, na którą będą przesuwane towary do kompletacji.
- Domyślną lokalizację dla dekompletacji  - możliwość określenia - z listy rozwijanej – domyślnej lokalizację, na którą będą przesuwane towary do dekompletacji.

#### Konfiguracja widoków

Konfiguracja widoków służy określeniu które dane będą włączone do widoków lub wyłączone, dla użytkowników o wskazanej roli uprawnień.

Konfiguracja widoków rozpocznie się o wybrania roli uprawnień, dla której tworzymy ustawienia, np. magazynier.

![. Widok wyboru roli uprawnień do konfiguracji widoków.](\img\Obrazy\Widoki_user.png)

 Widok wyboru roli uprawnień do konfiguracji widoków.

W kolejnym kroku możliwe będzie ustawienie dostępu do całych grup widoków, w ramach których – w danej roli uprawnień – będzie można osobno włączać lub wyłączać dostęp do poszczególnych danych. Szczegółową strukturę konfiguracji widoków przedstawiają tabele poniżej.

1. Grupa „Widok akceptacji (kompletacji)”
  1. Komplet

| Komplet | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość do skompletowania | Wł./Wył. |
| Ilość skompletowana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Składniki

| Składniki | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość do wykorzystania | Wł./Wył. |
| Ilość wykorzystana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Status | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data realizacji | Wł./Wył. |
| Tworzenie ZZL | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Dokument przesunięcia | Wł./Wył. |
| Uwagi do kompletacji | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Przekaż do magazynu | Wł./Wył. |
| Zwróć do edycji | Wł./Wył. |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Logi | Wł./Wył. |
| Anuluj | Wł./Wył. |

1. Grupa „Widok akceptacji (Dekompletacja)”
  1. Komplet

| Komplet | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość do skompletowania | Wł./Wył. |
| Ilość skompletowana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Składniki

| Składniki | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość do wykorzystania | Wł./Wył. |
| Ilość wykorzystana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Status | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data realizacji | Wł./Wył. |
| Tworzenie ZZL | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Dokument przesunięcia | Wł./Wył. |
| Uwagi do kompletacji | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Przekaż do magazynu | Wł./Wył. |
| Zwróć do edycji | Wł./Wył. |
| Pokaż powiązane dokumenty | Wł./Wył. |
| Logi | Wł./Wył. |
| Anuluj | Wł./Wył. |

1. Grupa „Widok Kompletacji”
  1. Komplet

| Komplet | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość do skompletowania | Wł./Wył. |
| Ilość skompletowana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Składniki

| Składniki | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość do wykorzystania | Wł./Wył. |
| Ilość wykorzystana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Lokalizacja produktu | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

  1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Status | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data realizacji | Wł./Wył. |
| Tworzenie ZZL | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Dokument przesunięcia | Wł./Wył. |
| Uwagi do kompletacji | Wł./Wył. |

  1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |
| Anuluj | Wł./Wył. |

1. Grupa „Widok Dekompletacji”
1. Komplet

| Komplet | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość do skompletowania | Wł./Wył. |
| Ilość skompletowana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Lokalizacja produktu | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

1. Składniki

| Składniki | Wł./Wył. |
| --- | --- |
| Symbol produktu | Wł./Wył. |
| Nazwa produktu | Wł./Wył. |
| Kod produktu | Wł./Wył. |
| Ilość do wykorzystania | Wł./Wył. |
| Ilość wykorzystana | Wł./Wył. |
| JM | Wł./Wył. |
| Lokalizacja | Wł./Wył. |
| Nośnik | Wł./Wył. |
| Partia | Wł./Wył. |
| Zdjęcia | Wł./Wył. |

1. Podstawowe informacje

| Podstawowe informacje | Wł./Wył. |
| --- | --- |
| Status | Wł./Wył. |
| Data utworzenia | Wł./Wył. |
| Data realizacji | Wł./Wył. |
| Tworzenie ZZL | Wł./Wył. |
| Data zakończenia | Wł./Wył. |
| Dokument przesunięcia | Wł./Wył. |
| Uwagi do kompletacji | Wł./Wył. |

1. Ogólne

| Ogólne | Wł./Wył. |
| --- | --- |
| Logi | Wł./Wył. |
| Anuluj | Wł./Wył. |

## Drukarki

Konfiguracja drukarek służy:

1. Udostępnieniu ich dla użytkowników w systemie Asiston WMS,
1. Określeniu sposobu ich wykorzystania (np. drukowanie dokumentów lub etykiet z kodami).

Po przejściu do konfiguracji drukarek („Konfiguracja WMS/Drukarki”) użytkownik otrzyma listę skonfigurowanych już drukarek. Pełny zestaw kolumn, w widoku listy, obejmuje następujące dane:

- Nazwa,
- Typ drukarki,
- Rodzaj drukarki,
- Opis,
- Szerokość,
- Wysokość ,
- Akcje:
  - Edytuj
  - Usuń

Lista może być filtrowana wg:

- Nazwy,
- Typu – wybór predefiniowanych typów słownikowych z listy rozwijanej,
- Rodzaju – także wybór z listy rozwijanej predefiniowanych typów słownikowych.

![. Widok listy drukarek w systemie Asiston WMS.](\img\OIP.png)

 Widok listy drukarek w systemie Asiston WMS.

Nową drukarkę do listy będzie można dodać przyciskiem „Dodaj drukarkę”. Użycie przycisku zwraca widok, w którym należy określić:

- Nazwę drukarki – pole wymagane
- Opis
- Rodzaj – pole wymagane
  - Globalne – dla wszystkich użytkowników
  - Użytkownika – dla konkretnego użytkownika
- Typ – pole wymagane
  - Zebra bezprzewodowa – po wybraniu tego typu, pojawią dodatkowe opcje do uzupełnienia:
    - Nazwa – pole wymagane
    - Adres IP – pole wymagane
    - Port – pole wymagane
    - Szerokość strony – pole wymagane
    - Wysokość strony – pole wymagane
    - DPI – pole wymagane
  - Windows – po wybraniu tego typu, pojawią dodatkowe opcje do uzupełnienia:
    - Nazwa – pole wymagane
    - Szerokość strony – pole wymagane
    - Wysokość strony – pole wymagane
  - PDF – po wybraniu tego typu, pojawią dodatkowe opcje do uzupełnienia:
    - Szerokość strony – pole wymagane
    - Wysokość strony – pole wymagane

System Asiston WMS będzie również obsługiwał dodawanie drukarek, dostępnych w sieci. W tym celu należy użyć przycisku „Wyszukaj drukarkę w sieci”. System – w sekcji poniżej - zwróci listę znalezionych drukarek do wyboru.

![. Widok dodawania drukarki w systemie Asiston WMS.](\img\OIP.png)

 Widok dodawania drukarki w systemie Asiston WMS.

Z widoku listy drukarek można będzie wejść do szczegółów wybranej drukarki. Widok szczegółów będzie zwracał pola jak w formularzu dodawania drukarki oraz sekcję „Drukowanie etykiety na urządzeniu”, do wyboru rodzajów etykiet, które będą mogły być drukowane na wybranym urządzeniu. Zestaw rodzajów etykiet do wyboru, przedstawia tabela poniżej.

| Drukowanie etykiety na urządzeniu | Wł./Wył. |
| --- | --- |
| Etykieta kodu zbiorczego | Wł./Wył. |
| Etykieta nośnika stałego | Wł./Wył. |
| Etykieta kompletacyjna | Wł./Wył. |
| Zewnętrzny dokument wydania | Wł./Wył. |
| Etykieta lokalizacji | Wł./Wył. |
| Etykieta logistyczna | Wł./Wył. |
| Etykieta opakowania | Wł./Wył. |
| Etykieta produktu | Wł./Wył. |
| Etykiety listów przewozowych | Wł./Wył. |

Wszystkie pola, widoczne, w szczegółach drukarki, będą edytowalne, można zmieniać ich zawartość. Wprowadzone zmiany należy zapisać przyciskiem „Zapisz” lub „Zapisz i wróć”. Widok szczegółów został przedstawiony na.

![. Widok szczegółów drukarki, w systemie Asiston WMS.](\img\OIP.png)

 Widok szczegółów drukarki, w systemie Asiston WMS.

## Szablony etykiet

Konfiguracja szablonów etykiet służy do tworzenia wyglądu etykiet, generowanych w systemie Asiston WMS i umieszczanych na:

- Produktach jednostkowych,
- Opakowaniach zbiorczych, używanych do pakowania,
- Opakowaniach zbiorczych, jako jednostkach wysyłkowych,
- Lokalizacjach,
- Nośnikach stałych

Podstawowym widokiem konfiguracji szablonów etykiet jest ich lista, zawierająca predefiniowane szablony. Każdy szablon, dostępny na liście, będzie miał:

- Rodzaj etykiety (możliwość sortowania nazw rosnąco i malejąco),
- Przycisk: Akcje:
  - Szczegóły.

![. Widok listy szablonów etykiet w konfiguracji WMS.](\img\OIP.png)

 Widok listy szablonów etykiet w konfiguracji WMS.

Po wejściu do szczegółów zostanie otwarty formularz, zawierający:

- Sekcję do tworzenia treści i podglądu szablonu, z dwiema zakładkami:
  - „Treść szablonu” – obsługująca wpisywanie i edycję tekstu,
  - „Podgląd” – pokazuje utworzony szablon etykiety na podglądzie
- Zakładkę „Właściwości” z polami:
  - „Nazwa” – bez możliwości edycji nazwy,
  - „Rozmiar wydruku” – możliwość ustawienia rozmiaru w dwóch wymiarach:
    - Szerokość
    - Wysokość
  - „Orientacja” – wybór z lity rozwijanej:
    - Horyzontalna
    - Wertykalna
  - „Dodaj logo” – obsługuje pobieranie logo z pliku oraz zwraca jego podgląd
- Zakładkę „Pola dokumentu”, wyświetlającą listę zmiennych, które będzie można użyć w projektowaniu etykiety. Zmienne wyświetlane są w układzie:
  - Kod
  - Opis

Zestaw zmiennych, widocznych w tej zakładce, uzależniony będzie od rodzaju etykiety, której dotyczy. Będą to następujące zmienne:

    - Etykieta kodu zbiorczego:
      - Nazwa produktu,
      - Kod EAN produktu
      - Symbol produktu
      - Waga produktu
      - Wysokość produktu
      - Szerokość produktu
      - Długość produktu
      - Jednostka miary
      - Zdjęcie produktu
      - Kod kreskowy zbiorczy
      - Ilość pod kodem zbiorczym
    - Etykieta lokalizacji
      - Nazwa strefy
      - Kod rzędu
      - Kod lokalizacji
    - Etykieta nośnika stałego:
      - Nazwa nośnika
      - Kod nośnika
    - Etykieta opakowania:
      - Nazwa opakowania
      - Stały kod opakowania
      - Jednorazowy kod opakowania
    - Etykieta produktu:
      - Nazwa produktu
      - Kod EAN produktu
      - Symbol produktu
      - Waga produktu
      - Wysokość produktu
      - Szerokość produktu
      - Długość produktu
      - Jednostka miary
      - Zdjęcie produktu
      - Partia
    - Etykieta Kompletacjyjna

Pola:

      - Numer głównego ZK

Kolumny:

      - Symbol towaru
      - Nazwa towaru
      - Ilość
    - Etykieta Logistyczna
      - Numer opakowania/SSCC
      - Suma wszystkich sztuk towarów
      - Data ważności
      - Partia
      - Nazwa produktu
      - Symbol produktu
      - EAN produktu

![. Widok szczegółów szablonu etykiety.](\img\OIP.png)

 Widok szczegółów szablonu etykiety.

## Lokalizacje

Pozycja „Konfiguracja WMS/Lokalizacje” będzie zawierać następujące podpozycje, dostępne w formie listy rozwijanej:

- „Strefy”,
- „Budynki”,
- „Typy stref”,
- „Rodzaje lokalizacji”,
- „Konfiguracja ścieżki”,

### Strefy

Strefy są to zbiory lokalizacji, pogrupowanych zwykle pod względem funkcjonalnym, np. strefa przyjęć, wydań, odkładcza (składowania) itp.

Podstawowy widok stref wyświetlany będzie jako lista z kolumnami:

- „Nazwa”,
- „Typ”,
- „Budynek”,
- „Magazyn”,
- „Aktywna”,
- Akcje:
  - „Edytuj”,
  - „Usuń”.

Listę stref będzie można filtrować wg następujących kryteriów:

- „Nazwa strefy”* - *nazwę lub jej fragment należy wpisać w polu tekstowym,
- „Kod lokalizacji w strefie” – w polu wyszukiwania skanujemy lub wpisujemy kod lokalizacji,
- „Typ” - lista rozwijana z typami, które zostały wcześniej utworzone przy użyciu funkcjonalności „Konfiguracja WMS/Lokalizacje/Typy stref”, możliwość wybrania kilku stref,
- „Budynek”* -* lista rozwijana z wartościami, pochodzącym z konfiguracji budynków *Konfiguracja WMS/Lokalizacje/Budynki*, możliwość wybrania kilku budynków,
- „Magazyn ERP” - lista rozwijana z wartościami, pobranymi z integracji, z ERP (można wybrać kilka magazynów); Ten przycisk filtrowania jest widoczny tylko gdy wcześniej zaznaczono *Powiązanie stref z magazynem ERP*, w widoku *Konfiguracja WMS/Ustawienia*.
- „Aktywna” – lista rozwijana:
  - „Wszystkie”,
  - „Tak”,
  - „Nie”.

![. Widok listy stref w systemie Asiston WMS.](\img\OIP.png)

 Widok listy stref w systemie Asiston WMS.

Ponadto z poziomu listy będzie możliwość zaimportowania lokalizacji z excela oraz ich wyeksportowanie.

#### Dodawanie strefy

Strefę będzie można dodać przy użyciu przycisku „Dodaj strefę”, w widoku listy stref. Kliknięcie przycisku zwróci widok formularza dodawania strefy.

![. Widok dodawania strefy w systemie Asiston WMS.](\img\OIP.png)

 Widok dodawania strefy w systemie Asiston WMS.

Formularz będzie zawierał następujące, obowiązkowe pola do wypełnienia:

- „Nazwa strefy”* (wpisywana ręcznie nazwa tworzonej strefy)*,
- „Typ” – lista rozwijana z typami, które zostały wcześniej utworzone przy użyciu funkcjonalności „Konfiguracja WMS/Lokalizacje/Typy”,
- „Magazyn ERP” – lista rozwijana z nazwami magazynów, pobranymi z integracji, z ERP; ten przycisk filtrowania jest widoczny tylko gdy wcześniej zaznaczono „Powiązanie stref z magazynem ERP”, w widoku „Konfiguracja WMS/Ustawienia”,
- „Budynek” – lista rozwijana - możliwość wybrania jednej wartości pochodzącej z pozycji „Konfiguracja WMS/Lokalizacje/Budynki”,
- „Aktywna” – lista rozwijana:
  - „Nie”,
  - „Tak”.

#### Szczegóły strefy

Widok szczegółów strefy zwróci dane podstawowe oraz układ lokalizacji, utworzonych w danej strefie.

W sekcji „Dane podstawowe” będą widoczne pola jak w formularzu dodawania strefy (*punkt* 7.2.5.1.1), z możliwością edycji i zmiany. Wprowadzone zmiany będzie można zapisać przyciskami „Zapisz” lub „Zapisz i wróć” (przyciski widoczne po przewinięciu ekranu w dół).

![. Widok szczegółów strefy, sekcja" Dane podstawowe".](\img\OIP.png)

 Widok szczegółów strefy, sekcja" Dane podstawowe".

Sekcja „Lokalizacje” zwróci widok rozmieszczenia lokalizacji w strefie. Konfiguracja lokalizacji w strefie będzie zawierać następujące składniki:

- „Rząd”,
- „Przęsło”,
- „Poziom”,
- „Lokalizacja” (pojedyncze miejsce składowania).

![. Widok szczegółów strefy, sekcja" Lokalizacje".](\img\OIP.png)

Widok szczegółów strefy, sekcja" Lokalizacje".

#### Dodawanie rzędu

Dodawanie rzędu rozpocznie się od kliknięcia przycisku „Dodaj rząd” w widoku szczegółów strefy. Użycie przycisku uruchomi konfigurator, w którym znajdują się sekcje do określania poszczególnych składowych tworzonego rzędu.

##### Konfigurator rzędu

- Konfigurator rzędu będzie włączany lub wyłączany suwakiem „Pusty rząd”.
- Ustawienie suwaka w pozycji włączonej (i zapisanie tej konfiguracji, spowoduje automatyczne utworzenie jednego przęsła i jednego poziomu. Dodawanie kolejnych przęseł, poziomów i lokalizacji będzie możliwe ręcznie, po kliknięciu dedykowanych przycisków, w widoku szczegółów strefy, w sekcji „Lokalizacje”;
- Suwak w pozycji wyłączonej udostępni – przy pomocy konfiguratora rzędu – możliwość wprowadzenia liczby przęseł, poziomów i lokalizacji na poziomie oraz ustalenie schematu kodu lokalizacji i domyślnych danych w lokalizacji.

![. Widok konfiguracji z włączonym suwakiem "Pusty rząd".](\img\OIP.png)

. Widok konfiguracji z włączonym suwakiem "Pusty rząd".

![. Widok konfiguracji z wyłączonym suwakiem "Pusty rząd".](\img\OIP.png)

 Widok konfiguracji z wyłączonym suwakiem "Pusty rząd".

- Kod GLN – jeśli w ustawieniach systemu włączona jest obsługa WMS zgodnie z standardami GS1 system umożliwia dodanie lokalizacji GLN. System nie posiada generatora kodów GLN.

![Pole tekstowe 126](\img\OIP.png)

![Obraz 87](\img\OIP.png)

##### Konfigurator schematu kodów lokalizacji

Konfigurator schematu kodów lokalizacji – określi sposób, w jaki system Asiston WMS będzie automatycznie oznaczał poszczególne lokalizacje w magazynie. Użytkownik będzie miał możliwość zdefiniowania co ma się składać na kod lokalizacji, w tym:

- Oznaczenie strefy – możliwość włączenia / wyłączenia
  - opcja: Litera – wpisanie litery
  - opcja: Separator – wpisanie dowolnego znaku oddzielającego składowe kodu lokalizacji
- Oznaczenie Rzędu – możliwość włączenia / wyłączenia
  - opcja: Litera – wpisanie litery
  - opcja: Liczba – wpisanie liczby od której ma się rozpocząć numerowanie Rzędu
  - opcja: Separator – wpisanie dowolnego znaku oddzielającego składowe kodu lokalizacji
- Oznaczenie Przęsła – możliwość włączenia / wyłączenia
  - opcja: Litera – wpisanie litery
  - opcja: Liczba – wpisanie liczby od której ma się rozpocząć numerowanie Przęsła
  - opcja: Separator – wpisanie dowolnego znaku oddzielającego składowe kodu lokalizacji
- Oznaczenie Poziomu – możliwość włączenia / wyłączenia
  - opcja: Litera – wpisanie litery
  - opcja: Liczba – wpisanie liczby od której ma się rozpocząć numerowanie Poziomu
  - opcja: Separator – wpisanie dowolnego znaku oddzielającego składowe kodu lokalizacji
- Oznaczenie Lokalizacji – możliwość włączenia / wyłączenia
  - opcja: Litera – wpisanie litery
  - opcja: Liczba – wpisanie liczby od której ma się rozpocząć numerowanie Lokalizacji
  - opcja: Separator – wpisanie dowolnego znaku oddzielającego składowe kodu lokalizacji

Konfigurator schematu kodu lokalizacji umożliwi również użycie separatora, pomiędzy poszczególnymi znacznikami kodu (składowymi lokalizacji). Separatorem może być np. myślnik. Kod lokalizacji z takim separatorem będzie wyglądał w następujący sposób: A-R1-P1-P1-L1. Ostatni aktywny znacznik schematu kodu lokalizacji będzie zablokowany, aby na końcu kodu lokalizacji nie wystąpił separator.

W ramach konfiguracji kodowania lokalizacji, można będzie również wybrać porządek numerowania lokalizacji w magazynie;

- Od lewej do prawej (proponowana domyślnie) – w kodach lokalizacji kolejne numery przęseł oraz lokalizacji (miejsc składowania), na danym poziomie, rosną od lewej do prawej,
- Od prawej do lewej – w kodach lokalizacji kolejne numery przęseł oraz lokalizacji (miejsc składowania), na danym poziomie, rosną od prawej do lewej.

System Asiston WMS pozwoli także łatwo (metodą „drag&drop”) zmienić kolejność poszczególnych elementów kodu lokalizacji (np. najpierw oznaczenie lokalizacji, później poziomu). Aby rząd został utworzony, konieczne będzie wprowadzenie schematu kodowania przynajmniej dla trzech z pięciu składowych lokalizacji.

![. Przykład skonfigurowania schematu kodów lokalizacji w nowo dodawanym rzędzie.](\img\OIP.png)

 Przykład skonfigurowania schematu kodów lokalizacji w nowo dodawanym rzędzie.

Zapisanie wyboru liczby przęseł, poziomów i lokalizacji (przy wyłączonym suwaku „Pusty rząd”) oraz schematu kodu lokalizacji, jak na ilustracjach wyżej, spowoduje, że system Asiston WMS, do danej strefy, doda rząd z następującymi składnikami lokalizacji:

- 2 przęsła,
- 4 poziomy,
- 3 lokalizacje na każdym poziomie i w każdym utworzonym przęśle.

System Asiston WMS automatycznie nada każdej lokalizacji kod, zgodnie ze skonfigurowanym powyżej schematem numerowania. Poniżej przedstawienie graficzne układu utworzonego rzędu, wraz z pozostałymi składowymi lokalizacji.

![. Utworzony rząd ze składowymi lokalizacji, w systemie Asiston WMS](\img\OIP.png)

 Utworzony rząd ze składowymi lokalizacji, w systemie Asiston WMS

##### Konfigurator domyślnych danych lokalizacji

W systemie Asiston WMS będzie możliwość określenia domyślnych danych, przypisanych do tworzonych lokalizacji.

Sekcja do konfigurowania danych lokalizacji będzie aktywowana suwakiem „Domyślne dane lokalizacji”, na etapie tworzenia i dodawania rzędu do strefy.

- Ustawienie suwaka w pozycji włączonej udostępni do edycji pola:
  - „Rodzaj lokalizacji”
  - „Szerokość”,
  - „Głębokość”,
  - „Wysokość”,
  - „Nośność”,
  - „Maksymalna waga jednego towaru”,
  - „Ilość palet na lokalizacji”.

Jednostki miary dla wagi i wymiarów lokalizacji oraz dokładność miejsc po przecinku, będą takie, jak określone wcześniej w widoku „Konfiguracja WMS/Ustawienia”, w menu systemu Asiston WMS (opis widoku w punkcie *5.7. Ustawienia*).

![. Przykładowa konfiguracja domyślnych danych lokalizacji.](\img\OIP.png)

 Przykładowa konfiguracja domyślnych danych lokalizacji.

- Ustawienie suwaka w pozycji wyłączonej spowoduje, że dane lokalizacji nie będą określane przy tworzeniu i dodawaniu rzędu. Później będzie je można wprowadzić oraz zmieniać, wchodząc do widoku szczegółów wybranej lokalizacji (więcej w punkcie 7.2.5.1.8* Szczegóły lokalizacji*).

#### Ręczne dodawanie i usuwanie lokalizacji

System Asiston WMS umożliwia ręczne dodawanie pojedynczych składowych lokalizacji, do zestawu który powstał przy tworzeniu rzędu.

Ręcznie można dodać:

- Przęsło - przyciskiem „Dodaj przęsło” – system doda puste przęsło z liczbą poziomów, jak w pozostałych przęsłach, w danym rzędzie;
- Poziom - przyciskiem „Dodaj poziom” - system doda kolejny, pusty poziom do wszystkich przęseł w danym rzędzie;
- Lokalizację (pojedyncze miejsce składowania) - do konkretnego poziomu w danym przęśle - przyciskiem „+” na wybranym poziomie. Użycie przycisku dodawania pojedynczej lokalizacji zwróci popup „Dodaj lokalizacje” z zestawem pól do wypełnienia. Pola te służą do określenia parametrów lokalizacji i są to:
  - „Wpisz kod lokalizacji”,
  - „Rodzaj lokalizacji”
  - „Szerokość”,
  - „Głębokość”,
  - „Wysokość”,
  - „Nośność”,
  - „Maksymalna waga jednego towaru”,
  - „Ilość palet na lokalizacji”.

Pole „Wpisz kod lokalizacji” należy wypełnić obowiązkowo, wypełnienie pozostałych pól nie jest obowiązkowe. Po kliknięciu przycisku „Zapisz” nowa lokalizacja pojawi się w widoku wybranego poziomu i przęsła.

W systemie Asiston WMS można również usuwać:

- Lokalizację,
- Poziom,
- Przęsło.

Do usunięcia służą ikonki kosza, umieszczone przy odpowiednich składowych lokalizacji. Usuwana składowa musi być pusta, tj. wcześniej należy z niej wydać lub przesunąć składowany towar.

Wszystkie przyciski oraz ikonki do dodawania i usuwania składowych lokalizacji.

![. Widok rzędu, wraz z przyciskami do dodawania i usuwania składowych lokalizacji.](\img\OIP.png)

 Widok rzędu, wraz z przyciskami do dodawania i usuwania składowych lokalizacji.

#### Edycja zbiorcza lokalizacji

System Asiston WMS umożliwia zbiorczą edycję lokalizacjami na danym rzędzie. Aby to zrobić, należy zaznaczyć cały rząd, przęsło lub konkretną lokalizację, a następnie wybrać przycisk „Edytuj zbiorczo”. Dzięki temu możliwe będzie ustawienie określonych danych na zaznaczonych lokalizacjach tj:

- Rodzaj lokalizacji
- Klasa rotacyjności
- Szerokość
- Wysokość
- Głębokość
- Nośność
- Maksymalna waga jednego towaru
- Ilość palet na lokalizacji

![. Zbiorcza edycja lokalizacji](\img\OIP.png)

 Zbiorcza edycja lokalizacji

#### Wydruk zbiorczy lokalizacji

System Asiston WMS umożliwia także zbiorczy wydruk etykiet lokalizacji. W tym celu należy zaznaczyć lokalizacje, dla których mają zostać wydrukowane etykiety, a następnie wybrać przycisk „Drukuj zbiorczo”. Jeśli została dodana drukarka i przypisana do danej etykiety, wówczas nastąpi wydruk ww etykiety.

#### Edycja numeru rzędu

W szczegółach strefy, przy każdym rzędzie możliwa jest zmiana numeru rzędu. Dzięki odpowiedniej numeracji będzie możliwe skuteczne filtrowanie listy dokumentów do zbierania wg numeru rzędów oraz ustawienie najkrótszej ścieżki.

![. Edycja numeru rzędu](\img\OIP.png)

 Edycja numeru rzędu

#### Szczegóły lokalizacji

Dostęp do szczegółów lokalizacji uzyskamy po kliknięciu kodu danej lokalizacji. Kliknięcie kodu otworzy okno, w którym widoczne będą pola do określenia cech (parametrów) danej lokalizacji a także sekcje „Dozwolone produkty” oraz „Zablokowani użytkownicy”.

Zestaw cech (parametrów) lokalizacji będzie się rozpoczynał od paska postępu, pokazującego stopień aktualnego zapełnienia lokalizacji (w %). Sposób wyliczania zapełnienia będzie taki, jak określony wcześniej w widoku „Konfiguracja WMS/Ustawienia”, tj. wg kryterium objętości lub masy (opis widoku w punkcie 7.2.1.2*. Ustawienia*).

Kolejne pola obowiązkowe będą zawierać:

- „Kod” (danej lokalizacji) - pobrany automatycznie lub wprowadzony ręcznie, z możliwością zmiany w widoku szczegółów lokalizacji,
- „Rodzaj lokalizacji”, wybierany z rozwijanej listy rodzajów lokalizacji, które wcześniej zostały określone w pozycji Konfiguracja/Lokalizacje/Rodzaje lokalizacji,
- „Klasę rotacyjności” – klasa do wyboru z listy rozwijanej:
  - Brak wyboru
  - X – najbardziej rotacyjna
  - Y – średnio rotacyjna
  - Z – najmniej rotacyjna
- „Kategorię ryzyka” – kategoria do wyboru z listy rozwijanej:
  - Neutralna – możliwość składowania na danej lokalizacji każdy towar,
  - Niebezpieczne – możliwość składowania na danej lokalizacji towarów z oznaczeniem „Towar niebezpieczny”, który ustawia się w jego szczegółach,
  - Bezpieczne – możliwość składowania na danej lokalizacji towarów bez oznaczenia „Towar niebezpieczny”, który ustawia się w jego szczegółach.

Pozostałe pola powinny być wypełnione ręcznie i zawierać odpowiednio:

- „Szerokość”,
- „Wysokość”,
- „Głębokość”,
- „Nośność”,
- „Maksymalną wagę jednego towaru”,
- „Ilość palet na lokalizacji”:
  - Jeżeli pole jest puste to nie ma limitów liczby nośników, umieszczanych na lokalizacji,
  - Wartość „0” oznacza brak możliwości umieszczania jakichkolwiek nośników w tej lokalizacji,
  - Jeśli wartość jest większa od „0”, wtedy można przyjąć na tę lokalizację tyle nośników, na ile wskazuje liczba.

Jednostki miary dla wagi i wymiarów lokalizacji oraz dokładność miejsc po przecinku, będą takie, jak określone wcześniej w widoku „Konfiguracja/Ustawienia”, w menu systemu Asiston WMS.

Lokalizację można również ustawić (używając checkboxa), jako:

- „Zablokowana” – wówczas nie będzie można na nią przyjmować, ani wydawać z niej towarów,
- „Aktywna” – w pełni dostępną dla operacji magazynowych (opcja domyślna w systemie Asiston WMS).

![. Widok pól szczegółów lokalizacji, z przykładowym ich wypełnieniem.](\img\OIP.png)

 Widok pól szczegółów lokalizacji, z przykładowym ich wypełnieniem.

W sekcji „Dozwolone produkty” można wskazać jakie produkty mają być umieszczane na danej lokalizacji. Podstawowy widok sekcji zwraca listę produktów, na której każda pozycja zawiera kolumny:

- „Nazwa” – w formie hiperłącza - po kliknięciu przenosi użytkownika do widoku szczegółów produktu,
- „Symbol”,
- Akcje:
  - „Usuń”*.*

Z listy produktów można wyszukać konkretny, używając przycisku Wyszukaj i wpisując nazwę, symbol lub ich fragment w polu wyszukiwania na popupie.

Dodawanie produktu do listy dozwolonych produktów na lokalizacji, odbywa się przyciskiem Dodaj produkt. Po jego kliknięciu, system wyświetli popup z listą rozwijaną nazw produktów do wyboru. Zakres wyszukiwania można będzie zawęzić wpisując nazwę produktu lub jej frazę.

Pusta lista dozwolonych produktów oznacza, że na danej lokalizacji można umieszczać wszystkie produkty, przyjęte do magazynu.

![. Widok sekcji "Dozwolone produkty" w szczegółach lokalizacji.](\img\OIP.png)

Widok sekcji "Dozwolone produkty" w szczegółach lokalizacji.

Sekcja „Zablokowani użytkownicy” służy do wskazania, którzy użytkownicy systemu Asiston WMS nie będą mieli dostępu do danej lokalizacji. Brak dostępu dla użytkownika oznacza, że nie będzie mógł korzystać z lokalizacji, w zakresie swoich uprawnień.

Podstawowy widok sekcji zwraca listę użytkowników, każda pozycja na liście zawiera kolumny:

- „Nazwa”* *– w formie hiperłącza - po kliknięciu przenosi do widoku edycji użytkownika,
- Akcje:
  - „Usuń”.

![. Widok sekcji "Zablokowani użytkownicy" w szczegółach lokalizacji.](\img\OIP.png)

Widok sekcji "Zablokowani użytkownicy" w szczegółach lokalizacji.

Z listy zablokowanych użytkowników można wyszukać konkretnego, używając przycisku „Wyszukaj” i wpisując jego nazwę, w polu wyszukiwania na popupie.

Dodawanie użytkownika do listy zablokowanych, odbywa się przyciskiem „Dodaj użytkownika”. Po jego kliknięciu, system wyświetli popup z listą rozwijaną nazw użytkowników do wyboru. Zakres wyszukiwania można będzie zawęzić wpisując nazwę użytkownika lub jej frazę.

Pusta lista zablokowanych użytkowników oznacza, że do danej lokalizacji mają dostęp wszyscy użytkownicy, o stosownych uprawnieniach, nadanych w pozycji „Administracja/Użytkownicy”.

Sekcja „Produkty na lokalizacji” służy do wskazania, jakie produkty znajdują się na danej lokalizacji. Podstawowy widok sekcji zwraca listę produktów, na której każda pozycja zawiera kolumny:

- „Symbol produktu” – w formie hiperłącza – po kliknięciu przenosi użytkownika do widoku szczegółów produktu,
- „Nazwa produktu” – w formie hiperłącza - po kliknięciu przenosi użytkownika do widoku szczegółów produktu,
- „Ilość” – ilość danego produktu na lokalizacji
- „JM” – podstawowa jednostka miary danego produktu

Z listy produktów można wyszukać konkretny, używając przycisku Wyszukaj i wpisując nazwę, symbol lub ich fragment w polu wyszukiwania na popupie.

![ Produkty na lokalizacji](\img\OIP.png)

 Produkty na lokalizacji

### Budynki

Konfiguracja budynków służy wprowadzeniu nazw oraz określeniu cech budynków magazynowych, a także budynków, w których są wydzielone powierzchnie magazynowe, wykorzystywane na potrzeby przedsiębiorstwa.

Podstawowym widokiem konfiguracji budynków będzie lista dodanych budynków, zawierająca kolumny:

- „Nazwa”,
- Akcje:
  - „Edytuj”,
  - „Usuń”.

Możliwe będzie filtrowanie listy wg nazwy. Po wpisaniu części frazy, system zwróci wyniki, w których ta fraza występuje.

![ Widok listy budynków w systemie Asiston WMS.](\img\OIP.png)

 Widok listy budynków w systemie Asiston WMS.

Formularz dodawania budynku uruchamiany będzie przyciskiem „Dodaj budynek”, w widoku listy budynków. Nazwę dodawanego budynku należy wprowadzić w polu „Nazwa budynku” oraz zapisać.

![ Widok formularza dodawania budynku w systemie Asiston WMS.](\img\OIP.png)

 Widok formularza dodawania budynku w systemie Asiston WMS.

Zapisaną już nazwę można edytować i zmieniać w widoku szczegółów budynku.

### Typy stref

Typ strefy to określenie (zazwyczaj jednym słowem) jej funkcjonalnego przeznaczenia. Typy stref, utworzone w tym miejscu systemu Asiston WMS, są potem pobierane i udostępniane do wyboru, przy dodawaniu nowej strefy w magazynie „Dodawanie strefy”

Podstawowym widokiem typów stref jest lista utworzonych już typów. Pełny widok listy zawiera trzy następujące kolumny:

- „Nazwa”,
- „Opis”,
- Akcje:
  - „Edytuj”,
  - „Usuń”.

Lista może być filtrowana po nazwie, przy użyciu przycisku „Nazwa”. Przycisk zwróci popup z polem wyszukiwania, w którym należy wpisać nazwę lub fragment nazwy szukanego typu strefy.

![Widok listy typów stref w systemie Asiston WMS.](\img\OIP.png)

 Widok listy typów stref w systemie Asiston WMS.

Nowy typ strefy można będzie utworzyć i dodać do listy przyciskiem „Dodaj typ”. Użycie przycisku zwróci widok szczegółów strefy, z dwoma, obowiązkowymi polami do wypełnienia:

- „Nazwa typu”,
- „Opis”.

Do widoku szczegółów typów strefy, można wejść – z listy typów stref - na dwa sposoby:

- Klikając daną strefę na liście,
- Klikając przycisk akcji i wybierając „Edytuj”.

Zawartość pól, w widoku szczegółów jest edytowalna, ewentualne, wprowadzone zmiany należy zapisać przyciskiem „Zapisz” lub „Zapisz i wróć”.

![ Widok szczegółów wybranego typu strefy.](\img\OIP.png)

 Widok szczegółów wybranego typu strefy.

#### Rodzaje lokalizacji

Rodzaj lokalizacji określa jej główną funkcję, np. „Nadstanowa”, „Standardowa”, „Zapasowa”, itp. Rodzaje lokalizacji, utworzone w tym miejscu, są potem pobierane i udostępniane do wyboru, w szczegółach lokalizacji (więcej w punkcie* **Szczegóły lokalizacji*).

Podstawowym widokiem jest lista utworzonych rodzajów lokalizacji. Pełny widok listy zawiera dwie następujące kolumny:

- „Nazwa”,
- „Priorytet” – ustawienie na podstawie którego system będzie w ustawionym priorytecie pobranie towaru z lokalizacji. Nr 1 oznacza najwyższy priorytet,
- „Wyliczenia XYZ” – na podstawie tego ustawienia system będzie sugerował odłożenie towaru do lokalizacji, dla którego wyliczony odpowiedni poziom klasy rotacyjności,
- „Autouzupełnianie” – na podstawie tego ustawienia system będzie sprawdzał stany minimalne i maksymalne, dzięki którym będzie możliwe automatyczne generowanie zleceń przesunięć do uzupełnienia towarów do stanów maksymalnych,
- „Lokalizacja usuwająca stan” – system z lokalizacjami z tym ustawieniem będzie cyklicznie sprawdzał i usuwał stan towarów,
- Akcje:
  - „Edytuj”
  - „Usuń”.

Lista może być filtrowana po nazwie, przy użyciu przycisku „Nazwa”. Przycisk zwróci popup z polem wyszukiwania, w którym należy wpisać nazwę lub fragment nazwy szukanego rodzaju lokalizacji.

![ Widok listy rodzajów lokalizacji, w systemie Asiston WMS.](\img\OIP.png)

 Widok listy rodzajów lokalizacji, w systemie Asiston WMS.

### Konfiguracja ścieżki

Konfiguracja ścieżki jest to określenie kolejności stref oraz lokalizacji, którą magazynier powinien przejść, w procesie zbierania (wydania), tak, aby przebyć najkrótszą drogę od rozpoczęcia do zakończenia wydania. Podstawowym widokiem konfiguracji ścieżki jest lista stref, zawierająca:

- Nazwy stref, istniejących w magazynie,
- Suwak „Wykluczona”, którego włączenie usunie daną strefę z udziału w procesie wydania,
- Pole do wpisania kolejnego numeru strefy na ścieżce,
- Przycisk przejścia do konfiguracji kolejności rzędów w danej strefie.
1. Konfiguracja kolejność stref

Kolejność stref na ścieżce można ustalić dwoma sposobami (do wyboru):

1. Wpisując kolejny numer w polu każdej strefy na liście,
1. Przeciągając strefę na właściwe miejsce w kolejności, przy użyciu funkcji „drag&drop”. Przeciągnięcie automatycznie zaktualizuje kolejny numer strefy na ścieżce.

![ Widok konfiguracji kolejności stref, z wpisanymi ręcznie, kolejnymi numerami stref na ścieżce.](\img\OIP.png)

 Widok konfiguracji kolejności stref, z wpisanymi ręcznie, kolejnymi numerami stref na ścieżce.

1. Kolejność rzędów

Po przejściu do szczegółów strefy (przycisk „Rzędy”) zostaną wyświetlone wszystkie rzędy, utworzone w danej strefie. Ustalenie kolejności rzędów możliwe będzie tak samo, jak określenie kolejności stref (poprzez wpisanie kolejnego numeru lub użycie „drag&drop”).

![ Widok konfiguracji kolejności rzędów, z wpisanymi ręcznie, kolejnymi numerami rzędów    na ścieżce](\img\OIP.png)

 Widok konfiguracji kolejności rzędów, z wpisanymi ręcznie, kolejnymi numerami rzędów   
na ścieżce

1. Kolejność przęseł i lokalizacji

Po przejściu do szczegółów rzędu (przycisk „Lokalizacje”) zostaną wyświetlone wszystkie przęsła, a w nich lokalizacje. Ustalenie kolejności rzędów odbywa się tak samo, jak w poprzednich poziomach.

![ Widok konfiguracji kolejności przęseł i lokalizacji, z wpisanymi ręcznie, kolejnymi numerami.](\img\OIP.png)

 Widok konfiguracji kolejności przęseł i lokalizacji, z wpisanymi ręcznie, kolejnymi numerami.

## Priorytety

Priorytety na dokumentach służą do określenia stopnia ważności lub pilności danego dokumentu w procesie jego obsługi, przetwarzania lub realizacji. Umożliwiają one zarządzanie zadaniami i zasobami w sposób bardziej efektywny. Po przejściu do konfiguracji priorytetów, system Asiston WMS zwróci listę modułów, dla których możliwe jest ustawienie priorytetów. Pełny zestaw kolumn będzie obejmował:

- *Nazwę modułu*,

Lista priorytetów będzie mogła być filtrowana według kryteriów:

- *Nazwa modułu*

![ Widok listy priorytetów, w systemie Asiston WMS.](\img\OIP.png)

 Widok listy priorytetów, w systemie Asiston WMS.

Z poziomu listy będzie można przejść do konfiguracji priorytetów danego modułu, używając przycisku *Szczegóły.* Po przejściu do danego widoku, system zwróci widok z następującymi, sekcjami

- *Priorytety – możliwość ustawienia ilości gwiazdek dla każdego priorytetu dokumentu*,
- *Sortowanie – domyślne sortowanie listy*

![ Widok szczegółów priorytetu modułu, w systemie Asiston WMS.](\img\OIP.png)

 Widok szczegółów priorytetu modułu, w systemie Asiston WMS.

W sekcji priorytetów będzie możliwe określenie liczby gwiazdek, jakie mają się ustawiać na dokumencie. Każdy dokument zawiera domyślny priorytet, który będzie się ustawiał automatycznie przy utworzeniu dokumentu.

Dodatkowo dla każdego priorytetu istnieje możliwość oznaczenia „Wymuszaj realizację z tym priorytetem”. Oznacza to, że system Asiston WMS taki dokument (oznaczony w akceptacji) będzie wymuszał na użytkowniku aby w pierwszej kolejności go zrealizował.

### Kody zbiorcze

Kody zbiorcze służą do oznakowania towarów w opakowaniu zbiorczym, jako odrębnej jednostki logistycznej w magazynie. Po przejściu do konfiguracji kodów zbiorczych, system Asiston WMS zwróci listę utworzonych kodów zbiorczych. Pełny zestaw kolumn będzie obejmował:

- *Kod kreskowy* – unikalny numer zakodowany w kodzie zbiorczym,
- *Ilość* – ilość towaru w jednostce logistycznej, dla której kod został ustanowiony,
- *Symbol*,
- *Nazwa* -  nazwa towaru, znajdującego się wewnątrz,
- *Akcje**:*
  - *Edytu**j*
  - *Usuń*

Lista kodów zbiorczych będzie mogła być filtrowana według kryteriów:

- *Symbol,*
- *Nazw**a**,*
- *Kod kreskow**y**.*

![ Widok listy kodów zbiorczych, w systemie Asiston WMS.](\img\OIP.png)

 Widok listy kodów zbiorczych, w systemie Asiston WMS.

Z poziomu listy będzie można dodać nowy kod, używając przycisku *Dodaj kod* Po przejściu do dodawania nowego kodu, system zwróci widok z następującymi, obowiązkowymi polami:

- *Towar* - wybór z listy rozwijanej,
- *Kod* – ręcznie wpisywany kod tworzonej jednostki logistycznej,
- *Ilość* - ilość towarów w opakowaniu zbiorczym, dla którego ustanawiany jest kod zbiorczy.

![ Widok formularza dodawania kodów zbiorczych, w systemie Asiston WMS.](\img\OIP.png)

 Widok formularza dodawania kodów zbiorczych, w systemie Asiston WMS.

Z widoku listy kodów zbiorczych można będzie wejść do szczegółów wybranego kodu i tego, jaka jednostka logistyczne jest nim oznaczona. Struktura widoku szczegółów będzie taka sama, jak w formularzu dodawania kodu. Wszystkie pola, widoczne, w szczegółach kodu zbiorczego, są edytowalne, można zmieniać ich zawartość. Wprowadzone zmiany należy zapisać przyciskiem *Zapisz* lub *Zapisz i wróć*. Przycisk *Drukuj* pozwala na wydrukowanie etykiety ze zbiorczym kodem kreskowym.

![ Przykładowy widok szczegółów kodu zbiorczego, w systemie Asiston WMS.](\img\OIP.png)

 Przykładowy widok szczegółów kodu zbiorczego, w systemie Asiston WMS.

Wszędzie tam, gdzie występuje skanowanie towarów (przyjęcie, wydanie, przesunięcie, inwentaryzacja, zwrot), po zeskanowaniu zbiorczego kodu towaru, pole ilość będzie się automatycznie uzupełniać w ilości skonfigurowanej dla danego opakowania zbiorczego - jednostki logistycznej, bez możliwości zmiany raz wprowadzonej ilości.

- Przykład: Produkt 1 o kodzie 123456789 ma skonfigurowany kod zbiorczy 555 z ilością 15 szt. towarów jednostkowych, w środku. Po zeskanowaniu kodu zbiorczego, np. w przyjęciu, ilość będzie ma automatycznie ustawiać się jako 15. Ilość ta ustawiona będzie na stałe, bez możliwości zmiany.

## Kurierzy

System Asiston WMS można zintegrować z systemem Asiston Kurierzy, który wspiera obsługę procesu nadawania, kontroli oraz dostawy paczek do klienta. Jeśli oba te systemy są wdrożone i zintegrowane w przedsiębiorstwie, to pozycja „Konfiguracja WMS/Kurierzy”, w menu systemu Asiston WMS, wyświetli listę kurierów, aktywnych w systemie Asiston Kurierzy, którym można składać zlecenia przewozowe do obsługi wydań dwuetapowych (Jednoetapowe + Kurier) oraz wydań trzyetapowych (szczegóły procesów opisane w punkcie „14.2. Wydania”).

Jeżeli system Asiston WMS nie będzie zintegrowany z systemem Asiston Kurierzy, to lista kurierów będzie pusta.

Widok listy kurierów zintegrowanej z systemem Asiston Kurierzy, będzie zawierał następujące informacje:

- Nazwę,
- Przycisk akcji: „Szczegóły”.

Kurierzy, zintegrowani z systemem Asiston WMS, będą wyświetlani na liście.

Możliwe będzie filtrowanie listy wg nazwy kuriera, przy użyciu przycisku „Nazwa”. Kliknięcie przycisku zwróci popup z polem do wpisania szukanej nazwy lub jej części. Po jej wpisaniu system zwróci listę kurierów, w których ta nazwa występuje.

![ Widok listy kurierów w konfiguracji systemu Asiston WMS.](\img\OIP.png)

 Widok listy kurierów w konfiguracji systemu Asiston WMS.

Lista kurierów będzie aktualizowana:

1. Automatycznie – w ustalonych odstępach czasu, określonych w ramach integracji z systemem Asiston Kurierzy,
1. Ręcznie – użytkownik będzie mógł ręcznie wymusić natychmiastowe odświeżenie przyciskiem aktualizacji, w widoku listy kurierów.

Z widoku listy będzie można wejść w szczegóły wybranego kuriera, aby:

- Dostępny w pakowaniu - przy pomocy checkboxa, włączyć lub wyłączyć opcję,
  - checkbox zaznaczony – wybranemu kurierowi będzie można przekazać spakowany towar oraz utworzyć dla niego list przewozowy w procesie pakowania. Ponadto na liście kurierów zostanie podświetlony kolorem zielonym,
  - checkbox odznaczony – wybranemu kurierowi nie będzie można nadać spakowanego towaru. Ponadto na liście kurierów zostanie podświetlony kolorem czerwonym.
- Domyślna lokalizacja – możliwość określenia - z listy rozwijanej – domyślną lokalizację, przypisaną do danego kuriera w magazynie – na tę lokalizację będą przesuwane spakowane towary do wydania kurierowi.
- Ustaw lokalizacje po przypisaniu pierwszej paczki – przy pomocy checkboxa włączyć lub wyłączyć opcję,
  - Checkbox zaznaczony – lokalizacja zostanie przypisana do kuriera po przypisaniu pierwszej paczki. Lokalizacja zostanie wyzerowana po wydaniu wszystkich paczek do kuriera
  - Checkbox odznaczony – system Asiston WMS nie wymusza i nie przypisuje lokalizacji dla paczek do kuriera
- Generuj własną etykietę - przy pomocy checkboxa włączyć lub wyłączyć opcję,
  - Checkbox zaznaczony – system Asiston WMS generuje własną etykietę przewozową zgodnie ze skonfigurowanym szablonem etykiet
  - Checkbox odznaczony – system Asiston WMS generuje etykietę bezpośrednio od kuriera

Dodatkowo istnieje możliwość skonfigurowania maksymalnych wymiarów paczek dla każdego rodzaju, jaki ofertuje dany kurier. Przekroczenie tych wymiarów powoduje wygenerowanie paczki niestandardowej.

![ Przykładowy widok szczegółów kuriera z listy z "Konfiguracja WMS/Kurierzy".](\img\OIP.png)

 Przykładowy widok szczegółów kuriera z listy z "Konfiguracja WMS/Kurierzy".
