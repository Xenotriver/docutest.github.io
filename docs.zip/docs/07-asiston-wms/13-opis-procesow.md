---
title: "Opis procesów"
sidebar_label: "7.13. Opis procesów"
---











## Reklamacje

### Reklamacje bez akceptacji

![Diagram 41. Reklamacja bez akceptacji.](\img\OIP.png)

Diagram 41. Reklamacja bez akceptacji.

Proces będzie się rozpoczynał od przyjęcia zgłoszenia reklamacji.  Pracownik posiadający uprawnienia do widoku akceptacji utworzy dokument wypełniając pola z danymi podstawowymi, tj. :

- Nazwa kontrahenta
- Żądanie reklamującego (Wymian towaru na nowy/ Napraw/ Zwrot pieniędzy)
- Data powstania wady
- Data zgłoszenia
- Sposób odesłania zgłaszanego towaru
- Opis usterki
- Załącznik
- Rodzaj dokument (faktura/ paragon)
- Numer dokumentu sprzedaży
- Ilość reklamowanego towaru dla pozycji z zamówienia

Po zakończeniu wypełniania formularza pracownik zapisze wprowadzone dane. Dokument reklamacji zostanie utworzony w systemie WMS i będzie dodany do listy reklamacji w widoku akceptacji ze statusem  „Zarejestrowano”. Pracownik posiadający uprawnienia do widoku akceptacji otworzy dokument z listy i podejmie decyzje o akceptacji bądź odrzuceniu reklamacji. Na tym etapie możliwa będzie również edycja reklamacji. Odrzucenie spowoduje zakończenie procesu i zmianę statusu dokumentu na „Odrzucono”.  Akceptacja spowoduje przekazanie dokumentu na listę przyjęcia reklamacji w widoku magazynowym.

Rozpoczynając przyjęcie, magazynier otworzy wybrany dokument z listy i zablokuje go do obsługi przez siebie. System WMS automatycznie nada dokumentowi na liście status „W przygotowaniu”.

Magazynier zeskanuje kod przyjmowanego towaru, uzupełni aktywne pola dokumentu i kliknie przycisk „Zakończ”. System WMS automatycznie zatwierdzi przyjęcie i nada dokumentowi na liście przyjęć reklamacji w widoku magazynowym status "Zakończono". Ten sam dokument na liście akceptacji otrzyma status „Do weryfikacji”.

Pracownik posiadający uprawnienia do widoku akceptacji otworzy dokument z listy i podejmie decyzje o zatwierdzeniu bądź odrzuceniu reklamacji na podstawie oceny zwróconego towaru. Na tym etapie u użytkownik może zmodyfikować pozycję „żądanie reklamującego”.  Odrzucenie wymusi na użytkowniku wprowadzenie powodu odrzucenia oraz spowoduje  zakończenie procesu i zmianę statusu dokumentu na „Odrzucono”.  Zatwierdzenie w zależności od żądania reklamującego spowoduje:

- Dla „Wymiany towaru na nowy”: zmianę statusu reklamacji w widoku akceptacji na „Zaakceptowano”.
- Dla „Naprawa”: zmianę statusu reklamacji w widoku akceptacji na „Oczekuje na naprawę ”.
- Dla „Zwrot pieniędzy”: zmianę statusu reklamacji w widoku akceptacji na „Zakończono”.

W przypadku żądania zwrotu pieniędzy zatwierdzenie dokumentu jest jednoznaczne z zakończeniem procesu. Dla pozostałych dwóch żądań Pracownik posiadający uprawnienia do widoku akceptacji może odrzucić reklamacje (system wymusi podanie powodu odrzucenia) lub przekazać dokument do wydania. Powoduje to zmianę statusu dokumentu na „Oczekuje na wydanie” zarówno w widoku akceptacji jak i w widoku magazynowym.

Rozpoczynając wydanie, magazynier otworzy wybrany dokument z listy i zablokuje go do obsługi przez siebie. System WMS automatycznie nada dokumentowi na liście status „W przygotowaniu”.

Magazynier zeskanuje kod wydawanego towaru, uzupełni aktywne pola dokumentu i kliknie przycisk „Zakończ”. System WMS automatycznie zatwierdzi wydanie  i nada dokumentowi "Zakończono" zarówno w widoku akceptacji jak i w widoku magazynowym.

### Reklamacje z końcową akceptacją

![Diagram 42 Reklamacja z końcową akceptacją.](\img\OIP.png)

Diagram 42 Reklamacja z końcową akceptacją.

Proces będzie się rozpoczynał od przyjęcia zgłoszenia reklamacji.  Pracownik posiadający uprawnienia do widoku akceptacji utworzy dokument wypełniając pola z danymi podstawowymi, tj. :

- Nazwa kontrahenta
- Żądanie reklamującego (Wymian towaru na nowy/ Napraw/ Zwrot pieniędzy)
- Data powstania wady
- Data zgłoszenia
- Sposób odesłania zgłaszanego towaru
- Opis usterki
- Załącznik
- Rodzaj dokument (faktura/ paragon)
- Numer dokumentu sprzedaży
- Ilość reklamowanego towaru dla pozycji z zamówienia

Po zakończeniu wypełniania formularza pracownik zapisze wprowadzone dane. Dokument reklamacji zostanie utworzony w systemie WMS i będzie dodany do listy reklamacji w widoku akceptacji ze statusem  „Zarejestrowano”. Pracownik posiadający uprawnienia do widoku akceptacji otworzy dokument z listy i podejmie decyzje o akceptacji bądź odrzuceniu reklamacji. Na tym etapie możliwa będzie również edycja reklamacji. Odrzucenie spowoduje zakończenie procesu i zmianę statusu dokumentu na „Odrzucono”.  Akceptacja spowoduje przekazanie dokumentu na listę przyjęcia reklamacji w widoku magazynowym.

Rozpoczynając przyjęcie, magazynier otworzy wybrany dokument z listy i zablokuje go do obsługi przez siebie. System WMS automatycznie nada dokumentowi na liście status „W przygotowaniu”.

Magazynier zeskanuje kod przyjmowanego towaru, uzupełni aktywne pola dokumentu i kliknie przycisk „Zakończ”. System WMS automatycznie zatwierdzi przyjęcie i nada dokumentowi na liście przyjęć reklamacji w widoku magazynowym status "Zakończono". Ten sam dokument na liście akceptacji otrzyma status „Do weryfikacji”.

Pracownik posiadający uprawnienia do widoku akceptacji otworzy dokument z listy i podejmie decyzje o zatwierdzeniu bądź odrzuceniu reklamacji na podstawie oceny zwróconego towaru. Na tym etapie u użytkownik może zmodyfikować pozycję „żądanie reklamującego”.  Odrzucenie wymusi na użytkowniku wprowadzenie powodu odrzucenia oraz spowoduje  zakończenie procesu i zmianę statusu dokumentu na „Odrzucono”.  Zatwierdzenie w zależności od żądania reklamującego spowoduje:

- Dla „Wymiany towaru na nowy”: zmianę statusu reklamacji w widoku akceptacji na „Zaakceptowano”.
- Dla „Naprawa”: zmianę statusu reklamacji w widoku akceptacji na „Oczekuje na naprawę ”.
- Dla „Zwrot pieniędzy”: zmianę statusu reklamacji w widoku akceptacji na „Zakończono”.

W przypadku żądania zwrotu pieniędzy zatwierdzenie dokumentu jest jednoznaczne z zakończeniem procesu. Dla pozostałych dwóch żądań Pracownik posiadający uprawnienia do widoku akceptacji może odrzucić reklamacje (system wymusi podanie powodu odrzucenia) lub przekazać dokument do wydania. Powoduje to zmianę statusu dokumentu na „Oczekuje na wydanie” zarówno w widoku akceptacji jak i w widoku magazynowym.

Rozpoczynając wydanie, magazynier otworzy wybrany dokument z listy i zablokuje go do obsługi przez siebie. System WMS automatycznie nada dokumentowi na liście status „W przygotowaniu”.

Magazynier zeskanuje kod wydawanego towaru, uzupełni aktywne pola dokumentu i kliknie przycisk „Zakończ”. System WMS automatycznie zatwierdzi wydanie  i nada dokumentowi w widoku magazynowym status "Zakończono". Dokument w widoku akceptacji otrzyma status „Do akceptacji”. Pracownik posiadający uprawnienia do widoku akceptacji będzie mógł zwrócić dokument do magazynu lub zaakceptować dokument co będzie jednoznaczne z zakończeniem procesu i zmiana statusu dokumentu na „Zakończony”.




