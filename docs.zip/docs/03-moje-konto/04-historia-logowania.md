---
title: "Historia logowania"
sidebar_label: "3.4. Historia logowania"
---

Widok historii logowania będzie pokazywał aktywne sesje – od czasu zalogowania użytkownika w systemie Asiston WMS oraz listę urządzeń, z których  użytkownik logował się do systemu.

![ Przykładowe okno "Moje konto/Bezpieczeństwo", w systemie Asiston WMS.](\img\Obrazy\Historia_logowania.png)

 Przykładowe okno "Moje konto/Bezpieczeństwo", w systemie Asiston WMS.

Funkcjonalność ta będzie użytkownikowi ułatwiać sprawdzenie czy wszystkie logowania na jego konto były autoryzowane.
