---
title: "Wydania"
sidebar_label: "7.8. Wydania"
---

Moduł wydań służy do obsługi wydań towaru z magazynu, od pobrania dokumentu awizującego wydanie, do zakończenia wydania. Zakładka „Wydania”, w menu systemu Asiston WMS, wyświetla listę rozwijaną, której zawartość zależy od konfiguracji rodzajów wydań określonych w konfiguracji procesów opisanych w punktach  Konfiguracja procesu wydań awizowanych, Konfiguracja procesu odbioru osobistego  oraz Konfiguracja procesu wydania bezpośredniego.

## Wydania awizowane

W konfiguracji, do wyboru jest jeden z następujących rodzajów wydań:

- Jednoetapowe,
- Dwuetapowe (Zbieranie + Kurier),
- Dwuetapowe (Zbieranie + Pakowanie),
- Trzyetapowe (Zbieranie + Pakowanie + Kurier)

### Wydania jednoetapowe

Na liście rozwijanej pozycji „Wydania”, w menu systemu Asiston WMS, będzie widoczny jeden element „Wydania”, do obsługi całego procesu. Lista awizowanych wydań będzie zawierać następujące kolumny:

- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent
- Status:
  - Oczekuje na wydanie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony,
  - Do anulowania
  - Anulowano.
- Data utworzenia,
- Data zakończenia,
- Waga całkowita pozycji,
- Ilość towarów w dokumencie,
- Objętość całkowita,
- Osoba blokująca,
- List przewozowy (Tak/Nie)
- Kurier
- Postęp realizacji,
- Termin realizacji,
- Osoba wystawiająca bazowy dokument,
- Priorytet
- Akcje:
  - Szczegóły

Filtrowanie listy możliwe będzie według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Kontrahent – pole tekstowe,
- Status – lista rozwijana:
  - Oczekuje na wydanie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony,
  - Do anulowania
  - Anulowano.
- Data utworzenia (od – do),
- Daty zakończenia (od – do),
- Liczba pozycji dokumentu,
- Osoba blokująca,
- Waga całkowita,
- Kurier,
- Objętość całkowita,
- Osoba wystawiająca,
- Kod regału,
- Priorytet,
- Zawiera listy przewozowe
- Numer listu przewozowego
- Numer opakowania,

Lista będzie odświeżana i aktualizowana w integracji z systemem ERP – nowe awizacje będą automatycznie pobierane do systemu WMS i dodawane do listy, po dodaniu nowego dokumentu ZK w systemie ERP.

![8. Widok listy wydań jednoetapowych.](\img\OIP.png)

8. Widok listy wydań jednoetapowych.

Widok szczegółów wydania jednoetapowego będzie się zmieniał wraz ze zmiana statusu dokumentu.

1. Dokument ze statusem „Oczekuje na wydanie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie,
      - Lokalizacja,
      - Nośnik,
      - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
      - JM,
      - Partia.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Rozpocznij pakowanie”.

![9. Widok szczegółów dokumentu wydania jednoetapowego,    ze statusem "Oczekuje na wydanie".](\img\OIP.png)

9. Widok szczegółów dokumentu wydania jednoetapowego,   
ze statusem "Oczekuje na wydanie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Opakowanie”, zawierającą:
  - Pole do zeskanowania kodu opakowania zbiorczego, jeśli w konfiguracji procesu zaznaczono wcześniej „Opakowanie zbiorcze w pakowaniu”
  - Przycisk „Zatwierdź”,
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika,
    - Kodu towaru,
    - Ilości,
    - Partii
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik,
    - Ukryj ilość,
    - Ukryj partię,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie,
      - Lokalizacja,
      - Nośnik,
      - Ilość,
      - JM.
- Sekcję „Generowanie listu przewozowego”, jeśli w konfiguracji procesu wybrano wcześniej opcję „Generowanie listów przewozowych/W trakcie pakowania” (więcej w punkcie Opcje). Sekcja zawiera:
  - Zestawienie wygenerowanych listów przewozowych, z kolumnami:
    - Kurier (nazwa kuriera),
    - Rodzaj przesyłki,
    - Ilość,
    - Waga,
    - Długość,
    - Szerokość,
    - Wysokość,
    - Numer listu przewozowego,
    - Opakowanie
  - Pola do wypełnienia przy generowaniu nowego listu przewozowego. Pola te będą udostępniane po użyciu przycisku „Dodaj pozycję” i będą to:
    - Kurier (nazwa kuriera),
    - Rodzaj przesyłki,
    - Ilość,
    - Waga,
    - Długość,
    - Szerokość,
    - Wysokość,
    - Ikonka usuwania
  - Przyciski: „Dodaj pozycję” oraz „Generuj list przewozowy”.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Kontrahent,
  - Aktualny status dokumentu,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Przerwij”,
  - „Zakończ wydanie”.

![0. Widok szczegółów dokumentu wydania jednoetapowego, o statusie "W przygotowaniu", sekcje "Opakowanie" i "Zeskanuj pozycje".](\img\OIP.png)

0. Widok szczegółów dokumentu wydania jednoetapowego, o statusie "W przygotowaniu", sekcje "Opakowanie" i "Zeskanuj pozycje".

![1. Widok szczegółów dokumentu wydania jednoetapowego, o statusie "W przygotowaniu", sekcja "Towary".](\img\OIP.png)

1. Widok szczegółów dokumentu wydania jednoetapowego, o statusie "W przygotowaniu", sekcja "Towary".

![2. Widok szczegółów dokumentu wydania jednoetapowego, o statusie "W przygotowaniu", sekcje "Generowanie listu przewozowego" i "Podstawowe informacje".](\img\OIP.png)

2. Widok szczegółów dokumentu wydania jednoetapowego, o statusie "W przygotowaniu", sekcje "Generowanie listu przewozowego" i "Podstawowe informacje".

  - Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na wydanie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania i spakowanych, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której pobrano towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie,
      - Lokalizacja,
      - Nośnik,
      - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
      - JM.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Kontrahent
  - Aktualny status dokumentu,
  - Przez kogo dokument został zablokowany,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przycisk „Powrót”.

Jeśli wszystkie towary zostały ilościowo wydane zgodnie z awizacją, dokument podświetli się na zielono.

![3. Widok szczegółów dokumentu wydania jednoetapowego, o statusie "Zakończony".](\img\OIP.png)

3. Widok szczegółów dokumentu wydania jednoetapowego, o statusie "Zakończony".

### Wydania dwuetapowe (Wydanie + Kurier)

Na liście rozwijanej pozycji „Wydania”, w menu systemu Asiston WMS, będą widoczne dwa elementy:

- „Zbierania” – dokumenty do obsługi zbierania,
- „Wydania do kurierów” – dokumenty obsługujące przekazanie towarów do dostarczenia przez wybranego kuriera.

#### Zbieranie

Lista dokumentów zbierania („Wydania/Zbieranie”) będzie zawierać następujące kolumny:

- Checkbox do zaznaczania dokumentów do zagregowania,
- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent,
- Status:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Ilość towarów w dokumencie,
- Waga całkowita pozycji,
- Zagregowane,
- Typ,
- Listy przewozowe,
- Osoba blokująca,
- Postęp realizacji
- Akcje:
  - Szczegóły

Filtrowanie listy możliwe będzie według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Status – lista rozwijana:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Kontrahent,
- Produkt – lista rozwijana produktów, awizowanych do zbierania,
- Data utworzenia (od – do),
- Daty zakończenia (od – do),
- Liczba pozycji dokumentu,
- Uwagi dokumentu,
- Zawiera listy przewozowe,
- Odbiór osobisty,
- Osoba blokująca,
- Waga całkowita.

Lista będzie odświeżana i aktualizowana w integracji z systemem ERP – nowe awizacje będą automatycznie pobierane do systemu WMS i dodawane do listy, po dodaniu nowego dokumentu ZK w systemie ERP.

![4. Widok listy dokumentów zbierania.](\img\OIP.png)

4. Widok listy dokumentów zbierania.

Widok szczegółów dokumentu zbierania będzie się zmieniał wraz ze zmianą statusu dokumentu.

1. Dokument ze statusem „Oczekuje na zebranie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
      - JM (jednostka miary),
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Rozpocznij zbieranie”.

![5. Widok szczegółów dokumentu zbierania, ze statusem "Oczekuje na zebranie".](\img\OIP.png)

5. Widok szczegółów dokumentu zbierania, ze statusem "Oczekuje na zebranie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika początkowego,
    - Kodu towaru,
    - Partii,
    - Ilości,
    - Nośnika końcowego.
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik początkowy,
    - Ukryj partię,
    - Ukryj ilość,
    - Ukryj nośnik końcowy,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Przerwij”,
  - „Zakończ zbieranie”.

![6. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".](\img\OIP.png)

6. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".

![7. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".](\img\OIP.png)

7. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na zebranie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania i spakowanych, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której pobrano towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przycisk:
    - „Powrót”,
    - „Logi”

Jeśli wszystkie towary zostały zebrane zgodnie z awizacją, dokument podświetli się na zielono.

![8. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".](\img\OIP.png)

8. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".

#### Wydania do kurierów

Podstawowym widokiem pozycji „Wydania do kurierów” będzie lista kurierów, zintegrowanych z systemem Asiston WMS i zaznaczonych kolorem zielonym w konfiguracji kurierów (więcej w punkcie Kurierzy*)*). Lista będzie zawierać następujące kolumny:

- Nazwa (kuriera),
- Ilość paczek oczekujących (do wydania danemu kurierowi),
- Akcje:
  - Szczegóły,
  - Usuń.

Filtrowanie listy będzie możliwe według nazwy kuriera. Lista będzie automatycznie odświeżana i aktualizowana.

![9. Widok listy wydań do kurierów.](\img\OIP.png)

9. Widok listy wydań do kurierów.

Widok szczegółów wydania do kuriera, zawiera listę załadunków dla danego kuriera. Lista będzie wyświetlana w układzie następujących kolumn:

- Numer dokumentu,
- Status:
  - Oczekuje na załadunek,
  - Przerwany,
  - W przygotowaniu,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Osoba blokująca
- Akcje:
  - Szczegóły,
  - Usuń.

Filtrowanie listy będzie się mogło odbywać, przy użyciu przycisków filtrowania, według kryteriów:

- Numer dokumentu – pole do wpisania znaków,
- Status – lista rozwijana:
  - Oczekuje na załadunek,
  - Przerwany,
  - W przygotowaniu,
  - Zakończony,
- Data utworzenia (od - do),
- Data zakończenia (od – do),
- Osoba blokująca.

![0. Widok szczegółów wydania do kuriera.](\img\OIP.png)

0. Widok szczegółów wydania do kuriera.

Dodanie załadunku do listy nastąpi przyciskiem „Dodaj załadunek”. System Asiston WMS doda kolejną pozycję do listy załadunków i automatycznie nada jej status „Oczekuje na załadunek”.

Zestaw informacji w widoku szczegółów załadunku, będzie zależał od statusu dokumentu załadunku.

1. Status „Oczekuje na załadunek” zwróci następującą treść:
  1. Numer dokumentu załadunku,
  1. Datę zapisania dokumentu,
  1. Sekcję „Paczki oczekujące”
    1. Listę paczek, znajdujących się na lokalizacji danego kuriera i oczekujących na załadunek,
    1. Przycisk „Załaduj wszystkie”, pozwalający wydać kurierowi wszystkie paczki z listy oczekujących,
    1. Pole wyszukiwania pozycji z listy, po wpisanej frazie
  1. Sekcję „Podstawowe informacje”, zwracającą:
    1. Aktualny status dokumentu,
    1. Przez kogo dokument został zablokowany,
    1. Datę utworzenia,
    1. Datę zakończenia,
    1. Kurier (nazwa kuriera),
    1. Nr rejestracyjny (samochodu, na który będzie załadunek)
    1. Uwagi (pole tekstowe),
  1. Przyciski:
    1. Powrót,
    1. Rozpocznij zbieranie

![1. Widok szczegółów załadunku, status "Oczekuje na załadunek".](\img\OIP.png)

1. Widok szczegółów załadunku, status "Oczekuje na załadunek".

1. Status „W przygotowaniu” spowoduje wyświetlenie następującej treści:
  1. Numer dokumentu załadunku,
  1. Datę zapisania dokumentu,
  1. Sekcja załadunek:
    1. Pole do zeskanowania kodu opakowania do załadunku lub odpowiadającego mu listu przewozowego,
    1. Przycisk „Dodaj” – dodaje zeskanowane wyżej opakowanie do załadunku,
  1. Sekcja „Paczki oczekujące”:
    1. Lista paczek, znajdujących się na lokalizacji danego kuriera i oczekujących na załadunek,
    1. Przycisk „Załaduj wszystkie”, pozwalający wydać kurierowi wszystkie paczki z listy oczekujących,
    1. Pole wyszukiwania pozycji z listy, po wpisanej frazie,
  1. Sekcja „Podstawowe informacje”, zwracająca:
    1. Aktualny status dokumentu,
    1. Przez kogo dokument został zablokowany,
    1. Datę utworzenia,
    1. Datę zakończenia,
    1. Kurier (nazwa kuriera),
    1. Nr rejestracyjny (samochodu, na który będzie załadunek)
    1. Uwagi (pole tekstowe),
  1. Przyciski:
    1. Powrót,
    1. Przerwij
    1. Zakończ

![2. Widok szczegółów załadunku, status "W przygotowaniu".](\img\OIP.png)

2. Widok szczegółów załadunku, status "W przygotowaniu".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na wydanie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Status „Zakończony” zwróci następującą treść:
  1. Numer dokumentu załadunku,
  1. Datę zapisania dokumentu,
  1. Sekcja załadunek – lista z następującymi kolumnami:
    1. Numer kolejny pozycji na liście,
    1. Opakowanie (kod opakowania zbiorczego z towarem wydanym kurierowi),
    1. List przewozowy
  1. Sekcja „Podstawowe informacje”, zwracająca:
    1. Aktualny status dokumentu,
    1. Przez kogo dokument został zablokowany,
    1. Datę utworzenia,
    1. Datę zakończenia,
    1. Kurier (nazwa kuriera),
    1. Nr rejestracyjny (samochodu, na który będzie załadunek)
    1. Uwagi (pole tekstowe),
    1. Przycisk „Powrót”.

![3. Widok szczegółów załadunku, status "Zakończony".](\img\OIP.png)

3. Widok szczegółów załadunku, status "Zakończony".

## Wydania dwuetapowe (Zbieranie + Pakowanie)

Na liście rozwijanej pozycji „Wydania”, w menu systemu Asiston WMS, będą widoczne dwa elementy:

- „Zbieranie” – dokumenty do obsługi zbierania,
- „Pakowanie” – dokumenty obsługujące pakowanie zebranych towarów.

### 8.8.2.1     Zbieranie

Lista dokumentów zbierania („Wydania/Zbieranie”) będzie zawierać następujące kolumny:

- Checkbox do zaznaczania dokumentów do zagregowania,
- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent,
- Status:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Ilość towarów w dokumencie,
- Waga całkowita pozycji,
- Zagregowane,
- Typ,
- Listy przewozowe,
- Osoba blokująca,
- Postęp realizacji
- Akcje:
  - Szczegóły

Filtrowanie listy możliwe będzie według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Status – lista rozwijana:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Kontrahent,
- Produkt – lista rozwijana produktów, awizowanych do zbierania,
- Data utworzenia (od – do),
- Daty zakończenia (od – do),
- Liczba pozycji dokumentu,
- Uwagi dokumentu,
- Zawiera listy przewozowe,
- Odbiór osobisty,
- Osoba blokująca,
- Waga całkowita.

Lista będzie odświeżana i aktualizowana w integracji z systemem ERP – nowe awizacje będą automatycznie pobierane do systemu WMS i dodawane do listy, po dodaniu nowego dokumentu ZK w systemie ERP.

![4. Widok listy dokumentów zbierania.](\img\OIP.png)

4. Widok listy dokumentów zbierania.

Widok szczegółów dokumentu zbierania będzie się zmieniał wraz ze zmianą statusu dokumentu.

1. Dokument ze statusem „Oczekuje na zebranie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
      - JM (jednostka miary),
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Rozpocznij zbieranie”.

![5. Widok szczegółów dokumentu zbierania, ze statusem "Oczekuje na zebranie".](\img\OIP.png)

5. Widok szczegółów dokumentu zbierania, ze statusem "Oczekuje na zebranie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika początkowego,
    - Kodu towaru,
    - Partii,
    - Ilości,
    - Nośnika końcowego.
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik początkowy,
    - Ukryj partię,
    - Ukryj ilość,
    - Ukryj nośnik końcowy,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Przerwij”,
  - „Zakończ zbieranie”.

![6. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".](\img\OIP.png)

6. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".

![7. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".](\img\OIP.png)

7. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na zebranie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania i spakowanych, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której pobrano towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przycisk:
    - „Powrót”,
    - „Logi”

Jeśli wszystkie towary zostały zebrane zgodnie z awizacją, dokument podświetli się na zielono.

![8. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".](\img\OIP.png)

8. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".

### Pakowanie

Lista dokumentów pakowania („Wydania/Pakowanie”) będzie zawierać następujące kolumny:

- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent,
- Status:
  - Oczekuje na pakowanie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Ilość towarów w dokumencie,
- Waga całkowita pozycji,
- Osoba blokująca
- Postęp realizacji
- Akcje:
  - Szczegóły

Bezpośrednio nad listą dokumentów, widoczne będzie okno do skanowania kodu nośnika, wraz z przyciskami usuwania i zatwierdzania zeskanowanego kodu. Zatwierdzenie zeskanowanego kodu przefiltruje listę dokumentów pakowania i zwróci te, w których są towary na nośniku, o zeskanowanym kodzie.

Filtrowanie listy możliwe będzie także według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Kontrahent,
- Status – lista rozwijana:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Produkt – lista rozwijana produktów, awizowanych do pakowania,
- Data utworzenia (od – do),
- Daty zakończenia (od – do),
- Liczba pozycji dokumentu,
- Uwagi dokumentu,
- Zawiera listy przewozowe,
- Osoba blokująca,
- Waga całkowita.

Lista będzie odświeżana i aktualizowana za każdym razem, po zakończeniu dokumentu zbierania.

![9. Widok listy dokumentów pakowania.](\img\OIP.png)

9. Widok listy dokumentów pakowania.

Widok szczegółów dokumentu pakowania będzie się zmieniał wraz ze zmianą statusu dokumentu.

1. Dokument ze statusem „Oczekuje na wydanie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Nośnik,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie,
      - Lokalizacja,
      - Nośnik,
      - Ilość,
      - JM,
      - Partia.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Rozpocznij pakowanie”.

![0. Widok szczegółów dokumentu pakowania, ze statusem "Oczekuje na wydanie".](\img\OIP.png)

0. Widok szczegółów dokumentu pakowania, ze statusem "Oczekuje na wydanie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Opakowanie”, zawierającą:
  - Pole do zeskanowania kodu opakowania zbiorczego, jeśli w konfiguracji procesu zaznaczono wcześniej „Opakowanie zbiorcze w pakowaniu” (więcej w punkcie Opcje)
  - Przycisk „Zatwierdź”, po użyciu którego, w widoku sekcji „Opakowanie” zwracane będą dane opakowania zbiorczego z zeskanowanym kodem. Dane te obejmują:
    - Nazwa,
    - Kod,
    - Długość,
    - Szerokość,
    - Wysokość,
    - Waga,
    - Indywidualny kod,
    - Ikonka drukowania etykiety
    - Ikonka edycji (umożliwia powtórne zeskanowanie i dodanie opakowania zbiorczego).
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika,
    - Kodu towaru,
    - Partii,
    - Ilości
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik,
    - Ukryj partię,
    - Ukryj ilość,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Nośnik,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie,
      - Lokalizacja,
      - Nośnik,
      - Ilość,
      - JM,
      - Partia.
- Sekcję „Generowanie listu przewozowego”, jeśli w konfiguracji procesu wybrano wcześniej opcję „Generowanie listów przewozowych/W trakcie pakowania”. Sekcja zawiera:
  - Zestawienie wygenerowanych listów przewozowych, z kolumnami:
    - Kurier (nazwa kuriera),
    - Rodzaj przesyłki,
    - Ilość,
    - Waga,
    - Długość,
    - Szerokość,
    - Wysokość,
    - Numer listu przewozowego,
    - Opakowanie
  - Pola do wypełnienia przy generowaniu nowego listu przewozowego. Pola te będą udostępniane po użyciu przycisku „Dodaj pozycję” i będą to:
    - Kurier (nazwa kuriera),
    - Rodzaj przesyłki,
    - Ilość,
    - Waga,
    - Długość,
    - Szerokość,
    - Wysokość,
    - Ikonka usuwania
  - Przyciski: „Dodaj pozycję” oraz „Generuj list przewozowy”.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Przerwij”,
  - „Zakończ pakowanie”.

![1. Widok szczegółów dokumentu pakowania, o statusie "W przygotowaniu", sekcje: „Opakowanie”, "Zeskanuj pozycje" i "Towary".](\img\OIP.png)

1. Widok szczegółów dokumentu pakowania, o statusie "W przygotowaniu", sekcje: „Opakowanie”, "Zeskanuj pozycje" i "Towary".

![2. Widok szczegółów dokumentu pakowania, o statusie "W przygotowaniu", sekcje: "Generowanie listu przewozowego" i "Podstawowe informacje".](\img\OIP.png)

2. Widok szczegółów dokumentu pakowania, o statusie "W przygotowaniu", sekcje: "Generowanie listu przewozowego" i "Podstawowe informacje".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na zebranie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (wydaną/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Nośnik,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie (kod opakowania zbiorczego z towarem),
      - Lokalizacja,
      - Nośnik,
      - Ilość,
      - JM,
      - Partia.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przycisk „Powrót”.

Jeśli wszystkie towary zostały ilościowo spakowane zgodnie z awizacją, dokument podświetli się na zielono.

![3. Widok szczegółów dokumentu pakowania, o statusie "Zakończony".](\img\OIP.png)

3. Widok szczegółów dokumentu pakowania, o statusie "Zakończony".

## Wydania trzyetapowe

Na liście rozwijanej pozycji „Wydania”, w menu systemu Asiston WMS, będą widoczne trzy elementy:

- „Zbieranie” – dokumenty do obsługi zbierania,
- „Pakowanie” – dokumenty obsługujące pakowanie zebranych towarów,
- „Wydania do kurierów” - dokumenty obsługujące przekazanie towarów do dostarczenia przez wybranego kuriera.

### Zbieranie

Lista dokumentów zbierania („Wydania/Zbieranie”) będzie zawierać następujące kolumny:

- Checkbox do zaznaczania dokumentów do zagregowania,
- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent,
- Status:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Ilość towarów w dokumencie,
- Waga całkowita pozycji,
- Zagregowane,
- Typ,
- Listy przewozowe,
- Osoba blokująca,
- Postęp realizacji
- Akcje:
  - Szczegóły

Filtrowanie listy możliwe będzie według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Status – lista rozwijana:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Kontrahent,
- Produkt – lista rozwijana produktów, awizowanych do zbierania,
- Data utworzenia (od – do),
- Daty zakończenia (od – do),
- Liczba pozycji dokumentu,
- Uwagi dokumentu,
- Zawiera listy przewozowe,
- Odbiór osobisty,
- Osoba blokująca,
- Waga całkowita.

Lista będzie odświeżana i aktualizowana w integracji z systemem ERP – nowe awizacje będą automatycznie pobierane do systemu WMS i dodawane do listy, po dodaniu nowego dokumentu ZK w systemie ERP.

![4. Widok listy dokumentów zbierania.](\img\OIP.png)

4. Widok listy dokumentów zbierania.

Widok szczegółów dokumentu zbierania będzie się zmieniał wraz ze zmianą statusu dokumentu.

1. Dokument ze statusem „Oczekuje na zebranie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
      - JM (jednostka miary),
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Rozpocznij zbieranie”.

![5. Widok szczegółów dokumentu zbierania, ze statusem "Oczekuje na zebranie".](\img\OIP.png)

5. Widok szczegółów dokumentu zbierania, ze statusem "Oczekuje na zebranie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika początkowego,
    - Kodu towaru,
    - Partii,
    - Ilości,
    - Nośnika końcowego.
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik początkowy,
    - Ukryj partię,
    - Ukryj ilość,
    - Ukryj nośnik końcowy,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Kontrahent,
  - Aktualny status dokumentu,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Przerwij”,
  - „Zakończ zbieranie”.

![6. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".](\img\OIP.png)

6. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".

![7. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".](\img\OIP.png)

7. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na zebranie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania i spakowanych, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której pobrano towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przyciski:
    - „Powrót”,
    - „Logi”,

Jeśli wszystkie towary zostały zebrane zgodnie z awizacją, dokument podświetli się na zielono.

![8. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".](\img\OIP.png)

8. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".

### Pakowanie

Lista dokumentów pakowania („Wydania/Pakowanie”) będzie zawierać następujące kolumny:

- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent,
- Status:
  - Oczekuje na pakowanie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Ilość towarów w dokumencie,
- Waga całkowita pozycji,
- Osoba blokująca
- Postęp realizacji
- Akcje:
  - Szczegóły

Bezpośrednio nad listą dokumentów, widoczne będzie okno do skanowania kodu nośnika, wraz z przyciskami usuwania i zatwierdzania zeskanowanego kodu. Zatwierdzenie zeskanowanego kodu przefiltruje listę dokumentów pakowania i zwróci te, w których są towary na nośniku, o zeskanowanym kodzie.

Filtrowanie listy możliwe będzie także według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Kontrahent,
- Status – lista rozwijana:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Produkt – lista rozwijana produktów, awizowanych do pakowania,
- Data utworzenia (od – do),
- Daty zakończenia (od – do),
- Liczba pozycji dokumentu,
- Uwagi dokumentu,
- Zawiera listy przewozowe,
- Osoba blokująca,
- Waga całkowita.

Lista będzie odświeżana i aktualizowana za każdym razem, po zakończeniu dokumentu zbierania.

![9. Widok listy dokumentów pakowania.](\img\OIP.png)

9. Widok listy dokumentów pakowania.

Widok szczegółów dokumentu pakowania będzie się zmieniał wraz ze zmianą statusu dokumentu.

1. Dokument ze statusem „Oczekuje na wydanie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania),
    - Partia,
    - Nośnik,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie,
      - Lokalizacja,
      - Nośnik,
      - Ilość,
      - JM,
      - Partia.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Rozpocznij pakowanie”.

![0. Widok szczegółów dokumentu pakowania, ze statusem "Oczekuje na wydanie".](\img\OIP.png)

0. Widok szczegółów dokumentu pakowania, ze statusem "Oczekuje na wydanie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Opakowanie”, zawierającą:
  - Pole do zeskanowania kodu opakowania zbiorczego, jeśli w konfiguracji procesu zaznaczono wcześniej „Opakowanie zbiorcze w pakowaniu”.
  - Przycisk „Zatwierdź”, po użyciu którego, w widoku sekcji „Opakowanie” zwracane będą dane opakowania zbiorczego z zeskanowanym kodem. Dane te obejmują:
    - Nazwa,
    - Kod,
    - Długość,
    - Szerokość,
    - Wysokość,
    - Waga,
    - Indywidualny kod,
    - Ikonka drukowania etykiety
    - Ikonka edycji (umożliwia powtórne zeskanowanie i dodanie opakowania zbiorczego).
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika,
    - Kodu towaru,
    - Partii,
    - Ilości
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik,
    - Ukryj partię,
    - Ukryj ilość,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Nośnik,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie,
      - Lokalizacja,
      - Nośnik,
      - Ilość,
      - JM,
      - Partia.
- Sekcję „Generowanie listu przewozowego”, jeśli w konfiguracji procesu wybrano wcześniej opcję „Generowanie listów przewozowych/W trakcie pakowania” . Sekcja zawiera:
  - Zestawienie wygenerowanych listów przewozowych, z kolumnami:
    - Kurier (nazwa kuriera),
    - Rodzaj przesyłki,
    - Ilość,
    - Waga,
    - Długość,
    - Szerokość,
    - Wysokość,
    - Numer listu przewozowego,
    - Opakowanie
  - Pola do wypełnienia przy generowaniu nowego listu przewozowego. Pola te będą udostępniane po użyciu przycisku „Dodaj pozycję” i będą to:
    - Kurier (nazwa kuriera),
    - Rodzaj przesyłki,
    - Ilość,
    - Waga,
    - Długość,
    - Szerokość,
    - Wysokość,
    - Ikonka usuwania
  - Przyciski: „Dodaj pozycję” oraz „Generuj list przewozowy”.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Przerwij”,
  - „Zakończ pakowanie”.

![1. Widok szczegółów dokumentu pakowania, o statusie "W przygotowaniu", sekcje: „Opakowanie”, "Zeskanuj pozycje" i "Towary".](\img\OIP.png)

1. Widok szczegółów dokumentu pakowania, o statusie "W przygotowaniu", sekcje: „Opakowanie”, "Zeskanuj pozycje" i "Towary".

![2. Widok szczegółów dokumentu pakowania, o statusie "W przygotowaniu", sekcje: "Generowanie listu przewozowego" i "Podstawowe informacje".](\img\OIP.png)

2. Widok szczegółów dokumentu pakowania, o statusie "W przygotowaniu", sekcje: "Generowanie listu przewozowego" i "Podstawowe informacje".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na zebranie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (wydaną/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Nośnik,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Opakowanie (kod opakowania zbiorczego z towarem),
      - Lokalizacja,
      - Nośnik,
      - Ilość,
      - JM,
      - Partia.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przycisk „Powrót”.

Jeśli wszystkie towary zostały ilościowo spakowane zgodnie z awizacją, dokument podświetli się na zielono.

![3. Widok szczegółów dokumentu pakowania, o statusie "Zakończony".](\img\OIP.png)

3. Widok szczegółów dokumentu pakowania, o statusie "Zakończony".

### Wydania do kurierów

Podstawowym widokiem pozycji „Wydania do kurierów” będzie lista kurierów, zintegrowanych z systemem Asiston WMS i zaznaczonych kolorem zielonym w konfiguracji kurierów (więcej w punkcie* **Kurierzy*). Lista będzie zawierać następujące kolumny:

- Nazwa (kuriera),
- Ilość paczek oczekujących (do wydania danemu kurierowi),
- Akcje:
  - Szczegóły,
  - Usuń.

Filtrowanie listy będzie możliwe według nazwy kuriera. Lista będzie automatycznie odświeżana i aktualizowana.

![4. Widok listy wydań do kurierów.](\img\OIP.png)

4. Widok listy wydań do kurierów.

Widok szczegółów wydania do kuriera, zawiera listę załadunków dla danego kuriera. Lista będzie wyświetlana w układzie następujących kolumn:

- Numer dokumentu,
- Status:
  - Oczekuje na załadunek,
  - Przerwany,
  - W przygotowaniu,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Osoba blokująca,
- Akcje:
  - Szczegóły,
  - Usuń.

Filtrowanie listy będzie się mogło odbywać, przy użyciu przycisków filtrowania, według kryteriów:

- Numer dokumentu – pole do wpisania znaków,
- Status – lista rozwijana:
  - Oczekuje na załadunek,
  - Przerwany,
  - W przygotowaniu,
  - Zakończony,
- Data utworzenia (od - do),
- Data zakończenia (od – do),
- Osoba blokująca.

![5. Widok szczegółów wydania do kuriera.](\img\OIP.png)

5. Widok szczegółów wydania do kuriera.

Dodanie załadunku do listy nastąpi przyciskiem „Dodaj załadunek”. System Asiston WMS doda kolejną pozycję do listy załadunków i automatycznie nada jej status „Oczekuje na załadunek”.

Zestaw informacji w widoku szczegółów załadunku, będzie zależał od statusu dokumentu załadunku.

1. Status „Oczekuje na załadunek” zwróci następującą treść:
  1. Numer dokumentu załadunku,
  1. Datę zapisania dokumentu,
  1. Sekcję „Paczki oczekujące”
    1. Listę paczek, znajdujących się na lokalizacji danego kuriera i oczekujących na załadunek,
    1. Przycisk „Załaduj wszystkie”, pozwalający wydać kurierowi wszystkie paczki z listy oczekujących,
    1. Pole wyszukiwania pozycji z listy, po wpisanej frazie
  1. Sekcję „Podstawowe informacje”, zwracającą:
    1. Aktualny status dokumentu,
    1. Przez kogo dokument został zablokowany,
    1. Datę utworzenia,
    1. Datę zakończenia,
    1. Kurier (nazwa kuriera),
    1. Nr rejestracyjny (samochodu, na który będzie załadunek)
    1. Uwagi (pole tekstowe),
  1. Przyciski:
    1. Powrót,
    1. Logi,
    1. Rozpocznij zbieranie

![6. Widok szczegółów załadunku, status "Oczekuje na załadunek".](\img\OIP.png)

6. Widok szczegółów załadunku, status "Oczekuje na załadunek".

1. Status „W przygotowaniu” spowoduje wyświetlenie następującej treści:
  1. Numer dokumentu załadunku,
  1. Datę zapisania dokumentu,
  1. Sekcja załadunek:
    1. Pole do zeskanowania kodu opakowania do załadunku lub odpowiadającego mu listu przewozowego,
    1. Przycisk „Dodaj” – dodaje zeskanowane wyżej opakowanie do załadunku,
  1. Sekcja „Paczki oczekujące”:
    1. Lista paczek, znajdujących się na lokalizacji danego kuriera i oczekujących na załadunek,
    1. Przycisk „Załaduj wszystkie”, pozwalający wydać kurierowi wszystkie paczki z listy oczekujących,
    1. Pole wyszukiwania pozycji z listy, po wpisanej frazie,
  1. Sekcja „Podstawowe informacje”, zwracająca:
    1. Aktualny status dokumentu,
    1. Przez kogo dokument został zablokowany,
    1. Datę utworzenia,
    1. Datę zakończenia,
    1. Kurier (nazwa kuriera),
    1. Nr rejestracyjny (samochodu, na który będzie załadunek)
    1. Uwagi (pole tekstowe),
  1. Przyciski:
    1. Powrót,
    1. Przerwij
    1. Zakończ

![7. Widok szczegółów załadunku, status "W przygotowaniu".](\img\OIP.png)

7. Widok szczegółów załadunku, status "W przygotowaniu".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na wydanie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Status „Zakończony” zwróci następującą treść:
  1. Numer dokumentu załadunku,
  1. Datę zapisania dokumentu,
  1. Sekcja załadunek – lista z następującymi kolumnami:
    1. Numer kolejny pozycji na liście,
    1. Opakowanie (kod opakowania zbiorczego z towarem wydanym kurierowi),
    1. List przewozowy
  1. Sekcja „Paczki oczekujące”:
    1. Lista paczek, znajdujących się na lokalizacji danego kuriera i oczekujących na załadunek,
    1. Przycisk „Załaduj wszystkie”, pozwalający wydać kurierowi wszystkie paczki z listy oczekujących,
    1. Pole wyszukiwania pozycji z listy, po wpisanej frazie,
  1. Sekcja „Podstawowe informacje”, zwracająca:
    1. Aktualny status dokumentu,
    1. Przez kogo dokument został zablokowany,
    1. Datę utworzenia,
    1. Datę zakończenia,
    1. Kurier (nazwa kuriera),
    1. Nr rejestracyjny (samochodu, na który będzie załadunek)
    1. Uwagi (pole tekstowe),
    1. Przycisk „Powrót”, „Logi”.

![8. Widok szczegółów załadunku, status "Zakończony".](\img\OIP.png)

8. Widok szczegółów załadunku, status "Zakończony".

## Odbiory osobiste

W konfiguracji, do wyboru jest jeden z następujących rodzajów wydań:

- Proste – jednoetapowe wydanie towary
- Standardowe (Zbieranie + Odbiór osobisty),

### Wydanie proste – jednoetapowe wydanie towaru

Lista dokumentów („Wydania/Odbiór osobisty”) będzie zawierać następujące kolumny:

- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent,
- Priorytet,
- Status:
  - Anulowano
  - Do anulowania
  - Do zakończenia
  - Oczekuje na wydanie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Ilość towarów w dokumencie,
- Waga całkowita pozycji,
- Objętość całkowita,
- Osoba blokująca,
- Postęp realizacji
- Termin realizacji
- Osoba wystawiająca bazowy dokument
- Akcje:
  - Szczegóły

Filtrowanie listy możliwe będzie według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Status – lista rozwijana:
  - Anulowano
  - Do anulowania
  - Do zakończenia
  - Oczekuje na wydanie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Kontrahent,
- Produkt – lista rozwijana produktów,
- Produkt (Symbol/Nazwa/EAN) – wyszukiwarka tekstowa
- Data utworzenia,
- Daty zakończenia,
- Liczba pozycji dokumentu,
- Uwagi dokumentu,
- Osoba blokująca,
- Waga całkowita,
- Odętość całkowita,
- Osoba wystawiająca,
- Kod regału,
- Priorytet

Lista będzie odświeżana i aktualizowana w integracji z systemem ERP – nowe awizacje będą automatycznie pobierane do systemu WMS i dodawane do listy, po dodaniu nowego dokumentu ZK w systemie ERP.

![9. Widok listy dokumentów zbierania.](\img\OIP.png)

9. Widok listy dokumentów zbierania.

Widok szczegółów dokumentu zbierania będzie się zmieniał wraz ze zmianą statusu dokumentu.

1. Dokument ze statusem „Oczekuje na wydanie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ststus,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
      - JM (jednostka miary),
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Priorytet,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Rozpocznij”.

![0. Widok szczegółów dokumentu wydaniu, ze statusem "Oczekuje na wydanie".](\img\OIP.png)

0. Widok szczegółów dokumentu wydaniu, ze statusem "Oczekuje na wydanie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika początkowego,
    - Kodu towaru,
    - Partii,
    - Ilości,
    - Nośnika końcowego,
    - Status,
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik początkowy,
    - Ukryj partię,
    - Ukryj ilość,
    - Ukryj nośnik końcowy,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Przerwij”,
  - „Zakończ wydanie”.

![1. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".](\img\OIP.png)

1. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".

![2. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".](\img\OIP.png)

2. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na wydanie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania i spakowanych, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której pobrano towar do wydania - niewymagane),
    - Partia,
    - Status,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przycisk:
    - „Powrót”,
    - „Logi”

Jeśli wszystkie towary zostały zebrane zgodnie z awizacją, dokument podświetli się na zielono.

![3. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".](\img\OIP.png)

3. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".

### Wydanie standardowe (Zbieranie + Odbiór osobisty)

Na liście rozwijanej pozycji „Wydania”, w menu systemu Asiston WMS, będą widoczne dwa elementy:

- „Zbieranie” – dokumenty do obsługi zbierania,
- „Odbiór osobisty” - dokumenty obsługujące wydanie towarów bezpośrednio do klienta

#### Zbieranie

Lista dokumentów zbierania („Wydania/Zbieranie”) będzie zawierać następujące kolumny:

- Checkbox do zaznaczania dokumentów do zagregowania,
- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent,
- Status:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Ilość towarów w dokumencie,
- Waga całkowita pozycji,
- Zagregowane,
- Typ,
- Listy przewozowe,
- Osoba blokująca,
- Postęp realizacji
- Akcje:
  - Szczegóły

Filtrowanie listy możliwe będzie według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Status – lista rozwijana:
  - Oczekuje na zebranie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Kontrahent,
- Produkt – lista rozwijana produktów, awizowanych do zbierania,
- Data utworzenia (od – do),
- Daty zakończenia (od – do),
- Liczba pozycji dokumentu,
- Uwagi dokumentu,
- Zawiera listy przewozowe,
- Odbiór osobisty,
- Osoba blokująca,
- Waga całkowita.

Lista będzie odświeżana i aktualizowana w integracji z systemem ERP – nowe awizacje będą automatycznie pobierane do systemu WMS i dodawane do listy, po dodaniu nowego dokumentu ZK w systemie ERP.

![4. Widok listy dokumentów zbierania.](\img\OIP.png)

4. Widok listy dokumentów zbierania.

Widok szczegółów dokumentu zbierania będzie się zmieniał wraz ze zmianą statusu dokumentu.

1. Dokument ze statusem „Oczekuje na zebranie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
      - JM (jednostka miary),
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Rozpocznij zbieranie”.

![5. Widok szczegółów dokumentu zbierania, ze statusem "Oczekuje na zebranie".](\img\OIP.png)

5. Widok szczegółów dokumentu zbierania, ze statusem "Oczekuje na zebranie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika początkowego,
    - Kodu towaru,
    - Partii,
    - Ilości,
    - Nośnika końcowego.
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik początkowy,
    - Ukryj partię,
    - Ukryj ilość,
    - Ukryj nośnik końcowy,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Kontrahent,
  - Aktualny status dokumentu,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Przerwij”,
  - „Zakończ zbieranie”.

![6. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".](\img\OIP.png)

6. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".

![7. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".](\img\OIP.png)

7. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na zebranie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania i spakowanych, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której pobrano towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przyciski:
    - „Powrót”,
    - „Logi”,

Jeśli wszystkie towary zostały zebrane zgodnie z awizacją, dokument podświetli się na zielono.

![8. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".](\img\OIP.png)

8. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".

#### Odbiór osobisty

Lista dokumentów („Wydania/Odbiór osobisty”) będzie zawierać następujące kolumny:

- Numer dokumentu,
- Pierwotny dokument,
- Kontrahent,
- Priorytet,
- Status:
  - Anulowano
  - Do anulowania
  - Do zakończenia
  - Oczekuje na wydanie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Data utworzenia,
- Data zakończenia,
- Ilość towarów w dokumencie,
- Waga całkowita pozycji,
- Objętość całkowita,
- Osoba blokująca,
- Postęp realizacji
- Termin realizacji
- Osoba wystawiająca bazowy dokument
- Akcje:
  - Szczegóły

Filtrowanie listy możliwe będzie według następujących kryteriów:

- Nr dokumentu – pole do wpisywania znaków,
- Status – lista rozwijana:
  - Anulowano
  - Do anulowania
  - Do zakończenia
  - Oczekuje na wydanie,
  - W przygotowaniu,
  - Przerwano,
  - Zakończony.
- Kontrahent,
- Produkt – lista rozwijana produktów,
- Produkt (Symbol/Nazwa/EAN) – wyszukiwarka tekstowa
- Data utworzenia,
- Daty zakończenia,
- Liczba pozycji dokumentu,
- Uwagi dokumentu,
- Osoba blokująca,
- Waga całkowita,
- Odętość całkowita,
- Osoba wystawiająca,
- Kod regału,
- Priorytet

Lista będzie odświeżana i aktualizowana w integracji z systemem ERP – nowe awizacje będą automatycznie pobierane do systemu WMS i dodawane do listy, po dodaniu nowego dokumentu ZK w systemie ERP.

![9. Widok listy dokumentów zbierania.](\img\OIP.png)

9. Widok listy dokumentów zbierania.

Widok szczegółów dokumentu zbierania będzie się zmieniał wraz ze zmianą statusu dokumentu.

1. Dokument ze statusem „Oczekuje na wydanie” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ststus,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
      - JM (jednostka miary),
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Priorytet,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Rozpocznij”.

![0. Widok szczegółów dokumentu wydaniu, ze statusem "Oczekuje na wydanie".](\img\OIP.png)

0. Widok szczegółów dokumentu wydaniu, ze statusem "Oczekuje na wydanie".

1. Dokument ze statusem „W przygotowaniu” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Zeskanuj pozycje”, która pokaże:
  - Pola do skanowania:
    - Lokalizacji,
    - Nośnika początkowego,
    - Kodu towaru,
    - Partii,
    - Ilości,
    - Nośnika końcowego,
    - Status,
  - Przyciski ukrywania pól:
    - Ukryj lokalizację,
    - Ukryj nośnik początkowy,
    - Ukryj partię,
    - Ukryj ilość,
    - Ukryj nośnik końcowy,
    - Resetuj
  - Przycisk „Dodaj” (zeskanowaną pozycję)
- Sekcję „Towary”, która zwróci:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość (zeskanowaną do wydania/przeznaczoną do wydania),
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której należy pobrać towar do wydania - niewymagane),
    - Partia,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
- Przyciski:
  - „Powrót”,
  - „Logi”,
  - „Przerwij”,
  - „Zakończ wydanie”.

![1. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".](\img\OIP.png)

1. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcje: "Zeskanuj pozycje" i "Towary".

![2. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".](\img\OIP.png)

2. Widok szczegółów dokumentu zbierania, o statusie "W przygotowaniu", sekcja "Podstawowe informacje".

1. Widok szczegółów dokumentu ze statusem „Przerwano”, jest taki sam jak dokumencie, o statusie „Oczekuje na wydanie”. W sekcji „Podstawowe informacje”, wyświetla aktualny status „Przerwano”.
1. Dokument ze statusem „Zakończony” wyświetli:
- Numer dokumentu, wraz z datą jego zapisania,
- Pasek postępu obsługi wydania (w %),
- Sekcję „Towary”, zawierającą:
  - Pole wyszukiwania po danych listy towarów,
  - Listę towarów, awizowanych do wydania i spakowanych, lista będzie zawierać następujące kolumny:
    - Zdjęcie,
    - Symbol,
    - Nazwa,
    - Kod towaru,
    - Ilość,
    - JM (jednostka miary),
    - Pobierz z (kod lokalizacji z której pobrano towar do wydania - niewymagane),
    - Partia,
    - Status,
    - Ikonka podglądu lokalizacji, na których dany towar znajduje się w magazynie,
    - Ikonka drukowania etykiety,
    - Przycisk „Pokaż więcej/Pokaż mniej” rozwijający dodatkową sekcję z następującymi danymi dla danego towaru:
      - Lokalizacja początkowa,
      - Nośnik początkowy,
      - Ilość,
      - JM,
      - Partia,
      - Nośnik końcowy.
- Sekcję „Podstawowe informacje”, wyświetlającą informacje:
  - Numer dokumentu WMS,
  - Aktualny status dokumentu,
  - Kontrahent,
  - Przez kogo dokument został zablokowany do obsługi,
  - Datę utworzenia,
  - Datę zakończenia,
  - Uwagi (pole tekstowe),
  - Przycisk:
    - „Powrót”,
    - „Logi”

Jeśli wszystkie towary zostały zebrane zgodnie z awizacją, dokument podświetli się na zielono.

![3. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".](\img\OIP.png)

3. Widok szczegółów dokumentu zbierania, o statusie "Zakończony".

## Wydania bezpośrednie

Moduł wydań bezpośrednich służy do obsługi wydań, które można utworzyć bezpośrednio w systemie Asiston WMS i nie są one awizowane z systemu ERP.

Podstawowym widokiem po wejściu do modułu będzie lista dokumentów przyjęć. Lista zawiera kolumny:

- Numer dokumentu
- Status:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zwrócone
  - Zakończony
- Data utworzenia
- Data zakończenia
- Numer dokumentu realizującego
- Osoba blokująca
- Priorytet
- Akcje:
  - Szczegóły

Lista może być filtrowana wg:

- Numeru dokumentu – wyszukiwanie po znakach
- Statusu – wybór z listy rozwijanej:
  - Nowy
  - W przygotowaniu
  - Przerwano
  - Zwrócone
  - Zakończony
- Daty utworzenia (od – do)
- Daty zakończenia (od – do)
- Osoby blokującej
- Produktu
- Kontrahenta
- Priorytetu

![4. Przykładowy widok listy wydań bezpośrednich, w systemie Asiston WMS](\img\OIP.png)

4. Przykładowy widok listy wydań bezpośrednich, w systemie Asiston WMS

Utworzenie nowego dokumentu wydania bezpośredniego nastąpi przy użyciu przycisku „Dodaj wydanie”.

Kliknięcie przycisku zwróci widok z następującymi polami do wypełnienia:

- Typ wydania – WZ lub RW, do wyboru z listy rozwijanej,
- Kontrahent – jeśli wybrano wydanie zewnętrzne WZ,
- Magazyn ERP,
- Numer oryginalny,
- Tytuł,
- Opis

Dodanie wydania do listy nastąpi przyciskiem „Zapisz”. Cofnięcie do poprzedniego widoku jest możliwe przyciskiem „Powrót”.

![5. Widok dodania wydania bezpośredniego, w systemie Asiston WMS.](\img\OIP.png)

5. Widok dodania wydania bezpośredniego, w systemie Asiston WMS.

Widok szczegółów dokumentu wydania bezpośredniego zawiera:

- Numer dokumentu,
- Zapisano – data i godzina ostatniego automatycznego zapisania dokumentu
- Sekcję do skanowania wydawanych towarów, z następującymi polami:
  - Lokalizacja
  - Nośnik
  - Kod towaru
  - Partia
  - Ilość
  - Przyciski do ukrywania pól:
    - Ukryj lokalizację
    - Ukryj nośnik
    - Ukryj partia
    - Ukryj ilość
    - Przycisk resetowania wartości pól z sekcji skanowania,
    - Przycisk „Dodaj”, który dodaje zeskanowany towar do listy poniżej.
- Sekcję z listą dodanych towarów, sekcja zawiera:
  - Pole wyszukiwania frazy z dowolnej kolumny na liście,
  - Listę towarów z następującymi kolumnami:
    - Zdjęcie
    - Symbol
    - Nazwa
    - Ilość
    - JM
    - Ikonka wydruku etykiety
    - Przycisk widoku rozwijanego, który dla danego towaru zwraca dane o:
      - Lokalizacja
      - Nośnik
      - Ilości
      - JM
      - Partia
      - Ikonkę usuwania
- Sekcję „Podstawowe informacje”, która wyświetla
  - Status dokumentu
  - Nr dokumentu realizującego
  - Nazwę użytkownika, który zablokował dokument
  - Datę utworzenia dokumentu
  - Data zakończenia
  - Pole „Uwagi”, tu magazynier może wpisać uwagi, przy przyjęciu.

Bieżącą pracę z dokumentem można zakończyć przyciskami:

- Zakończ wydanie
- Anuluj
- Przerwij
- Powrót

![6. Widok szczegółów dokumentu wydania bezpośredniego.](\img\OIP.png)

6. Widok szczegółów dokumentu wydania bezpośredniego.


## Opisy procesów wydania

### Wydanie awizowane - bez akceptacji

#### Wydanie jednoetapowe, bez akceptacji

![Diagram 13. Wydanie jednoetapowe, bez akceptacji.](\img\OIP.png)

Diagram 13. Wydanie jednoetapowe, bez akceptacji.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

1. utworzy nowy dokument ZK/WMS,
1. przekaże go do listy wydań magazynowych.

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania/Jednoetapowe” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania. W systemie WMS automatycznie spowoduje to:

1. zmianę statusu dokumentu wydania magazynowego na ”Zakończone”,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w „Akceptacji”, statusu „Zakończone”.

*Powrót do konfiguracji*

#### Wydanie dwuetapowe (Jednoetapowe + Kurier), bez akceptacji

![Diagram 14. Wydanie dwuetapowe (Jednoetapowe + Kurier), bez akceptacji.](\img\OIP.png)

Diagram 14. Wydanie dwuetapowe (Jednoetapowe + Kurier), bez akceptacji.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

1. utworzy nowy dokument ZK/WMS,
1. przekaże go do listy wydań magazynowych,

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania/Jednoetapowe” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania. System WMS wyświetli popup z polem do skanowania lokalizacji kuriera oraz przyciskami potwierdzenia i resetowania zeskanowanego kodu. Magazynier zeskanuje kod wybranego kuriera i potwierdzi to przyciskiem, dostępnym na popupie. Spowoduje to automatyczne wykonanie następujących czynności:

1. nadanie statusu ”Zakończone” zapisanemu właśnie dokumentowi pakowania,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w „Akceptacji”, statusu „Zakończone”.

System WMS przesunie skompletowane opakowania na lokalizację kuriera, który będzie realizował dostawę do klienta,

Wydanie spakowanego towaru kurierowi, magazynier rozpocznie od wejścia do zakładki "Wydanie do kuriera". System WMS zwróci listę kurierów, do których oczekują paczki/listy przewozowe do wydania. Lista zawierać będzie kolumny:

- Nazwa kuriera
- Paczki oczekujące (ilość paczek oczekująca na wydanie)
- Przycisk do przejścia do szczegółów

Po wejściu do szczegółów wybranego kuriera system WMS przeniesie magazyniera do widoku listy dokumentów wydania temu kurierowi. Magazynier wykona dalej następujące czynności:

1. utworzy nowy dokument wydania, na którym będzie kompletował ładunek towaru i doda ten dokument do listy istniejących już dokumentów wydania,
1. przejdzie do szczegółów nowo utworzonego dokumentu wydania,
1. kliknie przycisk „Rozpocznij załadunek”,
1. zeskanuje kod z dodawanego opakowania lub listu przewozowego towaru, pobranego z lokalizacji danego kuriera i kompletowanego do załadunku,
1. po każdym zeskanowaniu kliknie przycisk „Dodaj” – zeskanowana paczka lub list przewozowy doda się do listy zeskanowanych paczek, poniżej pola skanowania. Równocześnie zeskanowana już paczka zniknie z listy paczek oczekujących.

Zakończenie wydania magazynier potwierdzi przyciskiem „Zakończ”. System automatycznie zaktualizuje status dokumentu wydania. Po zakończeniu wydania paczek towary zostaną wydane z lokalizacji, a system WMS wygeneruje protokół przekazania paczek.

*Powrót do konfiguracji*

#### Wydanie dwuetapowe (Zbieranie + Pakowanie), bez akceptacji

![Diagram 15. Wydanie dwuetapowe (Zbieranie + Pakowanie), bez akceptacji.](\img\OIP.png)

Diagram 15. Wydanie dwuetapowe (Zbieranie + Pakowanie), bez akceptacji.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

1. utworzy nowy dokument ZK/WMS,
1. przekaże go do listy zbierania w menu,
1. dołączy dokument ZK/WMS, do listy zamówień od klienta w Akceptacji.

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione produkty z listy i doda je do listy towarów zbieranych na wybrany nośnik,

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary, czyli lokalizacji pakowacza. System WMS:

1. zmieni status dokumentu zbierania na „Zakończone”
1. utworzy dokument pakowania z zebranymi towarami i doda go do listy w menu „Wydania/Pakowanie”, ze statusem „Oczekuje na pakowanie”

Magazynier wybierze dokument ze statusem „Oczekuje na pakowanie”, z listy dokumentów w menu „Wydania/Pakowanie”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. w systemie WMS wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.
1. Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier zeskanuje kody z opakowań jednostkowych zebranego towaru i doda je do listy towarów spakowanych.

W dokumencie pakowania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu pakowania magazynier zakończy przyciskiem zapisywania. W systemie WMS automatycznie spowoduje to:

1. nadanie statusu ”Zakończone” zapisanemu właśnie dokumentowi pakowania,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w „Akceptacji, statusu „Zakończone”.

*Powrót do konfiguracji*

#### Wydanie trzyetapowe, bez akceptacji

![Diagram 16. Wydanie trzyetapowe, bez akceptacji.](\img\OIP.png)

Diagram 16. Wydanie trzyetapowe, bez akceptacji.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

1. utworzy nowy dokument ZK/WMS,
1. przekaże go do listy zbierania w menu,

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione produkty z listy i doda je do listy towarów zbieranych na wybrany nośnik,

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary, czyli lokalizacji pakowacza. System WMS:

1. zmieni status dokumentu zbierania na „Zakończone”
1. utworzy dokument pakowania z zebranymi towarami i doda go do listy w menu „Wydania/Pakowanie”, ze statusem „Oczekuje na pakowanie”

Magazynier wybierze dokument ze statusem „Oczekuje na pakowanie”, z listy dokumentów w menu „Wydania/Pakowanie”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. w systemie WMS wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier zeskanuje kody z opakowań jednostkowych zebranego towaru i doda je do listy towarów spakowanych.

W dokumencie pakowania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu pakowania magazynier zakończy przyciskiem zapisywania. System WMS wyświetli popup z polem do skanowania lokalizacji kuriera oraz przyciskami potwierdzenia i resetowania zeskanowanego kodu. Magazynier zeskanuje kod wybranego kuriera i potwierdzi to przyciskiem, dostępnym na popupie. Spowoduje to automatyczne wykonanie następujących czynności:

1. nadanie statusu ”Zakończone” zapisanemu właśnie dokumentowi pakowania,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w „Akceptacji”, statusu „Zakończone”.

System WMS przesunie skompletowane opakowania na lokalizację kuriera, który będzie realizował dostawę do klienta,

Wydanie spakowanego towaru kurierowi, magazynier rozpocznie od wejścia do zakładki "Wydanie do kuriera". System WMS zwróci listę kurierów, do których oczekują paczki/listy przewozowe do wydania. Lista zawierać będzie kolumny:

- - Nazwa kuriera
- - Paczki oczekujące (ilość paczek oczekująca na wydanie)
- - Przycisk do przejścia do szczegółów

Po wejściu do szczegółów wybranego kuriera system WMS przeniesie magazyniera do widoku listy dokumentów wydania temu kurierowi. Magazynier wykona dalej następujące czynności:

1. utworzy nowy dokument wydania, na którym będzie kompletował ładunek towaru i doda ten dokument do listy istniejących już dokumentów wydania,
1. przejdzie do szczegółów nowo utworzonego dokumentu wydania,
1. kliknie przycisk „Rozpocznij załadunek”,
1. zeskanuje kod z dodawanego opakowania lub listu przewozowego towaru, pobranego z lokalizacji danego kuriera i kompletowanego do załadunku,
1. po każdym zeskanowaniu kliknie przycisk „Dodaj” – zeskanowana paczka lub list przewozowy doda się do listy zeskanowanych paczek, poniżej pola skanowania. Równocześnie zeskanowana już paczka zniknie z listy paczek oczekujących.

Zakończenie wydania magazynier potwierdzi przyciskiem „Zakończ”. System automatycznie zaktualizuje status dokumentu wydania. Po zakończeniu wydania paczek towary zostaną wydane z lokalizacji, a system WMS wygeneruje protokół przekazania paczek.

*Powrót do konfiguracji*

### Wydanie awizowane - z początkową akceptacją

#### Wydanie jednoetapowe, z początkową akceptacją

![Diagram 17. Wydanie jednoetapowe, z początkową akceptacją](\img\OIP.png)

Diagram 17. Wydanie jednoetapowe, z początkową akceptacją

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w „Akceptacji”.

Na nowo utworzonym dokumencie ZK/WMS, „Akceptacja” wykona następujące działania:

1. Otworzy dokument,
1. Sprawdzi poprawność danych,
1. W razie potrzeby skoryguje:
  1. dane kontrahenta i dostawy,
  1. rodzaj kolejki zbierania i pakowania dla poszczególnych towarów - proponowane kolejki będą wyświetlane domyślnie, na podstawie cech towarów w systemie ERP.

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do wydania magazynowego. System WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania. W systemie WMS automatycznie spowoduje to:

1. zmianę statusu dokumentu wydania magazynowego na ”Zakończone”,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w „Akceptacji” statusu „Zakończone”.

*Powrót do konfiguracji*

#### Wydanie dwuetapowe (Jednoetapowe + Kurier), z początkową akceptacją

![Diagram 18. Wydanie dwuetapowe (Jednoetapowe + Kurier), z początkową akceptacją.](\img\OIP.png)

Diagram 18. Wydanie dwuetapowe (Jednoetapowe + Kurier), z początkową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w „Akceptacji”.

Na nowo utworzonym dokumencie ZK/WMS, „Akceptacja” wykona następujące działania:

- Otworzy dokument,
- Sprawdzi poprawność danych,
- W razie potrzeby skoryguje:
  - dane kontrahenta i dostawy
  - rodzaj kolejki zbierania i pakowania dla poszczególnych towarów - proponowane kolejki będą wyświetlane domyślnie, na podstawie cech towarów w systemie ERP.

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do wydania magazynowego. System WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania. System WMS wyświetli popup z polem do skanowania lokalizacji kuriera oraz przyciskami potwierdzenia i resetowania zeskanowanego kodu. Magazynier zeskanuje kod wybranego kuriera i potwierdzi to przyciskiem, dostępnym na popupie. Spowoduje to automatyczne wykonanie następujących czynności:

1. nadanie statusu ”Zakończone” zapisanemu właśnie dokumentowi pakowania,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w „Akceptacji” statusu „Zakończone”.

System WMS, automatycznie przesunie skompletowane opakowania na lokalizację kuriera, który będzie realizował dostawę do klienta,

Wydanie spakowanego towaru kurierowi, magazynier rozpocznie od wejścia do zakładki "Wydanie do kuriera". System WMS zwróci listę kurierów, do których oczekują paczki/listy przewozowe do wydania. Lista zawierać będzie kolumny:

- Nazwa kuriera
- Paczki oczekujące (ilość paczek oczekująca na wydanie)
- Przycisk do przejścia do szczegółów

Po wejściu do szczegółów wybranego kuriera system WMS przeniesie magazyniera do widoku listy dokumentów wydania temu kurierowi. Magazynier wykona dalej następujące czynności:

1. utworzy nowy dokument wydania, na którym będzie kompletował ładunek towaru i doda ten dokument do listy istniejących już dokumentów wydania,
1. przejdzie do szczegółów nowo utworzonego dokumentu wydania,
1. kliknie przycisk „Rozpocznij załadunek”,
1. zeskanuje kod z dodawanego opakowania lub listu przewozowego towaru, pobranego z lokalizacji danego kuriera i kompletowanego do załadunku,
1. po każdym zeskanowaniu kliknie przycisk „Dodaj” – zeskanowana paczka lub list przewozowy doda się do listy zeskanowanych paczek, poniżej pola skanowania. Równocześnie zeskanowana już paczka zniknie z listy paczek oczekujących.

Zakończenie wydania magazynier potwierdzi przyciskiem „Zakończ”. System automatycznie zaktualizuje status dokumentu wydania. Po zakończeniu wydania paczek towary zostaną wydane z lokalizacji, a system WMS wygeneruje protokół przekazania paczek.

*Powrót do konfiguracji*

#### Wydanie dwuetapowe (Zbieranie + Pakowanie), z początkową akceptacją

![Diagram 19. Wydanie dwuetapowe (Zbieranie + Pakowanie), z początkową akceptacją.](\img\OIP.png)

Diagram 19. Wydanie dwuetapowe (Zbieranie + Pakowanie), z początkową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w „Akceptacji”.

Na nowo utworzonym dokumencie ZK/WMS, „Akceptacja” wykona następujące działania:

1. Otworzy dokument,
1. Sprawdzi poprawność danych,
1. W razie potrzeby skoryguje:
  1. dane kontrahenta i dostawy,
  1. rodzaj kolejki zbierania i pakowania dla poszczególnych towarów - proponowane kolejki będą wyświetlane domyślnie, na podstawie cech towarów w systemie ERP.

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do zbierania w magazynie. System WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS:

1. wpisze kod nośnika do zbierania lub zaakceptuje nośnik, domyślnie proponowany przez system,
1. zeskanuje kolejno zamówione produkty z listy i doda je do listy towarów zbieranych na wybrany nośnik,

Po skompletowaniu na nośniku towarów z listy zamówionych, magazynier zakończy zbieranie przyciskiem zapisywania oraz wykona szybkie przesunięcie na wybraną lokalizację pakowania. System WMS:

1. zmieni status dokumentu zbierania na „Zakończone”
1. utworzy dokument pakowania z zebranymi towarami i doda go do listy w menu „Wydania/Pakowanie”, ze statusem „Oczekuje na pakowanie”

Magazynier wybierze dokument ze statusem „Oczekuje na pakowanie”, z listy dokumentów w menu „Wydania/Pakowanie”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. w systemie WMS wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier zeskanuje kody z opakowań jednostkowych zebranego towaru i doda je do listy towarów spakowanych.

W dokumencie pakowania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu pakowania magazynier zakończy przyciskiem zapisywania. W systemie WMS automatycznie spowoduje to:

1. nadanie statusu ”Zakończone” zapisanemu właśnie dokumentowi pakowania,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w „Akceptacji”, statusu „Zakończone”.

*Powrót do konfiguracji*

#### Wydanie trzyetapowe, z początkową akceptacją

![Diagram 20. Wydanie trzyetapowe, z początkową akceptacją.](\img\OIP.png)

Diagram 20. Wydanie trzyetapowe, z początkową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w „Akceptacji”.

Na nowo utworzonym dokumencie ZK/WMS, „Akceptacja” wykona następujące działania:

1. Otworzy dokument,
1. Sprawdzi poprawność danych,
1. W razie potrzeby skoryguje:
  1. dane kontrahenta i dostawy,
  1. rodzaj kolejki zbierania i pakowania dla poszczególnych towarów - proponowane kolejki będą wyświetlane domyślnie, na podstawie cech towarów w systemie ERP.

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do zbierania w magazynie. System WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS:

1. wpisze kod nośnika do zbierania lub zaakceptuje nośnik, domyślnie proponowany przez system,
1. zeskanuje kolejno zamówione produkty z listy i doda je do listy towarów zbieranych na wybrany nośnik,

Po skompletowaniu na nośniku towarów z listy zamówionych, magazynier zakończy zbieranie przyciskiem zapisywania oraz wykona szybkie przesunięcie na wybraną lokalizację pakowania. System WMS:

1. zmieni status dokumentu zbierania na „Zakończone – do akceptacji”
1. utworzy dokument pakowania z zebranymi towarami i doda go do listy w menu „Wydania/Pakowanie”, ze statusem „Oczekuje na pakowanie”

Magazynier wybierze dokument ze statusem „Oczekuje na pakowanie”, z listy dokumentów w menu „Wydania/Pakowanie”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. w systemie WMS wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier zeskanuje kody z opakowań jednostkowych zebranego towaru i doda je do listy towarów spakowanych.

W dokumencie pakowania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu pakowania magazynier zakończy przyciskiem zapisywania. System WMS wyświetli popup z polem do skanowania lokalizacji kuriera oraz przyciskami potwierdzenia i resetowania zeskanowanego kodu. Magazynier zeskanuje kod wybranego kuriera i potwierdzi to przyciskiem, dostępnym na popupie. Spowoduje to automatyczne wykonanie następujących czynności:

1. nadanie statusu ”Zakończone” zapisanemu właśnie dokumentowi pakowania,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w „Akceptacji” statusu „Zakończone”.

System WMS, automatycznie przesunie skompletowane opakowania na lokalizację kuriera, który będzie realizował dostawę do klienta,

Wydanie spakowanego towaru kurierowi, magazynier rozpocznie od wejścia do zakładki "Wydanie do kuriera". System WMS zwróci listę kurierów, do których oczekują paczki/listy przewozowe do wydania. Lista zawierać będzie kolumny:

- Nazwa kuriera
- Paczki oczekujące (ilość paczek oczekująca na wydanie)
- Przycisk do przejścia do szczegółów

Po wejściu do szczegółów wybranego kuriera system WMS przeniesie magazyniera do widoku listy dokumentów wydania temu kurierowi. Magazynier wykona dalej następujące czynności:

1. utworzy nowy dokument wydania, na którym będzie kompletował ładunek towaru i doda ten dokument do listy istniejących już dokumentów wydania,
1. przejdzie do szczegółów nowo utworzonego dokumentu wydania,
1. kliknie przycisk „Rozpocznij załadunek”,
1. zeskanuje kod z dodawanego opakowania lub listu przewozowego towaru, pobranego z lokalizacji danego kuriera i kompletowanego do załadunku,
1. po każdym zeskanowaniu kliknie przycisk „Dodaj” – zeskanowana paczka lub list przewozowy doda się do listy zeskanowanych paczek, poniżej pola skanowania. Równocześnie zeskanowana już paczka zniknie z listy paczek oczekujących.

Zakończenie wydania magazynier potwierdzi przyciskiem „Zakończ”. System automatycznie zaktualizuje status dokumentu wydania. Po zakończeniu wydania paczek towary zostaną wydane z lokalizacji, a system WMS wygeneruje protokół przekazania paczek.

*Powrót do konfiguracji*

### Wydanie awizowane - z końcową akceptacją

#### Wydanie jednoetapowe, z końcową akceptacją

![Diagram 21. Wydanie jednoetapowe, z końcową akceptacją.](\img\OIP.png)

Diagram 21. Wydanie jednoetapowe, z końcową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

1. utworzy nowy dokument ZK/WMS,
1. przekaże go do listy wydań magazynowych,

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mógł ręcznie wprowadzić zmiany. Jeśli nie zaakceptuje dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu od klienta (ZK/WMS) i wydanych z magazynu.

A.    Jeśli ilości te będą zgodne:

a.    System WMS automatycznie:

i.    zmieni status dokumentu wydania magazynowego na ”Zakończone”,

ii.    nada dokumentowi ZK/WMS w „Akceptacji”, status „Zakończone”,

b.    System ERP automatycznie utworzy WZ na towar, zatwierdzony do wydania.

B. Jeśli ilości nie będą zgodne, system – w zależności od sposobu postępowania, wybranego w konfiguracji WMS – zadziała w jeden wymienionych poniżej sposobów:

  1. zwróci dokument do magazynu, na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji), dokument po zwrocie otrzyma status "Zwrócone",
  1. obsłuży niepełne wydanie ścieżką opisaną w punkcie „A” (tak, jak przy ilościach zgodnych),
  1. na niewydaną ilość zamówionego towaru, system ERP utworzy zamówienie różnicowe, a niepełne wydanie obsłuży ścieżką opisaną w punkcie „A” (jak przy ilościach zgodnych).

*Powrót do konfiguracji*

#### Wydanie dwuetapowe (Jednoetapowe + Kurier), z końcową akceptacją

![Diagram 22. Wydanie dwuetapowe (Jednoetapowe + Kurier), z końcową akceptacją.](\img\OIP.png)

Diagram 22. Wydanie dwuetapowe (Jednoetapowe + Kurier), z końcową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

1. utworzy nowy dokument ZK/WMS,
1. przekaże go do listy wydań magazynowych.

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem „Zakończ i przekaż do akceptacji”. System WMS automatycznie sprawdzi czy towar był spakowany przynajmniej do jednego opakowania zbiorczego oraz czy list przewozowy został wygenerowany.

Jeżeli Opakowanie zbiorcze zostało użyte lub został wygenerowany list przewozowy, czyli wystąpiła jedna z kombinacji:

- Opakowanie – TAK, List – NIE,
- Opakowanie – NIE, List – TAK,
- Opakowanie – TAK, List –TAK,

to system wyświetli popup, w którym będą:

- Informacja na jaką lokalizację kuriera (lub „brak kuriera”, jeśli nie był wybrany list przewozowy) należy przesunąć spakowany towar z danego dokumentu wydania,
- Pole do skanowania kodu lokalizacji kuriera
- Pole do     skanowania kodu towaru (lub opakowania zbiorczego) na lokalizacji kuriera,
- Listę towarów (lub opakowań zbiorczych) do przesunięcia – po zeskanowaniu danego towaru, jego kolor na liście się zmieni,
- Przycisk zatwierdzenia skanowania – przesunięcia towarów z listy na lokalizację kuriera,
- Przycisk resetowania skanowania – przesunięcia towarów z listy.

Zatwierdzenie zeskanowania towarów (lub opakowań zbiorczych) na lokalizacji kuriera, spowoduje że system WMS automatycznie:

- Doda każdy zeskanowany towar (lub opakowanie zbiorcze) do lokalizacji kuriera i nada mu status „Oczekuje na zatwierdzenie” – z tym statusem towar (paczka) nie będzie mógł być wydany kurierowi,
- Doda ilości towarów, przesuniętych na lokalizację kuriera i powiązanych z danym dokumentem wydania, do dokumentu ZK/WMS oraz przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

Jeżeli opakowanie zbiorcze nie było użyte, ani nie został wygenerowany list przewozowy, to system WMS od razu przekaże dane z dokumentu wydania do dokumentu ZK/WMS, do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mógł ręcznie wprowadzić zmiany. Jeśli nie zaakceptuje dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu od klienta (ZK/WMS) i wydanych z magazynu.

A.    Jeśli ilości te będą zgodne, to system WMS automatycznie:

1. zmieni status dokumentu wydania magazynowego na ”Zakończone”,
1. nada dokumentowi ZK/WMS w „Akceptacji” status „Zakończone”, co będzie równoznaczne z końcową akceptacją wydania magazynowego.

B. Jeśli ilości nie będą zgodne, system – w zależności od sposobu postępowania, wybranego w konfiguracji WMS – zadziała w jeden wymienionych poniżej sposobów:

1. zwróci dokument do magazynu, na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji), dokument po zwrocie otrzyma status "Zwrócone",
1. obsłuży niepełne wydanie ścieżką opisaną w punkcie „A” (tak, jak przy ilościach zgodnych),
1. na niewydaną ilość zamówionego towaru, system ERP utworzy zamówienie różnicowe, a niepełne wydanie obsłuży ścieżką opisaną w punkcie „A” (jak przy ilościach zgodnych).

Po zatwierdzeniu wydania przez handel (końcowej akceptacji handlowej):

1. System ERP automatycznie utworzy WZ na towar, zatwierdzony do wydania,
1. System WMS zmieni status towarów lub paczek, przesuniętych na lokalizację kuriera i powiązanych z zakończonym dokumentem wydania magazynowego, z „Do akceptacji” na „Do wydania”.

Wydanie spakowanego towaru kurierowi, magazynier rozpocznie od wejścia do zakładki "Wydanie do kuriera". System WMS zwróci listę kurierów, do których oczekują paczki/listy przewozowe do wydania. Lista zawierać będzie kolumny:

- Nazwa kuriera
- Paczki oczekujące (ilość paczek oczekująca na wydanie)
- Przycisk do przejścia do szczegółów

Po wejściu do szczegółów wybranego kuriera system WMS przeniesie magazyniera do widoku listy dokumentów wydania temu kurierowi. Magazynier wykona dalej następujące czynności:

1. utworzy nowy dokument wydania, na którym będzie kompletował ładunek towaru i doda ten dokument do listy istniejących już dokumentów wydania,
1. przejdzie do szczegółów nowo utworzonego dokumentu wydania,
1. kliknie przycisk „Rozpocznij załadunek”,
1. zeskanuje kod z dodawanego opakowania lub listu przewozowego towaru, pobranego z lokalizacji danego kuriera i kompletowanego do załadunku,
1. po każdym zeskanowaniu kliknie przycisk „Dodaj” – zeskanowana paczka lub list przewozowy doda się do listy zeskanowanych paczek, poniżej pola skanowania. Równocześnie zeskanowana już paczka zniknie z listy paczek oczekujących.

Zakończenie wydania magazynier potwierdzi przyciskiem „Zakończ”. System automatycznie zaktualizuje status dokumentu wydania. Po zakończeniu wydania paczek towary zostaną wydane z lokalizacji, a system WMS wygeneruje protokół przekazania paczek.

*Powrót do konfiguracji*

#### Wydanie dwuetapowe (Zbieranie + Pakowanie), z końcową akceptacją

![Diagram 23. Wydanie dwuetapowe (Zbieranie + Pakowanie), z końcową akceptacją.](\img\OIP.png)

Diagram 23. Wydanie dwuetapowe (Zbieranie + Pakowanie), z końcową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

1. utworzy nowy dokument ZK/WMS,
1. przekaże go do listy zbierania,

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione produkty z listy i doda je do listy towarów zbieranych na wybrany nośnik,

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary, czyli lokalizacji pakowacza. System WMS:

1. zmieni status dokumentu zbierania na „Zakończone”
1. utworzy dokument pakowania z zebranymi towarami i doda go do listy w menu „Wydania/Pakowanie”, ze statusem „Oczekuje na pakowanie”

Magazynier wybierze dokument ze statusem „Oczekuje na pakowanie”, z listy dokumentów w menu „Wydania/Pakowanie”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. w systemie WMS wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier zeskanuje kody z opakowań jednostkowych zebranego towaru i doda je do listy towarów spakowanych.

W dokumencie pakowania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu pakowania magazynier zakończy przyciskiem zapisywania „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mógł ręcznie wprowadzić zmiany. Jeśli nie zaakceptuje dokumentu, zwróci go do magazynu na listę awizowanych dokumentów pakowania, w celu korekty i ponownego przeprowadzenia procesu pakowania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone". Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu od klienta (ZK/WMS) i wydanych z magazynu.

A.    Jeśli ilości te będą zgodne:

a.    System WMS automatycznie

i.    zmieni status dokumentu pakowania na ”Zakończone”,

ii.    nada dokumentowi ZK/WMS w „Akceptacji” status „Zakończone”,

b.    System ERP automatycznie utworzy WZ na towar, zatwierdzony do wydania.

B. Jeśli ilości nie będą zgodne, system – w zależności od sposobu postępowania, wybranego w konfiguracji WMS – zadziała w jeden wymienionych poniżej sposobów:

  1. zwróci dokument do magazynu, na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji), dokument po zwrocie otrzyma status "Zwrócone",
  1. obsłuży niepełne wydanie ścieżką opisaną w punkcie „A” (tak, jak przy ilościach zgodnych),
  1. na niewydaną ilość zamówionego towaru, system ERP utworzy zamówienie różnicowe, a niepełne wydanie obsłuży ścieżką opisaną w punkcie „A” (jak przy ilościach zgodnych).

*Powrót do konfiguracji *

#### Wydanie trzyetapowe, z końcową akceptacją

![Diagram 24. Wydanie trzyetapowe, z końcową akceptacją.](\img\OIP.png)

Diagram 24. Wydanie trzyetapowe, z końcową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

1. utworzy nowy dokument ZK/WMS,
1. przekaże go do listy wydań magazynowych,

Na podstawie danych z ZK/WMS, system WMS automatycznie wygeneruje dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione produkty z listy i doda je do listy towarów zbieranych na wybrany nośnik,

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary, czyli lokalizacji pakowacza. System WMS:

1. zmieni status dokumentu zbierania na „Zakończone”,
1. utworzy dokument pakowania z zebranymi towarami i doda go do listy w menu „Wydania/Pakowanie”, ze statusem „Oczekuje na pakowanie”.

Magazynier wybierze dokument ze statusem „Oczekuje na pakowanie”, z listy dokumentów w menu „Wydania/Pakowanie”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. w systemie WMS wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier zeskanuje kody z opakowań jednostkowych zebranego towaru i doda je do listy towarów spakowanych.

W dokumencie pakowania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem.

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu pakowania magazynier zakończy przyciskiem zapisywania „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mógł ręcznie wprowadzić zmiany oraz wybrać kuriera, któremu towar zostanie wydany do dostarczenia klientowi. Jeśli „Akceptacja” nie zatwierdzi dokumentu, zwróci go do magazynu na listę awizowanych dokumentów pakowania, w celu korekty i ponownego przeprowadzenia procesu pakowania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone". Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu od klienta (ZK/WMS) i wydanych z magazynu.

A.    Jeśli ilości te będą zgodne:

a.    System WMS automatycznie:

i.    zmieni status dokumentu pakowania na:

-- „Zakończone” jeśli przy końcowym zatwierdzeniu „Akceptacja” wskazała kuriera do dostarczenia,

-- „Zakończone, wybrać kuriera” jeśli przy końcowej akceptacji nie wskazała kuriera

ii.    nada dokumentowi ZK/WMS w „Akceptacji” status „Zakończone”,

b.    System ERP automatycznie utworzy WZ na towar, zatwierdzony do wydania.

B. Jeśli ilości nie będą zgodne, system WMS – w zależności od sposobu postępowania, wybranego w konfiguracji WMS – zadziała w jeden wymienionych poniżej sposobów:

  1. zwróci dokument do magazynu, na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji), dokument po zwrocie otrzyma status "Zwrócone",
  1. obsłuży niepełne wydanie ścieżką opisaną w punkcie „A” (tak, jak przy ilościach zgodnych),
  1. na niewydaną ilość zamówionego towaru, system ERP utworzy zamówienie różnicowe, a niepełne wydanie obsłuży ścieżką opisaną w punkcie „A” (jak przy ilościach zgodnych).

Po zatwierdzeniu wydania przez „Akceptację” nastąpi przesunięcie spakowanych towarów na lokalizację kuriera, który obsłuży dostarczenie do klienta. Przesunięcie to będzie mogło się odbywać jednym z dwóch następujących sposobów:

1. Automatycznie, jeśli dokument pakowania (po zatwierdzeniu przez „Akceptację”) ma status „Zakończone”,
1. Z ręcznym wyborem kuriera, jeżeli dokument pakowania ma status „Zakończone, wybrać kuriera”; wówczas magazynier:
  1. otworzy dokument pakowania,
  1. kliknie przycisk wyboru kuriera, po którym system WMS zwróci popup z listą rozwijaną kurierów do wyboru,
  1. wybierze kuriera z listy rozwijanej,
  1. zakończy wybór przyciskiem „Wybierz”, a system WMS przesunie spakowane towary na lokalizację wybranego kuriera

Wydanie spakowanego towaru kurierowi, magazynier rozpocznie od wejścia do zakładki "Wydanie do kuriera". System WMS zwróci listę kurierów, do których oczekują paczki/listy przewozowe do wydania. Lista zawierać będzie kolumny:

- Nazwa kuriera
- Paczki oczekujące (ilość paczek oczekująca na wydanie)
- Przycisk do przejścia do szczegółów

Po wejściu do szczegółów wybranego kuriera system WMS przeniesie magazyniera do widoku listy dokumentów wydania temu kurierowi. Magazynier wykona dalej następujące czynności:

1. utworzy nowy dokument wydania, na którym będzie kompletował ładunek towaru i doda ten dokument do listy istniejących już dokumentów wydania,
1. przejdzie do szczegółów nowo utworzonego dokumentu wydania,
1. kliknie przycisk „Rozpocznij załadunek”,
1. zeskanuje kod z dodawanego opakowania lub listu przewozowego towaru, pobranego z lokalizacji danego kuriera i kompletowanego do załadunku,
1. po każdym zeskanowaniu kliknie przycisk „Dodaj” – zeskanowana paczka lub list przewozowy doda się do listy zeskanowanych paczek, poniżej pola skanowania. Równocześnie zeskanowana już paczka zniknie z listy paczek oczekujących.

Zakończenie wydania magazynier potwierdzi przyciskiem „Zakończ”. System automatycznie zaktualizuje status dokumentu wydania. Po zakończeniu wydania paczek towary zostaną wydane z lokalizacji, a system WMS wygeneruje protokół przekazania paczek.

*Powrót do konfiguracji*

### Wydanie awizowane - z początkową i końcową akceptacją

#### Wydanie jednoetapowe, z początkową i końcową akceptacją

![Diagram 25. Wydanie jednoetapowe, z początkową i końcową akceptacją.](\img\OIP.png)

Diagram 25. Wydanie jednoetapowe, z początkową i końcową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w „Akceptacji”.

Na nowo utworzonym dokumencie ZK/WMS, „Akceptacja” wykona następujące działania:

1. Otworzy dokument,
1. Sprawdzi poprawność danych,
1. W razie potrzeby skoryguje:
  1. dane kontrahenta i dostawy,
  1. rodzaj kolejki zbierania i pakowania dla poszczególnych towarów - proponowane kolejki będą wyświetlane domyślnie, na podstawie cech towarów w systemie ERP.

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do wydania magazynowego. System WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mógł ręcznie wprowadzić zmiany. Jeśli nie zatwierdzi dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu od klienta (ZK/WMS) i wydanych z magazynu.

A.    Jeśli ilości te będą zgodne:

a.    System WMS automatycznie:

i.    zmieni status dokumentu wydania magazynowego na ”Zakończone”,

ii.    nada dokumentowi ZK/WMS w „Akceptacji” status „Zakończone”,

b.    System ERP automatycznie utworzy WZ na towar, zatwierdzony do wydania.

B. Jeśli ilości nie będą zgodne, system – w zależności od sposobu postępowania, wybranego w konfiguracji WMS – zadziała w jeden wymienionych poniżej sposobów:

  1. zwróci dokument do magazynu, na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji), dokument po zwrocie otrzyma status "Zwrócone",
  1. obsłuży niepełne wydanie ścieżką opisaną w punkcie „A” (tak, jak przy ilościach zgodnych),
  1. na niewydaną ilość zamówionego towaru, system ERP utworzy zamówienie różnicowe, a niepełne wydanie obsłuży ścieżką opisaną w punkcie „A” (jak przy ilościach zgodnych).

*Powrót do konfiguracji*

#### Wydanie dwuetapowe (Jednoetapowe + Kurier), z początkową i końcową akceptacją

![Diagram 26. Wydanie dwuetapowe (Jednoetapowe + Kurier), z początkową i końcową    akceptacją.](\img\OIP.png)

Diagram 26. Wydanie dwuetapowe (Jednoetapowe + Kurier), z początkową i końcową   
akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w „Akceptacji”.

Na nowo utworzonym dokumencie ZK/WMS, „Akceptacja” wykona następujące działania:

- Otworzy dokument,
- Sprawdzi poprawność danych,
- W razie potrzeby skoryguje:
  - dane kontrahenta i dostawy
  - rodzaj kolejki zbierania i pakowania dla poszczególnych towarów - proponowane kolejki będą wyświetlane domyślnie, na podstawie cech towarów w systemie ERP.

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do wydania magazynowego. System WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem „Zakończ i przekaż do akceptacji”. System WMS automatycznie sprawdzi czy towar był spakowany przynajmniej do jednego opakowania zbiorczego oraz czy list przewozowy został wygenerowany.

Jeżeli Opakowanie zbiorcze zostało użyte lub został wygenerowany list przewozowy, czyli wystąpiła jedna z kombinacji:

- Opakowanie – TAK, List – NIE,
- Opakowanie – NIE, List – TAK,
- Opakowanie – TAK, List –TAK,

to system wyświetli popup, w którym będą:

- Informacja na jaką lokalizację kuriera (lub „brak kuriera”, jeśli nie był wybrany list przewozowy) należy przesunąć spakowany towar z danego dokumentu wydania,
- Pole do skanowania kodu lokalizacji kuriera
- Pole do skanowania kodu towaru (lub opakowania zbiorczego) na lokalizacji kuriera,
- Listę towarów (lub opakowań zbiorczych) do przesunięcia – po zeskanowaniu danego towaru, jego kolor na liście się zmieni,
- Przycisk zatwierdzenia skanowania – przesunięcia towarów z listy na lokalizację kuriera,
- Przycisk resetowania skanowania – przesunięcia towarów z listy.

Zatwierdzenie zeskanowania towarów (lub opakowań zbiorczych) na lokalizacji kuriera, spowoduje że system WMS automatycznie:

1. Doda każdy zeskanowany towar (lub opakowanie zbiorcze) do lokalizacji kuriera i nada mu status „Oczekuje na zatwierdzenie” – z tym statusem towar (paczka) nie będzie mógł być wydany kurierowi,
1. Doda ilości towarów, przesuniętych na lokalizację kuriera i powiązanych z danym dokumentem wydania, do dokumentu ZK/WMS oraz przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

Jeżeli opakowanie zbiorcze nie było użyte, ani nie został wygenerowany list przewozowy, to system WMS od razu przekaże dane z dokumentu wydania do dokumentu ZK/WMS, do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mógł ręcznie wprowadzić zmiany. Jeśli nie zatwierdzi dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu od klienta (ZK/WMS) i wydanych z magazynu.

A.    Jeśli ilości te będą zgodne, to system WMS automatycznie:

1. zmieni status dokumentu wydania magazynowego na ”Zakończone”,
1. nada dokumentowi ZK/WMS w „Akceptacji”, status „Zakończone”, co będzie równoznaczne z końcową akceptacją wydania magazynowego.

B. Jeśli ilości nie będą zgodne, system – w zależności od sposobu postępowania, wybranego w konfiguracji WMS – zadziała w jeden wymienionych poniżej sposobów:

1. zwróci dokument do magazynu, na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji), dokument po zwrocie otrzyma status "Zwrócone",
1. obsłuży niepełne wydanie ścieżką opisaną w punkcie „A” (tak, jak przy ilościach zgodnych),
1. na niewydaną ilość zamówionego towaru, system ERP utworzy zamówienie różnicowe, a niepełne wydanie obsłuży ścieżką opisaną w punkcie „A” (jak przy ilościach zgodnych).

Po zatwierdzeniu wydania przez handel (końcowej akceptacji handlowej):

1. System ERP automatycznie utworzy WZ na towar, zatwierdzony do wydania,
1. System WMS zmieni status towarów lub paczek, przesuniętych na lokalizację kuriera i powiązanych z zakończonym dokumentem wydania magazynowego, z „Do akceptacji” na „Do wydania”.

Wydanie spakowanego towaru kurierowi, magazynier rozpocznie od wejścia do zakładki "Wydanie do kuriera". System WMS zwróci listę kurierów, do których oczekują paczki/listy przewozowe do wydania. Lista zawierać będzie kolumny:

- Nazwa kuriera
- Paczki oczekujące (ilość paczek oczekująca na wydanie)
- Przycisk do przejścia do szczegółów

Po wejściu do szczegółów wybranego kuriera system WMS przeniesie magazyniera do widoku listy dokumentów wydania temu kurierowi. Magazynier wykona dalej następujące czynności:

1. utworzy nowy dokument wydania, na którym będzie kompletował ładunek towaru i doda ten dokument do listy istniejących już dokumentów wydania,
1. przejdzie do szczegółów nowo utworzonego dokumentu wydania,
1. kliknie przycisk „Rozpocznij załadunek”,
1. zeskanuje kod z dodawanego opakowania lub listu przewozowego towaru, pobranego z lokalizacji danego kuriera i kompletowanego do załadunku,
1. po każdym zeskanowaniu kliknie przycisk „Dodaj” – zeskanowana paczka lub list przewozowy doda się do listy zeskanowanych paczek, poniżej pola skanowania. Równocześnie zeskanowana już paczka zniknie z listy paczek oczekujących.

Zakończenie wydania magazynier potwierdzi przyciskiem „Zakończ”. System automatycznie zaktualizuje status dokumentu wydania. Po zakończeniu wydania paczek towary zostaną wydane z lokalizacji, a system WMS wygeneruje protokół przekazania paczek.

*Powrót do konfiguracji*

#### Wydanie dwuetapowe (Zbieranie + Pakowanie), z początkową i końcową akceptacją

![Diagram 27. Wydanie dwuetapowe (Zbieranie + Pakowanie), z początkową i końcową akceptacją.](\img\OIP.png)

Diagram 27. Wydanie dwuetapowe (Zbieranie + Pakowanie), z początkową i końcową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w „Akceptacji”.

Na nowo utworzonym dokumencie ZK/WMS, „Akceptacja” wykona następujące działania:

1. Otworzy dokument,
1. Sprawdzi poprawność danych,
1. W razie potrzeby skoryguje:
  1. dane kontrahenta i dostawy,
  1. rodzaj kolejki zbierania i pakowania dla poszczególnych towarów - proponowane kolejki będą wyświetlane domyślnie, na podstawie cech towarów w systemie ERP.

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do wydania magazynowego. System WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. W dokumencie wydania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mógł ręcznie wprowadzić zmiany. Jeśli nie zaakceptuje dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu od klienta (ZK/WMS) i wydanych z magazynu.

A.    Jeśli ilości te będą zgodne:

a.    System WMS automatycznie:

i.    zmieni status dokumentu wydania magazynowego na ”Zakończone”,

ii.    nada dokumentowi ZK/WMS w „Akceptacji”, status „Zakończone”,

b.    System ERP automatycznie utworzy WZ na towar, zatwierdzony do wydania.

B. Jeśli ilości nie będą zgodne, system – w zależności od sposobu postępowania, wybranego w konfiguracji WMS – zadziała w jeden wymienionych poniżej sposobów:

  1. zwróci dokument do magazynu, na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji), dokument po zwrocie otrzyma status "Zwrócone",
  1. obsłuży niepełne wydanie ścieżką opisaną w punkcie „A” (tak, jak przy ilościach zgodnych),
  1. na niewydaną ilość zamówionego towaru, system ERP utworzy zamówienie różnicowe, a niepełne wydanie obsłuży ścieżką opisaną w punkcie „A” (jak przy ilościach zgodnych).

*Powrót do konfiguracji*

#### Wydanie trzyetapowe, z początkową i końcową akceptacją

![Diagram 28. Wydanie trzyetapowe, z początkową i końcową akceptacją.](\img\OIP.png)

Diagram 28. Wydanie trzyetapowe, z początkową i końcową akceptacją.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w „Akceptacji”.

Na nowo utworzonym dokumencie ZK/WMS, „Akceptacja” wykona następujące działania:

1. Otworzy dokument,
1. Sprawdzi poprawność danych,
1. W razie potrzeby skoryguje:
  1. dane kontrahenta i dostawy
  1. rodzaj kolejki zbierania i pakowania dla poszczególnych towarów - proponowane kolejki będą wyświetlane domyślnie, na podstawie cech towarów w systemie ERP.

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do wydania magazynowego. System WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione produkty z listy i doda je do listy towarów zbieranych na wybrany nośnik,

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary, czyli lokalizacji pakowacza. System WMS:

1. zmieni status dokumentu zbierania na „Zakończone”,
1. utworzy dokument pakowania z zebranymi towarami i doda go do listy w menu „Wydania/Pakowanie”, ze statusem „Oczekuje na pakowanie”.

Magazynier wybierze dokument ze statusem „Oczekuje na pakowanie”, z listy dokumentów w menu „Wydania/Pakowanie”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Jeżeli w konfiguracji procesów została wcześniej wybrana opcja używania opakowania zbiorczego przy wydaniu, to magazynier wykona następujące operacje:

1. pobierze opakowanie zbiorcze, w którym będzie umieszczał zamówione towary oraz zeskanuje kod rodzaju tego opakowania,
1. w systemie WMS wygeneruje i wydrukuje kod dla pobranego opakowania zbiorczego oraz naklei ten kod na opakowanie,
1. zeskanuje kolejno zamówione towary z listy i doda je do towarów pobranych do opakowania zbiorczego.

Jeżeli jedno opakowanie zbiorcze nie wystarczy do spakowania zamówionego towaru, magazynier pobierze kolejne i powtórzy operacje od „a” do „c”.

Jeśli w konfiguracji procesów opcja używania opakowania zbiorczego nie została wybrana, magazynier zeskanuje kody z opakowań jednostkowych zebranego towaru i doda je do listy towarów spakowanych.

W dokumencie pakowania magazynier opcjonalnie będzie mógł także utworzyć listy przewozowe dla skompletowanych opakowań zbiorczych z towarem (jeśli opakowanie zbiorcze było użyte) lub dla towarów w opakowaniach jednostkowych. Tworzenie listów przewozowych będzie dostępne w odrębnej sekcji, w której użytkownik określi:

1. nazwę kuriera,
1. rodzaj opakowania transportowego,
1. liczbę opakowań,
1. wymiary opakowania (długość, szerokość, wysokość),
1. łączną wagę opakowań danego rodzaju wraz z towarem.

W sekcji, dedykowanej listowi przewozowemu, użytkownik będzie mógł dodać kolejne rodzaje opakowań przyciskiem "Dodaj pozycję". Po skompletowaniu frachtu dla kuriera, nastąpi utworzenie listów przewozowych na poszczególne opakowania, przyciskiem "Generuj list przewozowy".

Obsługę procesu pakowania magazynier zakończy przyciskiem zapisywania „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

„Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mógł ręcznie wprowadzić zmiany oraz wybrać kuriera, któremu towar zostanie wydany do dostarczenia klientowi. Jeśli „Akceptacja” nie zatwierdzi dokumentu, zwróci go do magazynu na listę awizowanych dokumentów pakowania, w celu korekty i ponownego przeprowadzenia procesu pakowania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone". Jeśli „Akceptacja” zatwierdzi dokument, system WMS sprawdzi automatycznie czy występują rozbieżności pomiędzy ilością towarów zadeklarowanych w zamówieniu od klienta (ZK/WMS) i wydanych z magazynu.

A.    Jeśli ilości te będą zgodne:

a.    System WMS automatycznie:

i.    zmieni status dokumentu pakowania na:

-- „Zakończone” jeśli przy końcowym zatwierdzaniu „Akceptacja” wskazała kuriera do dostarczenia,

-- „Zakończone, wybrać kuriera” jeśli końcowym zatwierdzaniu „Akceptacja” nie wskazała kuriera

ii.    nada dokumentowi ZK/WMS w „Akceptacji”, status „Zakończone”,

b.    System ERP automatycznie utworzy WZ na towar, zatwierdzony do wydania.

B. Jeśli ilości nie będą zgodne, system WMS – w zależności od sposobu postępowania, wybranego w konfiguracji WMS – zadziała w jeden wymienionych poniżej sposobów:

  1. zwróci dokument do magazynu, na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji), dokument po zwrocie otrzyma status "Zwrócone",
  1. obsłuży niepełne wydanie ścieżką opisaną w punkcie „A” (tak, jak przy ilościach zgodnych),
  1. na niewydaną ilość zamówionego towaru, system ERP utworzy zamówienie różnicowe, a niepełne wydanie obsłuży ścieżką opisaną w punkcie „A” (jak przy ilościach zgodnych).

Po zatwierdzeniu wydania przez „Akceptację” nastąpi przesunięcie spakowanych towarów na lokalizację kuriera, który obsłuży dostarczenie do klienta. Przesunięcie to będzie mogło się odbywać jednym z dwóch następujących sposobów:

1. Automatycznie, jeśli dokument pakowania (po zatwierdzeniu przez „Akceptację”) ma status „Zakończone”,
1. Z ręcznym wyborem kuriera, jeżeli dokument pakowania ma status „Zakończone, wybrać kuriera”; wówczas magazynier:
  1. otworzy dokument pakowania,
  1. kliknie przycisk wyboru kuriera, po którym system WMS zwróci popup z listą rozwijaną kurierów do wyboru,
  1. wybierze kuriera z listy rozwijanej,
  1. zakończy wybór przyciskiem „Wybierz”, a system WMS przesunie spakowane towary na lokalizację wybranego kuriera

Wydanie spakowanego towaru kurierowi, magazynier rozpocznie od wejścia do zakładki "Wydanie do kuriera". System WMS zwróci listę kurierów, do których oczekują paczki/listy przewozowe do wydania. Lista zawierać będzie kolumny:

- Nazwa kuriera
- Paczki oczekujące (ilość paczek oczekująca na wydanie)
- Przycisk do przejścia do szczegółów

Po wejściu do szczegółów wybranego kuriera system WMS przeniesie magazyniera do widoku listy dokumentów wydania temu kurierowi. Magazynier wykona dalej następujące czynności:

1. utworzy nowy dokument wydania, na którym będzie kompletował ładunek towaru i doda ten dokument do listy istniejących już dokumentów wydania,
1. przejdzie do szczegółów nowo utworzonego dokumentu wydania,
1. kliknie przycisk „Rozpocznij załadunek”,
1. zeskanuje kod z dodawanego opakowania lub listu przewozowego towaru, pobranego z lokalizacji danego kuriera i kompletowanego do załadunku,
1. po każdym zeskanowaniu kliknie przycisk „Dodaj” – zeskanowana paczka lub list przewozowy doda się do listy zeskanowanych paczek, poniżej pola skanowania. Równocześnie zeskanowana już paczka zniknie z listy paczek oczekujących.

Zakończenie wydania magazynier potwierdzi przyciskiem „Zakończ”. System automatycznie zaktualizuje status dokumentu wydania. Po zakończeniu wydania paczek towary zostaną wydane z lokalizacji, a system WMS wygeneruje protokół przekazania paczek.

*Powrót do konfiguracji*

### Wydania bezpośrednie

#### Wydanie bezpośrednie bez akceptacji

![Diagram 37. Wydanie bezpośrednie bez akceptacji.](\img\OIP.png)

Diagram 37. Wydanie bezpośrednie bez akceptacji.

Po podjęciu decyzji o bezpośrednim przyjęciu towaru, magazynier – w widoku magazynowym listy wydań bezpośrednich - utworzy nowy dokument wydania bezpośredniego, wybierając przycisk „Dodaj wydanie”. Użycie przycisku zwróci formularz z polami do wypełnienia. Wypełnianie magazynier rozpocznie od wybrania typu przyjęcia: WZ – wydanie zewnętrzne lub RW – rozchód wewnętrzny. Jeśli wybierze wydanie zewnętrzne wskaże kontrahenta z listy rozwijanej. Jeżeli rozchód wewnętrzny, pole kontrahenta zostanie automatycznie ukryte. Dalej magazynier wypełni pola z danymi podstawowymi, tj.:

- Numer oryginalny,
- Tytuł,
- Opis.

Po zakończeniu wypełniania pól formularza, magazynier zapisze wprowadzone dane. Dokument wydania bezpośredniego zostanie utworzony w systemie WMS i będzie dodany do listy dokumentów wydań bezpośrednich w widoku magazynowym ze statusem „Nowe”. Rozpoczynając wydanie, magazynier otworzy wybrany dokument z listy i zablokuje go do obsługi przez siebie. System WMS automatycznie nada dokumentowi na liście status „W przygotowaniu”.

Magazynier zeskanuje kod każdego towaru, uzupełni aktywne pola dokumentu i kliknie przycisk „Zapisz”. System WMS automatycznie zatwierdzi wydanie i nada dokumentowi status "Zakończone". System ERP wygeneruje natomiast odpowiedni dokument wydania (WZ lub RW).

*Powrót do konfiguracji*

#### Wydanie bezpośrednie z końcową akceptacją

![Diagram 38. Wydanie bezpośrednie z końcową akceptacja.](\img\OIP.png)

Diagram 38. Wydanie bezpośrednie z końcową akceptacja.

Po podjęciu decyzji o bezpośrednim wydaniu towaru, magazynier – w widoku magazynowym listy wydań bezpośrednich - utworzy nowy dokument wydania bezpośredniego, wybierając przycisk „Dodaj wydanie”. Użycie przycisku zwróci formularz z polami do wypełnienia. Wypełnianie magazynier rozpocznie od wybrania typu wydania: WZ – wydanie zewnętrzne lub RW – rozchód wewnętrzny. Jeśli wybierze wydanie zewnętrzne wskaże kontrahenta z listy rozwijanej. Jeżeli wydanie wewnętrzne, pole kontrahenta zostanie automatycznie ukryte. Dalej magazynier wypełni pola z danymi podstawowymi, tj.:

- Numer oryginalny,
- Tytuł,
- Opis.

Po zakończeniu wypełniania pól formularza, magazynier zapisze wprowadzone dane. Dokument przyjęcia bezpośredniego zostanie utworzony w systemie WMS i będzie dodany do listy dokumentów wydań bezpośrednich w widoku magazynowym ze statusem „Nowe”. Rozpoczynając wydanie, magazynier otworzy wybrany dokument z listy i zablokuje go do obsługi przez siebie. System WMS automatycznie nada dokumentowi na liście status „W przygotowaniu”.

Magazynier zeskanuje kod każdego towaru, uzupełni aktywne pola dokumentu i kliknie przycisk „Zapisz i przekaż dalej”. System WMS automatycznie przekaże dokument do akceptacji, nadając mu status "Do akceptacji". „Akceptacja” zweryfikuje treść dokumentu, uzupełnionego o dane z wydania i będzie mógł ręcznie wprowadzić zmiany (zmiana ilości towaru przyjętego na każdej lokalizacji). Jeśli nie zaakceptuje dokumentu, zwróci go do magazynu na listę wydań bezpośrednich, w celu przeprowadzenia ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone". Jeśli „Akceptacja” zaakceptuje dokument, zatwierdzi go, a system WMS zmieni status zamówienia na "Zakończone". System ERP utworzy natomiast odpowiedni dokument wydania (WZ lub RW).

*Powrót do konfiguracji*

## Odbiór osobisty

#### Odbiór osobisty - bez akceptacji - jednoetapowy

![Diagram 29. Odbiór osobisty, bez akceptacji - jednoetapowy.](\img\OIP.png)

Diagram 29. Odbiór osobisty, bez akceptacji - jednoetapowy.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi lub statusu w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

  1. utworzy nowy dokument ZK/WMS,
  1. przekaże go do listy wydań magazynowych.

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania/ Odbiór osobisty” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe.

Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania. W systemie WMS automatycznie spowoduje to:

  1. zmianę statusu dokumentu wydania magazynowego na ”Zakończone”,
  1. utworzenie w systemie ERP dokumentu WZ,

#### Odbiór osobisty - bez akceptacji - dwuetapowy

![Diagram 30.  Odbiór osobisty, bez akceptacji - dwuetapowy.](\img\OIP.png)

Diagram 30.  Odbiór osobisty, bez akceptacji - dwuetapowy.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi lub statusu w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

  1. utworzy nowy dokument ZK/WMS,
  1. przekaże go do listy zbierania.

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione towary z listy i doda je do listy towarów zbieranych na wybrany nośnik,

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary. Po zeskanowaniu i zatwierdzeniu lokalizacji odbioru osobistego, system WMS:

  1. zmieni status dokumentu zbierania na „Zakończone”
  1. utworzy dokument odbioru osobistego z zebranymi towarami i doda go do listy w menu „Wydania/Odbiór osobisty”, ze statusem „Oczekuje na odbiór”

Magazynier wybierze dokument ze statusem „Oczekuje na odbiór”, z listy dokumentów w menu „Wydania/Odbiór osobisty”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Magazynier zeskanuje kody z zebranych towarów i doda je do listy towarów spakowanych, do odbioru osobistego.

Obsługę pakowania do odbioru osobistego magazynier zakończy przyciskiem zapisywania. W systemie WMS automatycznie spowoduje to:

  1. nadanie statusu ”Zakończone” zapisanemu właśnie dokumentowi odbioru osobistego,
  1. utworzenie w systemie ERP dokumentu WZ,
  1. nadanie dokumentowi ZK/WMS w Akceptacji, statusu „Zakończone”.

#### Odbiór osobisty - z początkową akceptacją - jednoetapowy

![Diagram 31. Odbiór osobisty, z początkową akceptacją - jednoetapowy.](\img\OIP.png)

Diagram 31. Odbiór osobisty, z początkową akceptacją - jednoetapowy.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi lub statusu w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w Akceptacji.

Na nowo utworzonym dokumencie ZK/WMS, Akceptacja sprawdzi poprawność danych. Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do wydania magazynowego. System WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania/Odbiór osobisty” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. Obsługę procesu wydania magazynier zakończy przyciskiem zapisywania. W systemie WMS automatycznie spowoduje to:

  1. zmianę statusu dokumentu wydania magazynowego na ”Zakończone”,
  1. utworzenie w systemie ERP dokumentu WZ,
  1. nadanie dokumentowi ZK/WMS w Akceptacji, statusu „Zakończone”.

#### Odbiór osobisty - z początkową akceptacją - dwuetapowy

![Diagram 32. Odbiór osobisty, z początkową akceptacją -dwuetapowy.](\img\OIP.png)

Diagram 32. Odbiór osobisty, z początkową akceptacją -dwuetapowy.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi lub statusu w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w Handlu.

Na nowo utworzonym dokumencie ZK/WMS, "Akceptacja" wykona następujące działania:

  1. Otworzy dokument, system WMS automatycznie zmieni jego status na „W przygotowaniu”,
  1. Sprawdzi poprawność danych,
  1. W razie potrzeby skoryguje dane kontrahenta i dostawy

Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do zbierania w magazynie. System WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione towary z listy i doda je do listy towarów zbieranych na wybrany nośnik.

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary. Po zeskanowaniu i zatwierdzeniu lokalizacji odbioru osobistego, system WMS:

1. zmieni status dokumentu zbierania na „Zakończone”
1. utworzy dokument odbioru osobistego z zebranymi towarami i doda go do listy w menu „Wydania/Odbiór osobisty”, ze statusem „Oczekuje na odbiór”

Magazynier wybierze dokument ze statusem „Oczekuje na odbiór”, z listy dokumentów w menu „Wydania/Odbiór osobisty”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Magazynier zeskanuje kody z zebranych towarów i doda je do listy towarów spakowanych, do odbioru osobistego. Obsługę procesu pakowania magazynier zakończy przyciskiem zapisywania. W systemie WMS automatycznie spowoduje to:

1. nadanie statusu ”Zakończone” zapisanemu właśnie dokumentowi pakowania,
1. utworzenie w systemie ERP dokumentu WZ,
1. nadanie dokumentowi ZK/WMS w "Akceptacji", statusu „Zakończone”.

#### Odbiór osobisty - z końcową akceptacją - jednoetapowy

![Diagram 33. Odbiór osobisty, z początkową akceptacją -jednoetapowy.](\img\OIP.png)

Diagram 33. Odbiór osobisty, z początkową akceptacją -jednoetapowy.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi lub zmianie statusu w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

  1. utworzy nowy dokument ZK/WMS,
  1. przekaże go do listy wydań magazynowych.

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania/Odbiór osobisty” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. Obsługę procesu wydania magazynier zakończy przyciskiem „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

Akceptacja zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania i będzie mogła ręcznie wprowadzić zmiany. Jeśli nie zatwierdzi dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli Akceptacja zatwierdzi dokument, to:

  1. system WMS zmieni status dokumentu wydania magazynowego na ”Zakończone”,
  1. system WMS nada dokumentowi ZK/WMS w Akceptacji, status „Zakończone”,
  1. system ERP automatycznie utworzy WZ na wydany towar.

#### Odbiór osobisty - z końcową akceptacją - dwuetapowy

![Diagram 34. Odbiór osobisty, z końcową akceptacją - dwuetapowy.](\img\OIP.png)

Diagram 34. Odbiór osobisty, z końcową akceptacją - dwuetapowy.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi lub statusu w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie:

  1. utworzy nowy dokument ZK/WMS,
  1. przekaże go do listy zbierania.

Na podstawie danych z ZK/WMS, system WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione towary z listy i doda je do listy towarów zbieranych na wybrany nośnik.

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary. Po zeskanowaniu i zatwierdzeniu lokalizacji odbioru osobistego, system WMS:

  1. zmieni status dokumentu zbierania na „Zakończone”
  1. utworzy dokument odbioru osobistego z zebranymi towarami i doda go do listy w menu „Wydania/Odbiór osobisty”, ze statusem „Oczekuje na odbiór”

Magazynier wybierze dokument ze statusem „Oczekuje na odbiór”, z listy dokumentów w menu „Wydania/Odbiór osobisty”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Magazynier zeskanuje kody zebranych towarów i doda je do listy towarów spakowanych, do wydania osobistego. Obsługę wydania zakończy przyciskiem zapisywania „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych do wydania przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

Akceptacja zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz wydania i będzie mogła ręcznie wprowadzić zmiany. Jeśli nie zatwierdzi dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli Akceptacja zatwierdzi dokument, system WMS automatycznie:

  1. zmieni status dokumentu wydania magazynowego na ”Zakończone”,
  1. nada dokumentowi ZK/WMS w Akceptacji, status „Zakończone”,
  1. system ERP automatycznie utworzy WZ na wydany towar.

#### Odbiór osobisty - z początkową i końcową akceptacją - jednoetapowy

![Diagram 35. Odbiór osobisty, z początkową i końcową akceptacją - jednoetapowy.](\img\OIP.png)

Diagram 35. Odbiór osobisty, z początkową i końcową akceptacją - jednoetapowy.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi lub statusu w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w Akceptacji.

Na nowo utworzonym dokumencie ZK/WMS, Akceptacja sprawdzi poprawność danych. Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do wydania magazynowego. System WMS automatycznie utworzy dokument wydania magazynowego i doda go do listy dokumentów wydania, pod pozycją „Wydania/Odbiór osobisty” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na wydanie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Magazynier pobierze zamówione towary jednostkowe i zeskanuje ich kody towarowe. Obsługę procesu wydania magazynier zakończy przyciskiem „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

Akceptacja zweryfikuje treść dokumentu, uzupełnionego o dane z wydania i będzie mogła ręcznie wprowadzić zmiany. Jeśli nie zatwierdzi dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli Akceptacja zatwierdzi dokument, to:

  1. system WMS zmieni status dokumentu wydania magazynowego na ”Zakończone”,
  1. system WMS nada dokumentowi ZK/WMS w Akceptacji, status „Zakończone”,
  1. system ERP automatycznie utworzy WZ na wydany towar.

#### Odbiór osobisty - z początkową i końcową akceptacją - dwuetapowy

![Diagram 36. Odbiór osobisty, z początkową i końcową akceptacją - dwuetapowy.](\img\OIP.png)

Diagram 36. Odbiór osobisty, z początkową i końcową akceptacją - dwuetapowy.

Proces będzie się rozpoczynał od utworzenia dokumentu zamówienia od klienta (ZK), w systemie ERP. Po wybraniu odpowiedniej flagi lub statusu w ERP, zamówienie zostanie przesłane do systemu WMS, który automatycznie utworzy nowy dokument ZK/WMS, ze statusem „Nowe” dołączy go do listy zamówień od klienta w Akceptacji.

Na nowo utworzonym dokumencie ZK/WMS, Akceptacja sprawdzi poprawność danych. Zatwierdzenie przyciskiem „Przekaż do magazynu” prześle dane z dokumentu ZK/WMS do zbierania. System WMS automatycznie utworzy dokument zbierania i doda go do listy dokumentów zbierania, pod pozycją „Wydania/Zbieranie” w menu systemu WMS. Dokumentowi temu nada status „Oczekuje na zbieranie”.

Magazynier wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”. Następnie magazynier, w systemie WMS zeskanuje kolejno zamówione towary z listy i doda je do listy towarów zbieranych na wybrany nośnik,

W momencie zakończenia zbierania, pokaże się popup z koniecznością zeskanowania lokalizacji, gdzie odkłada zebrane towary. Po zeskanowaniu i zatwierdzeniu lokalizacji odbioru osobistego, system WMS:

  1. zmieni status dokumentu zbierania na „Zakończone”
  1. utworzy dokument odbioru osobistego z zebranymi towarami i doda go do listy w menu „Wydania/Odbiór osobisty”, ze statusem „Oczekuje na odbiór”.

Magazynier wybierze dokument ze statusem „Oczekuje na odbiór”, z listy dokumentów w menu „Wydania/Odbiór osobisty”, następnie wejdzie w szczegóły dokumentu i kliknie przycisk „Rozpocznij”, system WMS zmieni status dokumentu na „W przygotowaniu”.

Magazynier zeskanuje kody zebranych towarów i doda je do listy towarów spakowanych do wydania osobistego. Pakowanie  do odbioru osobistego zakończy przyciskiem zapisywania „Zapisz i przekaż do akceptacji”. System WMS automatycznie doda ilości towarów, zebranych i spakowanych przez magazyniera, do dokumentu ZK/WMS i przekaże go do akceptacji, zmieniając status dokumentu na "Do akceptacji".

Akceptacja zweryfikuje treść dokumentu, uzupełnionego o dane ze zbierania oraz pakowania do odbioru osobistego i będzie mogła ręcznie wprowadzić zmiany. Jeśli nie zatwierdzi dokumentu, zwróci go do magazynu na listę awizowanych wydań, w celu korekty i ponownego wydania (magazynier widzi wydanie w takim stanie, w którym zakończył i przekazał do akceptacji). Dokument po zwrocie otrzyma status "Zwrócone".

Jeśli Akceptacja zatwierdzi dokument, to:

  1. system WMS zmieni status dokumentu wydania magazynowego na ”Zakończone”,
  1. system WMS nada dokumentowi ZK/WMS w Akceptacji, status „Zakończone”,
  1. system ERP automatycznie utworzy WZ na wydany towar.

