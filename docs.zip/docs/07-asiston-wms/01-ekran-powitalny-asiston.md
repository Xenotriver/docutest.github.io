---
title: "Ekran powitalny Asiston"
sidebar_label: "7.1. Ekran powitalny Asiston"
---

## Pulpit

Pulpit (dashboard) będzie pokazywał podstawowe statystyki, dotyczące bieżących operacji i zasobów w systemie Asiston WMS. Informacje te będą prezentowane w formie następujących, dostępnych  widgetów:

- Bestsellery
- Użytkownicy online,
- Liczba inwentaryzacji,
- Liczba niezakończonych przesunięć,
- Liczba trwających inwentaryzacji,
- Liczba niezakończonych wydań,
- Przesunięcia – etapy,
- Wydania – etapy,
- Przyjęcia awizowane – etapy,
- Zamówienia od klienta,
- Statystyki według kurierów,
- Paczki wydane kurierowi,
- Przyjęte towary,
- Wydane towary,
- Szybki dostęp.

Zestaw widgetów, do wyświetlania na swoim pulpicie, klient może sobie skompletować z listy widgetów, predefiniowanych w systemie w module „Moje konto”.

## Menu boczne

Menu boczne – w postaci listy oraz listy rozwijanej - będzie udostępniać użytkownikowi poszczególne moduły i funkcjonalności systemu Asiston WMS.

![. Widok menu systemu Asiston WMS.](\img\Obrazy\Menu_boczne.png)


 Widok menu systemu Asiston WMS.

Moduły systemu możemy podzielić na następujące rodzaje:

- Konfiguracyjne, służące określeniu i ustawieniu procesów, zasobów oraz widoków w systemie:
  - „Konfiguracja”.
- Administracyjne, których celem jest obsługa zarządzania dostępem dla pojedynczych użytkowników oraz nadawanie im ról i uprawnień:
  - „Moje konto”,
  - „Administracja”.
- Obsługujące poszczególne procesy i operacje magazynowe:
  - „Akceptacje”,
  - „Przyjęcia”,
  - „Kontrola jakości”
  - „Przesunięcia”,
  - „Wydania”,
  - „Zwroty”,
  - „Inwentaryzacja”,
  - „Reklamacje”.
- Służące monitorowaniu stanu i lokalizacji zasobów oraz stanu i wyników:
  - „Repozytorium plików”,
  - „Produkty”,
  - „Nośniki”,
  - „Informator”,
  - „Raporty”.

Kliknięcie poszczególnych modułów z menu systemu Asiston WMS zwróci widoki, które mogą mieć postać:

- Listy pozycji, na liście można ustawić:
  - Jakie kolumny będą wyświetlane na liście oraz jaka będzie ich kolejność,
  - Jakich przycisków filtrowania będzie można używać.
- Listy rozwijanej, zawierającej funkcjonalności, przypisane do danego modułu,
- Obszaru roboczego, podzielonego na sekcje (*Repozytorium plików*),
- Widgetów (ekran startowy).

W widoku listy będzie możliwe sortowanie rosnąco lub malejąco po zawartości każdej z kolumn.

Na górze każdego widoku będzie okno wyszukiwania, służące do znajdowania pozycji z menu systemu Asiston WMS, po nazwie lub fragmencie nazwy. Wyszukiwarka umożliwia także szybkie przejście do informatora poprzez zeskanowanie kodu towau, lokalizacji czy nośnika. Okno wyszukiwania będzie ułatwiać przechodzenie do wybranej pozycji menu, szczególnie na urządzeniach z mniejszym ekranem, na których pełne menu, nie będzie wyświetlane.
