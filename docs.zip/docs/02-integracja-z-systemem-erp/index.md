---
title: "Integracja z systemem ERP"
sidebar_label: "2. Integracja z systemem ERP"
---

Integracja z ERP będzie obsługiwana z formularza wyboru nazwy systemu oraz kartotek, pozycji i dokumentów do powiązania pomiędzy ERP, a WMS.

Opis zostanie uzupełniony po doprecyzowaniu szczegółów rozwiązania w pliku dokumentacji dedykowanej.
