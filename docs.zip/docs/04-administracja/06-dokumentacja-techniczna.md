---
title: "Dokumentacja techniczna"
sidebar_label: "4.6. Dokumentacja techniczna"
---

Pozycja „Administracja/Dokumentacja techniczna” służy przejścia do „Swaggera”. Dokumentacja zawiera zbiór metod, które mogą posłużyć do integracji programów zewnętrznych z systemem Asiston.

![. Dokumentacja techniczna](\img\Obrazy\Swagger.png)

 Dokumentacja techniczna
