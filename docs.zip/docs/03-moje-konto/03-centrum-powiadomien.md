---
title: "Centrum powiadomień"
sidebar_label: "3.3. Centrum powiadomień"
---

W zakładce „Moje konto/Centrum powiadomień” użytkownik będzie mógł ustawić widoki powiadomień, przychodzących na jego konto w systemie Asiston WMS.

![ Widok powiadomień użytkownika, w systemie Asiston WMS.](\img\Obrazy\Ustawienia_powiadomien.png)

 Widok ustawień powiadomień użytkownika, w systemie Asiston WMS.

Oprócz tego w tym widoku będzie miał listę wszystkich swoich historycznych powiadomień

![ Widok powiadomień użytkownika, w systemie Asiston WMS.](\img\Obrazy\Powiadomienia.png)

 Widok historii powiadomień użytkownika, w systemie Asiston WMS.