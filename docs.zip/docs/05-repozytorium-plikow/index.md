---
title: "Repozytorium plików"
sidebar_label: "5. Repozytorium plików"
---

W systemie Asiston WMS można dodawać pliki, które mogą być oznaczone jako:

- Publiczne – dostęp mają wszyscy użytkownicy, którzy mają dostęp do modułu
- Prywatne – dostępne tylko dla administratora
- Wybrane

W module jest możliwość tworzenia Katalogów oraz kolejnych podkatalogów.

Katalogi przechowują pliki - .pdf, .docx, .xlsx, .png, .jpg

Dodane pliki można:

- Przenieść do innego katalogu
- Usunąć
- Pobrać
- Zmienić nazwę
- Podejrzeć szczegóły:
  - Kto dodał załącznik
  - Kto ostatni modyfikował załącznik
  - Rozmiar

![. Widok repozytorium plików, w systemie Asiston WMS.](\img\Obrazy\Repozytorium_plików.png)

 Widok repozytorium plików, w systemie Asiston WMS.
